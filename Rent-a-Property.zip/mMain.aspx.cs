﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;
using DataAccess;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Collections.Specialized;

public class TempOkazion
{
    public string hfNameIDValue;
    public string NameOkazion;
    public string clientclickOkazion;
    public string CSSOkazionName;
    public string clientclickEtelaatBishtar;
    public string Dsc_Okazion;
    public string hfNameOkazionIDValue;
    public string class_OkazionTEXT;
}
public class ObjectQueryClass
{
    public string PrintType = "";
    public object lstQuery;
}
public partial class mMain : System.Web.UI.Page
{

    public static string ImagePath = "/Attachment/Images/";
    dbMaskanDataContext dc = new dbMaskanDataContext();
    protected override void OnInit(EventArgs e)
    {
        string adr = Request.QueryString["args"];
        if (adr == null || adr.Trim() == "" || adr.Trim().Replace("WEDFkmcvoD08r3e9SQ","").StartsWith("B"))
        {

            Request.Headers.Add("meta [name=viewport]", "content=\"width=480\",initial-scale=1");
        }
        else
            Request.Headers.Add("meta[name=viewport]",  "content=\"width=480\"");
        base.OnInit(e);
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        string strUserAgent = Request.UserAgent.ToString().ToLower();
        if (strUserAgent != null)
        {

            if (!(Request.Browser.IsMobileDevice == true || strUserAgent.Contains("iphone") ||
                strUserAgent.Contains("blackberry") || strUserAgent.Contains("mobile") ||
                strUserAgent.Contains("windows ce") || strUserAgent.Contains("opera mini") ||
                strUserAgent.Contains("palm")))
            {
                Response.Redirect("~/main.aspx");
            }
        }
        //if (!Request.Browser.IsMobileDevice)
        //{
        //    Response.Redirect("~/main.aspx");
        //    return;
        //}
        if (!IsPostBack)
        {
            bindCambo();
            DisplayOkazion();
            Display();
        }
    }
    protected void libtnprint_Click(object sender, EventArgs e)
    {
        Print();
    }
    protected void btnImgSend_Click(object sender, ImageClickEventArgs e)
    {
        if (CheckValidate())
        {
            Save();

            string message = "progressclose();ShowSeccessMessage('" + "پیام شما برای املاک ماهور ارسال گردید." + "</br>" + "');ClearDarkhast(); BindText();";
            ScriptManager.RegisterClientScriptBlock(btnImgSend, this.GetType(), "alert", message, true);
        }
    }
    protected void ldresult_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = BindKamboNoKarbari();
    }
    protected void btnrefreshListNoeKarbari_Click(object sender, EventArgs e)
    {
        ldresult.RaiseViewChanged();
        string message = ("SetDropDownLabel('lblNoeKarbariName_Zamin', 'hfNoekarbariName');");
        ScriptManager.RegisterStartupScript(lstboxNoeKarbariZamin, this.GetType(), "alert", message, true);
    }

    /// <summary>
    /// بررسی میکند که ورژن بروزر استفاده شده است اینترنت اکسپلرور کمتر از از 8 است یانه
    /// زیرا زیر این ورزن بعضی از کدها جواب داده نمی شود
    /// </summary>
    /// <returns></returns>
    bool IsBrowserIEVersoinLower8()
    {

        if (Request.Browser.Type.ToUpper().Contains("IE")) // replace with your check
        {
            if (Request.Browser.MajorVersion < 8)
            {
                return true;
            }
        }
        return false;
    }
    private void DisplayOkazion()
    {
        var obj = dc.Amlak_Porofiles.FirstOrDefault();
        if (obj == null)
        {

            return;
        }

        hflatlng.Value = obj.Lat + "," + obj.lng;

        List<TempOkazion> lsttmp = new List<TempOkazion>();
        int i = 0;
        foreach (var p in dc.Maskans.Where(s => s.IsOkazion == true && s.IsDeleted == false).OrderBy(s => s.Priority).Take(9))
        {
            TempOkazion tmp = new TempOkazion();
            tmp.class_OkazionTEXT = "M_DivOkazionTextNOSelect";
            tmp.clientclickEtelaatBishtar = "ShowInfoModelDialog('" + ((p.lat != null && p.lng != null && p.lng.Trim() != "" && p.lat.Trim() != "") ? "true" : "false") + "','" + (p.lat == null ? "" : p.lat) + "','" + (p.lng == null ? "" : p.lng) + "','" + (p.MaskanImages.Any() ? "true" : "false") + "','" + p.Id + "','SITE','" + ((p.AxShahrdari == null || p.AxShahrdari.Trim() == "") ? "" : (ImagePath + p.AxShahrdari)) + "',this); return false;";
            tmp.clientclickOkazion = "changeOkazion('" + i + "');" + " " + (IsBrowserIEVersoinLower8() ? "" : (" SetMArkerOkazion('" + p.lat + "','" + p.lng + "'); ")) + " return false;";
            tmp.CSSOkazionName = "M_BtnOkazionStyleNOSELECT";

            tmp.Dsc_Okazion = p.Dsc_Okazion;
            tmp.hfNameIDValue = i.ToString();
            tmp.hfNameOkazionIDValue = i.ToString();
            tmp.NameOkazion = p.Title_Okaziom;
            lsttmp.Add(tmp);
            i++;
        }

        var lst = from p in lsttmp
                  select new
                  {
                      p.NameOkazion,
                      p.hfNameOkazionIDValue,
                      p.hfNameIDValue,
                      p.Dsc_Okazion,
                      p.CSSOkazionName,
                      p.clientclickOkazion,
                      p.clientclickEtelaatBishtar,
                      p.class_OkazionTEXT
                  };
        LstOkazionName.DataSource = lst;
        LstOkazionName.DataBind();
        DataListOkazionInfo.DataSource = lst;
        DataListOkazionInfo.DataBind();
        hfvalueOfOkazion.Value = lst.Count().ToString();
    }
    private void Print()
    {
        int NoeMameleId = int.Parse("0" + hfNoeMameleValueID.Value);
        NoeMameleId = NoeMameleId == 0 ? 1 : NoeMameleId;
        int NoeMelkId = int.Parse("0" + hfNoeMelk_MELKValueID.Value);
        string _GROUPTYPE = NoeMelkId == 0 ? "MELK" : dc.NoeMelks.SingleOrDefault(s => s.Id == NoeMelkId).GROUPTYPE.ToUpper();//hfNoeMelk_MELKName.Value.Split(',')[2].Trim().ToUpper();


        List<int> lstTedadKhabId = new List<int>();
        foreach (string row in hfTedadKhabValueID.Value.Split(','))
        {
            if (row != null && row.Trim() != "")
                lstTedadKhabId.Add(int.Parse(row));
        }

        List<int> lstKarbaiId = new List<int>();
        foreach (string row in hfNoeKarbariID.Value.Split(','))
        {
            if (row != null && row.Trim() != "")
                lstKarbaiId.Add(int.Parse(row));
        }

        string _printType = "";


        if (NoeMameleId == 1 && (_GROUPTYPE == "MELK"))
        {
            _printType = "RAHNVAEJARE";
        }
        else if (NoeMameleId == 1 && (_GROUPTYPE == "ZAMIN"))
        {
            _printType = "KHARIDVAFOROSHZAMIN";
        }
        else if ((NoeMameleId == 2 || NoeMameleId == 3) && (_GROUPTYPE == "MELK"))
        {
            _printType = "KHARIDVAFOROSHMELK";
        }
        else if ((NoeMameleId == 2 || NoeMameleId == 3) && (_GROUPTYPE == "ZAMIN"))
        {
            _printType = "KHARIDVAFOROSHZAMIN";
        }

        decimal dtmo = 0;
        decimal? MetrazhAz = !decimal.TryParse(hfMetrazh.Value.Split(';')[0].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;
        decimal? MetrazhTa = !decimal.TryParse(hfMetrazh.Value.Split(';')[1].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;

        decimal? Rahnaz = !decimal.TryParse(hfRahn.Value.Split(';')[0].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;
        decimal? RahnTa = !decimal.TryParse(hfRahn.Value.Split(';')[1].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;

        decimal? EjareAz = !decimal.TryParse(hfEjare.Value.Split(';')[0].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;
        decimal? EjareTa = !decimal.TryParse(hfEjare.Value.Split(';')[1].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;

        decimal? GhymatAz = !decimal.TryParse(hfGhymat.Value.Split(';')[0].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;
        decimal? GhymatTa = !decimal.TryParse(hfGhymat.Value.Split(';')[1].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;


        var Query = (from p in dc.Maskans
                     where
                     p.IsDeleted == false
                     &&
                     p.ShowInList==true
                     &&
                     p.IsParvandeMaskanBePayanResideAst == false
                     &&
                     p.NoeMoavezeId != null
                     &&
                     (
                       (p.NoeMoavezeId == NoeMameleId)
                     )
                     &&
                     p.NoeMelkId != null && p.NoeMelk.GROUPTYPE == _GROUPTYPE
                     &&
                     (NoeMelkId == 0 || (p.NoeMelkId != null && NoeMelkId == p.NoeMelkId.Value))


                     &&
                     (MetrazhAz == null || (p.Metrazh != null && p.Metrazh.Value >= MetrazhAz))
                     &&
                     (MetrazhTa == null || (p.Metrazh != null && (p.Metrazh.Value <= MetrazhTa)))
                     &&
                     (
                         (_GROUPTYPE == "ZAMIN"
                         &&
                         (lstKarbaiId.Count == 0 || p.MaskanNoeKarbaris.Any(s => lstKarbaiId.Contains(s.NoeKarbariId)))
                         )
                         ||
                         (
                         _GROUPTYPE == "MELK"
                         &&
                         (lstTedadKhabId.Count == 0 || (p.TedadKhabId != null && lstTedadKhabId.Contains(p.TedadKhabId.Value)))
                         )
                     )
                     &&
                     (
                          (
                              NoeMameleId == 1
                              &&

                              (EjareAz == null || (p.Mablagh_Ejare != null && p.Mablagh_Ejare.Value >= (EjareAz)))
                              &&
                              (EjareTa == null || (p.Mablagh_Ejare != null && p.Mablagh_Ejare.Value <= EjareTa))
                              &&
                              (Rahnaz == null || (p.Mablagh_Rahn != null && p.Mablagh_Rahn.Value >= Rahnaz))
                              &&
                              (RahnTa == null || (p.Mablagh_Rahn != null && p.Mablagh_Rahn.Value <= RahnTa))
                          )
                          ||
                          (
                              NoeMameleId != 1
                              &&
                              (GhymatAz == null || (p.Ghymat != null && p.Ghymat.Value >= GhymatAz))
                              &&
                              (GhymatTa == null || (p.Ghymat != null && p.Ghymat.Value <= GhymatTa))
                          )
                     )
                     select new
                     {
                         p.Id,
                         Code = p.code,
                         NoeMelkName = p.NoeMelkId == null ? "" : p.NoeMelk.Name,
                         TedadKhab = p.TedadKhabId == null ? "" : p.TedadKhab.Name,
                         Tabghe = p.TabghaeForoshiId == null ? "" : p.Tabghe.Name,
                         Metrazh = p.Metrazh,
                         Ejare = p.Mablagh_Ejare,
                         Rahn = p.Mablagh_Rahn,
                         Ghymat = p.Ghymat,
                         DarbAz = p.DarbAzId == null ? "" : p.DarbAz.Name,
                         Vam = p.Vam,
                         p.DateSabt_English,
                         makan = p.MakanId == null ? "" : p.Makan.Name,
                         p.LittleAddress_Baray_Namayesh_Dar_Site,
                         Dsc = p.Dsc == null ? "" : p.Dsc,
                         mantaghe = (p.MantagheId == null ? "" : p.Mantaghe.Name),
                         Karbari = p.MaskanNoeKarbaris.Select(s => s.NoeKarbari.Name),
                         Details = "ShowInfoModelDialog('" + ((p.lat != null && p.lng != null && p.lng.Trim() != "" && p.lat.Trim() != "") ? "true" : "false") + "','" + (p.lat == null ? "" : p.lat) + "','" + (p.lng == null ? "" : p.lng) + "','" + (p.MaskanImages.Any() ? "true" : "false") + "','" + p.Id + "','SITE','" + ((p.AxShahrdari == null || p.AxShahrdari.Trim() == "") ? "" : (ImagePath + p.AxShahrdari)) + "',this); return false;",
                     }).OrderByDescending(s => s.DateSabt_English).ToList();


        var queryprint = (from p in Query
                          select new
                          {
                              p.Id,
                              p.Code,
                              p.DateSabt_English,
                              p.NoeMelkName,
                              p.TedadKhab,
                              p.Tabghe,
                              Metrazh = p.Metrazh == null ? "" : p.Metrazh.Value.ToString("###,###"),
                              Ejare = p.Ejare == null ? "" : p.Ejare.Value.ToString("###,###"),
                              Rahn = p.Rahn == null ? "" : p.Rahn.Value.ToString("###,###"),
                              Ghymat = p.Ghymat == null ? "" : p.Ghymat.Value.ToString("###,###"),
                              Vam = p.Vam == null ? "" : p.Vam.Value.ToString("###,###"),
                              mantaghe = _GROUPTYPE == "ZAMIN" ? (p.makan + (p.mantaghe == "" ? "" : (" - " + p.mantaghe))) : ((p.LittleAddress_Baray_Namayesh_Dar_Site == null ? "" : p.LittleAddress_Baray_Namayesh_Dar_Site)),
                              p.Details,
                              Karbari = (p.Karbari == null || !p.Karbari.Any()) ? "" : p.Karbari.Aggregate((a, b) => a + ", " + b).ToString(),
                              Address = _GROUPTYPE == "ZAMIN" ? (p.makan + (p.mantaghe == "" ? "" : (" - " + p.mantaghe))) : ((p.LittleAddress_Baray_Namayesh_Dar_Site == null ? "" : p.LittleAddress_Baray_Namayesh_Dar_Site)),
                              Dsc = p.Dsc,
                              NoeMelk = p.NoeMelkName,
                              Khab = p.TedadKhab,
                              Tabaghe = p.Tabghe,
                              DarbAz = p.DarbAz,
                              NoeKarbari = (p.Karbari == null || !p.Karbari.Any()) ? "" : p.Karbari.Aggregate((a, b) => a + ", " + b).ToString(),
                          }).OrderByDescending(s => s.DateSabt_English).ToList();
        string RptName = "";

        if (_printType == "KHARIDVAFOROSHZAMIN")
            RptName = "\\KharidVaForoshZamin.mrt";
        else if (_printType == "KHARIDVAFOROSHMELK")
            RptName = "\\KharidVaForoshKhune.mrt";
        else if (_printType == "RAHNVAEJARE")
            RptName = "\\RahnVaEjare.mrt";

        string ReportDate = DateShamsi.GetCurrentDate();
        string ReportTime = DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second;

        Stimulsoft.Report.StiReport rpt = new Stimulsoft.Report.StiReport();
        rpt.Load(HttpContext.Current.Server.MapPath("~\\ReportFiles" + RptName));


        var profile = dc.Amlak_Porofiles.FirstOrDefault();
        rpt.Dictionary.Variables["DateReport"].Value = ReportDate;
        rpt.Dictionary.Variables["Address"].Value = profile.Address;
        rpt.Dictionary.Variables["TEL"].Value = profile.Tel;
        rpt.RegData("ds", queryprint);

        rpt.Render();
        System.IO.MemoryStream ms = new System.IO.MemoryStream();
        rpt.ExportDocument(Stimulsoft.Report.StiExportFormat.Pdf, ms);
        //rpt.Print(true);
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.ContentType = "application/pdf";
        HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=Report." + "pdf");
        HttpContext.Current.Response.BinaryWrite(ms.ToArray());
        HttpContext.Current.Response.End();
    }
    private void Display()
    {
        var obj = dc.Amlak_Porofiles.FirstOrDefault();
        if (obj == null)
        {
            Div_AdressMa_Cantainer.Style.Add("display", "none");
            return;
        }

        hflatlng.Value = obj.Lat + "," + obj.lng;

        if ((obj.Address == null || obj.Address.Trim() == "")
            && (obj.Email == null || obj.Email.Trim() == "")
            && (obj.Tel == null || obj.Tel.Trim() == "")
            && (obj.Fax == null || obj.Fax.Trim() == "")
            )
        {
            Div_AdressMa_Cantainer.Style.Add("display", "none");
            return;
        }

        Div_lblAdr.InnerHtml = obj.Address;
        Div_lblFax.InnerHtml = obj.Fax;
        Div_lblTel.InnerHtml = obj.Tel;
        Div_lblEmail.InnerHtml = obj.Email;

        if (obj.Address == null || obj.Address.Trim() == "")
            DivAdr.Visible = false;
        if (obj.Email == null || obj.Email.Trim() == "")
            DivEmail.Visible = false;
        if (obj.Tel == null || obj.Tel.Trim() == "")
            DivTel.Visible = false;
        if (obj.Fax == null || obj.Fax.Trim() == "")
            DivFax.Visible = false;


    }
    private void bindCambo()
    {

        var ds_NoeMelks = (from p in dc.NoeMelks.OrderBy(s => s.priority)

                           select new
                           {
                               p.Id,
                               p.Name,
                               script = p.GROUPTYPE == "MELK" ? ("SelectItemCamboBox('" + p.Name + "," + p.Id.ToString() + "," + p.GROUPTYPE + "','lblNoeMelkName','hfNoeMelk_MELKName','btnNoeMelk', 'Div_NoeMelkBox','true');camboDisplay('hfNoeMelk_MELKName'); " + " return false;")
                               : ("if(SelectItemCamboBox('" + p.Name + "," + p.Id.ToString() + "," + p.GROUPTYPE + "','lblNoeMelkName','hfNoeMelk_MELKName','btnNoeMelk', 'Div_NoeMelkBox','true'))" + ("{ btnrefreshListNoeKarbariClick('" + btnrefreshListNoeKarbari.ClientID + "'); }") + "camboDisplay('hfNoeMelk_MELKName'); return false;"),
                               Value = false,

                           }).ToList();
        var melk = dc.NoeMelks.OrderBy(s => s.Id).First();
        hf_Defualt_MelkNameValue.Value = hfNoeMelk_MELKName.Value = melk.Name + "," + melk.Id + "," + melk.GROUPTYPE;
        lstboxNoeMelk.DataSource = ds_NoeMelks;
        lstboxNoeMelk.DataBind();
        ds_NoeMelks.Insert(0, new { Id = 0, Name = "همه موارد", script = ("SelectItemCamboBox('" + "همه موارد" + "," + "0" + "," + "MELK" + "','lblNoeMelkName','hfNoeMelk_MELKName','btnNoeMelk', 'Div_NoeMelkBox','true');camboDisplay('hfNoeMelk_MELKName'); " + " return false;"), Value = false });

        hfNoeMelk_MELKName.Value = "همه موارد" + "," + "0" + "," + "MELK";
        lstboxNoeMelk_RAHNVAEJARE.DataSource = ds_NoeMelks;
        lstboxNoeMelk_RAHNVAEJARE.DataBind();

        var ds_NoeMamele = (from p in dc.NoeMoavezes.OrderBy(s => s.priority)

                            select new
                            {
                                p.Id,
                                p.Name,
                                script = "SelectItemCamboBox('" + p.Name + "," + p.Id.ToString() + "','lblNoeMameleName','hfNoeMameleName','btnNoeMamele', 'Div_NoeMameleBox');sliderDisplay('hfNoeMameleName');ShowAllinRahnVaEjare();return false;",
                                Value = false,
                            }).ToList();
        var moamele = dc.NoeMoavezes.OrderBy(s => s.Id).First();
        hfNoeMameleName.Value = moamele.Name + "," + moamele.Id;
        lstboxNoeMamele.DataSource = ds_NoeMamele;
        lstboxNoeMamele.DataBind();


        var ds_darkhastmaskan = (from p in dc.NoeDarkhasts.OrderBy(s => s.priority)

                                 select new
                                 {
                                     Id = p.id,
                                     p.Name,
                                     script = "SelectItemCamboBox('" + p.Name + "," + p.id.ToString() + "','lbl_DarkhastMaska','hfDarkhastMaskanMozoValue','btn_DarkhastMaskan', 'Div_DarkhastMaskanBox');return false;",
                                     Value = false,
                                 }).ToList();

        hfDarkhastMaskanMozoValue.Value = "موضوع ...,";
        lstbox_DarkhastMaska.DataSource = ds_darkhastmaskan;
        lstbox_DarkhastMaska.DataBind();




        var ds_TedadKhabs = (from p in dc.TedadKhabs.OrderBy(s => s.priority)
                             select new
                             {
                                 Id = p.id,
                                 p.Name,
                                 script = "SetDropDownId(this,'" + p.id + "','hfTedadKhabValue');ChangeDropDownLabel(this,'" + p.Name + ", ','lblTedadKhabName','hfTedadKhabName');",
                                 Value = false,
                             }).ToList();
        hfTedadKhabName.Value = ds_TedadKhabs.Any(s => s.Value) ? (ds_TedadKhabs.Where(s => s.Value).Select(s => s.Name).Aggregate((a, b) => a + ", " + b) + ",") : "";
        hfTedadKhabValue.Value = ds_TedadKhabs.Any(s => s.Value) ? (ds_TedadKhabs.Where(s => s.Value).Select(s => s.Id.ToString()).Aggregate((a, b) => a + "," + b) + ",") : "";
        lstboxTedadKhab.DataSource = ds_TedadKhabs;
        lstboxTedadKhab.DataBind();



    }
    private object BindKamboNoKarbari()
    {
        string Id = hfNoeMelk_MELKName.Value.Split(',')[1];

        var ds_Noekarbari = (from p in dc.NoeKarbaris.OrderBy(s => s.priority)
                             where
                             p.NeMelkId.ToString() == Id
                             select new
                             {
                                 Id = p.Id,
                                 p.Name,
                                 script = "SetDropDownId(this,'" + p.Id + "','HfNoekarabariValue');ChangeDropDownLabel(this,'" + p.Name + ", ','lblNoeKarbariName_Zamin','hfNoekarbariName');",
                                 Value = false,
                             }).ToList();
        hfNoekarbariName.Value = ds_Noekarbari.Any(s => s.Value) ? (ds_Noekarbari.Where(s => s.Value).Select(s => s.Name).Aggregate((a, b) => a + ", " + b) + ",") : "";
        HfNoekarabariValue.Value = ds_Noekarbari.Any(s => s.Value) ? (ds_Noekarbari.Where(s => s.Value).Select(s => s.Id.ToString()).Aggregate((a, b) => a + "," + b) + ",") : "";
        return ds_Noekarbari;

    }
    private void Save()
    {
        var obj = new DarkhastMaskan();
        obj.UID = Guid.NewGuid();
        obj.TelFrestande = txtShomareTel_Darkhast.Text.Trim() == "شماره تماس ..." ? "" : txtShomareTel_Darkhast.Text.Trim();
        obj.EmailFrestande = txtEmail_Darkhast.Text.Trim() == "پست الکترونیکی ..." ? "" : txtEmail_Darkhast.Text.Trim();
        obj.NameFrestande = txtName_Darkhast.Text.Trim() == "نام و نام خانوادگی ..." ? "" : txtName_Darkhast.Text.Trim();
        obj.Dsc_Darkhast = txtDsc_Darkhast.Text.Trim() == "پیام ..." ? "" : txtDsc_Darkhast.Text.Trim();
        obj.DateErsal = DateShamsi.GetCurrentDate();
        obj.TimeErsal = DateShamsi.GetCurrentHour();
        obj.NoeDarkhast = dc.NoeDarkhasts.SingleOrDefault(s => s.id.ToString() == hfDarkhastMaskanMozoValue.Value.Split(',')[1]);
        obj.DateTimeErsal = DateTime.Now;
        obj.IsDeleted = false;
        obj.IsRead = false;

        dc.DarkhastMaskans.InsertOnSubmit(obj);
        dc.SubmitChanges();
    }
    private bool CheckValidate()
    {
        bool result = true;
        string Msg = "لطفا به نکات زیر توجه نمایید :" + "</br>";
        int i = 0;
        if (txtName_Darkhast.Text.Trim() == "نام و نام خانوادگی ..." || txtName_Darkhast.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام و نام خانوادگی را وارد نمایید." + "</br>";
        }
        if (!Validation.IsEmail(txtEmail_Darkhast.Text.Trim()))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "پست الکترونیکی را وارد نمایید." + "</br>";
        }
        if (!dc.NoeDarkhasts.Any(s => s.id.ToString() == hfDarkhastMaskanMozoValue.Value.Split(',')[1]))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "موضوع را انتخاب نمایید." + "</br>";
        }
        if (txtDsc_Darkhast.Text.Trim() == "پیام ..." || txtDsc_Darkhast.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "پیام خود را وارد نمایید." + "</br>";
        }
        if (!result)
        {
            string message = "progressclose();ShowErrorMessage('" + Msg + "');";
            ScriptManager.RegisterClientScriptBlock(btnImgSend, this.GetType(), "alert", message, true);
        }
        return result;
    }

    [System.Web.Services.WebMethod]
    public static string LoadItem(string skape, string nemoameleid, string noemelkid, string tedadkhabid, string noekarbariid, string metrazh, string rahn, string ejare, string ghymat)
    {
        dbMaskanDataContext dc = new dbMaskanDataContext();
        int tmp = 0;
        int skypecount = int.TryParse("0" + skape, out tmp) == false ? 0 : int.Parse("0" + skape);

        int NoeMameleId = int.Parse("0" + nemoameleid);
        NoeMameleId = NoeMameleId == 0 ? 1 : NoeMameleId;
        int NoeMelkId = int.Parse("0" + noemelkid);
        string _GROUPTYPE = NoeMelkId == 0 ? "MELK" : dc.NoeMelks.SingleOrDefault(s => s.Id == NoeMelkId).GROUPTYPE.ToUpper();//hfNoeMelk_MELKName.Value.Split(',')[2].Trim().ToUpper();


        List<int> lstTedadKhabId = new List<int>();
        foreach (string row in tedadkhabid.Split(','))
        {
            if (row != null && row.Trim() != "")
                lstTedadKhabId.Add(int.Parse(row));
        }

        List<int> lstKarbaiId = new List<int>();
        foreach (string row in noekarbariid.Split(','))
        {
            if (row != null && row.Trim() != "")
                lstKarbaiId.Add(int.Parse(row));
        }

        decimal dtmo = 0;
        decimal? MetrazhAz = !decimal.TryParse(metrazh.Split(';')[0].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;
        decimal? MetrazhTa = !decimal.TryParse(metrazh.Split(';')[1].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;

        decimal? Rahnaz = !decimal.TryParse(rahn.Split(';')[0].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;
        decimal? RahnTa = !decimal.TryParse(rahn.Split(';')[1].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;

        decimal? EjareAz = !decimal.TryParse(ejare.Split(';')[0].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;
        decimal? EjareTa = !decimal.TryParse(ejare.Split(';')[1].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;

        decimal? GhymatAz = !decimal.TryParse(ghymat.Split(';')[0].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;
        decimal? GhymatTa = !decimal.TryParse(ghymat.Split(';')[1].Replace(",", "").Replace("،", "").Replace(".", "").Trim(), out dtmo) ? (decimal?)null : dtmo;


        var Query = (from p in dc.Maskans
                     where
                     p.IsDeleted == false
                     &&
                     p.ShowInList == true
                     &&
                     p.IsParvandeMaskanBePayanResideAst == false
                     &&
                     p.NoeMoavezeId != null
                     &&
                     (
                       (p.NoeMoavezeId == NoeMameleId)
                     )
                     &&
                     p.NoeMelkId != null && p.NoeMelk.GROUPTYPE == _GROUPTYPE
                     &&
                     (NoeMelkId == 0 || (p.NoeMelkId != null && NoeMelkId == p.NoeMelkId.Value))


                     &&
                     (MetrazhAz == null || (p.Metrazh != null && p.Metrazh.Value >= MetrazhAz))
                     &&
                     (MetrazhTa == null || (p.Metrazh != null && (p.Metrazh.Value <= MetrazhTa)))
                     &&
                     (
                         (_GROUPTYPE == "ZAMIN"
                         &&
                         (lstKarbaiId.Count == 0 || p.MaskanNoeKarbaris.Any(s => lstKarbaiId.Contains(s.NoeKarbariId)))
                         )
                         ||
                         (
                         _GROUPTYPE == "MELK"
                         &&
                         (lstTedadKhabId.Count == 0 || (p.TedadKhabId != null && lstTedadKhabId.Contains(p.TedadKhabId.Value)))
                         )
                     )
                     &&
                     (
                          (
                              NoeMameleId == 1
                              &&

                              (EjareAz == null || (p.Mablagh_Ejare != null && p.Mablagh_Ejare.Value >= (EjareAz)))
                              &&
                              (EjareTa == null || (p.Mablagh_Ejare != null && p.Mablagh_Ejare.Value <= EjareTa))
                              &&
                              (Rahnaz == null || (p.Mablagh_Rahn != null && p.Mablagh_Rahn.Value >= Rahnaz))
                              &&
                              (RahnTa == null || (p.Mablagh_Rahn != null && p.Mablagh_Rahn.Value <= RahnTa))
                          )
                          ||
                          (
                              NoeMameleId != 1
                              &&
                              (GhymatAz == null || (p.Ghymat != null && p.Ghymat.Value >= GhymatAz))
                              &&
                              (GhymatTa == null || (p.Ghymat != null && p.Ghymat.Value <= GhymatTa))
                          )
                     )
                     select new
                     {
                         p.Id,
                         Code = p.code,
                         NoeMelkName = p.NoeMelkId == null ? "" : p.NoeMelk.Name,
                         TedadKhab = p.TedadKhabId == null ? "" : p.TedadKhab.Name,
                         Tabghe = p.TabghaeForoshiId == null ? "" : p.Tabghe.Name,
                         Metrazh = p.Metrazh,
                         Ejare = p.Mablagh_Ejare,
                         Rahn = p.Mablagh_Rahn,
                         Ghymat = p.Ghymat,
                         DarbAz = p.DarbAzId == null ? "" : p.DarbAz.Name,
                         Vam = p.Vam,
                         p.DateSabt_English,
                         makan = p.MakanId == null ? "" : p.Makan.Name,
                         p.LittleAddress_Baray_Namayesh_Dar_Site,
                         Dsc = p.Dsc == null ? "" : p.Dsc,
                         mantaghe = (p.MantagheId == null ? "" : p.Mantaghe.Name),
                         Karbari = p.MaskanNoeKarbaris.Select(s => s.NoeKarbari.Name),
                         Details = "ShowInfoModelDialog('" + ((p.lat != null && p.lng != null && p.lng.Trim() != "" && p.lat.Trim() != "") ? "true" : "false") + "','" + (p.lat == null ? "" : p.lat) + "','" + (p.lng == null ? "" : p.lng) + "','" + (p.MaskanImages.Any() ? "true" : "false") + "','" + p.Id + "','SITE','" + ((p.AxShahrdari == null || p.AxShahrdari.Trim() == "") ? "" : (ImagePath + p.AxShahrdari)) + "',this); return false;",
                     }).OrderByDescending(s => s.DateSabt_English).ToList();


        var Query1 = (from p in Query
                      select new
                      {
                          p.Id,
                          p.Code,
                          p.DateSabt_English,
                          p.NoeMelkName,
                          p.TedadKhab,
                          p.Tabghe,
                          Metrazh = p.Metrazh == null ? "" : p.Metrazh.Value.ToString("###,###"),
                          Ejare = p.Ejare == null ? "" : p.Ejare.Value.ToString("###,###"),
                          Rahn = p.Rahn == null ? "" : p.Rahn.Value.ToString("###,###"),
                          Ghymat = p.Ghymat == null ? "" : p.Ghymat.Value.ToString("###,###"),
                          Vam = p.Vam == null ? "" : p.Vam.Value.ToString("###,###"),
                          mantaghe = _GROUPTYPE == "ZAMIN" ? (p.makan + (p.mantaghe == "" ? "" : (" - " + p.mantaghe))) : ((p.LittleAddress_Baray_Namayesh_Dar_Site == null ? "" : p.LittleAddress_Baray_Namayesh_Dar_Site)),
                          p.Details,
                          Karbari = (p.Karbari == null || !p.Karbari.Any()) ? "" : p.Karbari.Aggregate((a, b) => a + ", " + b).ToString(),
                          Address = _GROUPTYPE == "ZAMIN" ? (p.makan + (p.mantaghe == "" ? "" : (" - " + p.mantaghe))) : ((p.LittleAddress_Baray_Namayesh_Dar_Site == null ? "" : p.LittleAddress_Baray_Namayesh_Dar_Site)),
                          Dsc = p.Dsc,
                          NoeMelk = p.NoeMelkName,
                          Khab = p.TedadKhab,
                          Tabaghe = p.Tabghe,
                          DarbAz = p.DarbAz,
                          NoeKarbari = (p.Karbari == null || !p.Karbari.Any()) ? "" : p.Karbari.Aggregate((a, b) => a + ", " + b).ToString(),
                      }).OrderByDescending(s => s.DateSabt_English).ToList();


        int count_obj = Query.Count();
        var Query2 = Query1.Skip(skypecount * 20).Take(20);
        string HTML_ = (count_obj == 0 ? " هیچ رکوردی یافت نشده است" : (count_obj + " رکورد یافت شده است")) + ";";
        foreach (var item in Query2)
        {
            HTML_ += " <div style=\"clear: both; height: 4px; line-height: 1px; background-color: #a93036\"></div> "
                  + "     <div class=\"Div_Label\" style=\"font-size: 14px; margin-right: 15px; padding-left: 15px; margin-top: 20px; color: black; text-align: justify; line-height: 23px\">  ";
            HTML_ += item.NoeMelk == "" ? "" : (item.NoeMelk + " ، ");
            HTML_ += item.mantaghe == "" ? "" : (item.mantaghe + " ، ");
            HTML_ += item.mantaghe == "" ? "" : (item.Metrazh + " مترمربع ، ");
            if (NoeMameleId == 1 && (_GROUPTYPE == "MELK"))
            {
                HTML_ += item.TedadKhab == "" ? "" : (item.TedadKhab + " ، ");
                HTML_ += item.Tabaghe == "" ? "" : ("طبقه " + item.Tabaghe + " ، ");
                HTML_ += item.Rahn == "" ? "" : ("رهن " + item.Rahn + " میلیون تومان ، ");
                HTML_ += item.Ejare == "" ? "" : ("اجاره " + item.Ejare + " تومان ، ");


            }
            else if (NoeMameleId == 1 && (_GROUPTYPE == "ZAMIN"))
            {
                HTML_ += item.Karbari == "" ? "" : ("نوع کاربری " + item.Karbari + " ، ");
                HTML_ += item.Rahn == "" ? "" : ("رهن " + item.Rahn + " میلیون تومان ، ");
                HTML_ += item.Ejare == "" ? "" : ("اجاره " + item.Ejare + " تومان ، ");
            }
            else if ((NoeMameleId == 2 || NoeMameleId == 3) && (_GROUPTYPE == "MELK"))
            {
                HTML_ += item.TedadKhab == "" ? "" : (item.TedadKhab + " ، ");
                HTML_ += item.Tabaghe == "" ? "" : ("طبقه " + item.Tabaghe + " ، ");
                HTML_ += item.Ghymat == "" ? "" : ("قیمت " + item.Ghymat + " تومان ، ");
            }
            else if ((NoeMameleId == 2 || NoeMameleId == 3) && (_GROUPTYPE == "ZAMIN"))
            {
                HTML_ += item.Karbari == "" ? "" : ("نوع کاربری " + item.Karbari + " ، ");
                HTML_ += item.Ghymat == "" ? "" : ("قیمت " + item.Ghymat + " تومان ، ");
            }

            HTML_ += "     </div> "
            + "     <div style=\"clear: both; height: 1px; line-height: 1px;\"></div>  "
            + "     <div class=\"Div_Label\" style=\"font-size: 14px; margin-right: 15px; width: 100%; color: black; text-align: justify; line-height: 23px\">  "
            + "         کد : " + item.Code + "  <span style=\"float: left; margin-left: 30px\"><a herf=\"#\" style=\"cursor:pointer;color:#5a69c1\" id=\"detail" + Guid.NewGuid().ToString().Replace("-", "_") + "\" onclick=\"" + item.Details + "\">اطلاعات بیشتر ...</a></span> "
            + "     </div> "
            + "     <div style=\"clear: both; height: 10px; line-height: 1px;\"></div> ";
        }



        return HTML_;
        //int count_obj = Query1.Count();
        //ScriptManager.RegisterStartupScript(gvResult,
        //                    this.GetType(),
        //                     "alert",
        //                     "progressclose();gvtest(" + count_obj.ToString() + "); ",
        //                     true);




        //if (IsPostBack)
        //    ScriptManager.RegisterClientScriptBlock(btnImgSend, this.GetType(), "alert", "SetScroll(610);", true);

        //if (NoeMameleId == (int)DataValueIds.NoeMoavezeIds.RahnVaEjare)
        //    return Query1.OrderByDescending(s => s.DateSabt_English);
        //return Query1.OrderByDescending(s => s.DateSabt_English);


    }



}