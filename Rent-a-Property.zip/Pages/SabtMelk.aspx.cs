﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Pages_SabtMelk : System.Web.UI.Page
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        litscript.Text = "";
        if (!IsPostBack)
        {
            string status = ArssPayamUtility.GetQueryString("status", Request.QueryString["args"]);
            if (status == "ok")
                litscript.Text = "<script> ShowSeccessMessage('" + "اطلاعات وارد شده با موفقیت ثبت گردید.<br/>پس از تایید اطلاعات توسط مدیر سیستم ملک شما در سیستم نمایش داده می شود.<br/>با تشکر از انتخاب شما" + "'); </script>";
        }
        setLatlng();
    }


    private void setLatlng()
    {
        txtlat.Text = hflatlng.Value.Split(',')[0];
        txtlng.Text = hflatlng.Value.Split(',')[1];
    }
    [System.Web.Services.WebMethod]
    public static string BindNoeMoameleItems(string Value)
    {

        dbMaskanDataContext dc = new dbMaskanDataContext();
        var objs = dc.NoeMoavezes.Where(s => s.IsDelete == false).OrderBy(s => s.priority);
        if (objs.Any() == false)
            return "";

        int i = 1;
        string record = "";
        string name = "انتخاب کنید ...";
        foreach (var obj in objs)
        {
            record += " <li> "
                + "  <input type=\"radio\" onchange=\"SetvalueTohf_NoeMoamele(this, '" + obj.Id + "', 'hf_noemameleValue')\"  id=\"IDNoeMoaveze" + (i++) + "\" " + (obj.Id.ToString() == Value ? ("checked=\"checked\"") : "") + " name=\"NAME\" value=\"" + obj.Id + "\"><label for=\"IDNoeMoaveze" + (i - 1) + "\">" + obj.Name + "</label></li>";
            if (obj.Id.ToString() == Value)
                name = obj.Name;
        }

        return name + "@;_" + record;
    }

    [System.Web.Services.WebMethod]
    public static string BindNoeMelkItems(string Value, string valueNoeMamele)
    {
        string GTYPE = (valueNoeMamele == "1" || valueNoeMamele == "3") ? "MELK" : (valueNoeMamele == "2" ? "MELK_ZAMIN" : "");
        dbMaskanDataContext dc = new dbMaskanDataContext();
        var objs = dc.NoeMelks.Where(s => s.IsDelete == false && (GTYPE == "MELK_ZAMIN" || s.GROUPTYPE == GTYPE)).OrderBy(s => s.GROUPTYPE != "MELK").ThenBy(s => s.priority);

        int i = 1;
        string record = "";
        string name = "انتخاب کنید ...";
        if (valueNoeMamele != "")
            name = "انتخاب کنید ...";
        else
            name = "ابتدا نوع معامله را انتخاب نمایید...";
        foreach (var obj in objs)
        {
            record += " <li> "
                + "  <input type=\"radio\" onchange=\"SetvalueTohf_noeMelk(this, '" + (obj.Id + "_" + obj.GROUPTYPE.ToUpper()) + "', 'hf_NoeMelK');\"  id=\"IDNoeMelk" + (i++) + "\" " + (obj.Id.ToString() == Value.Split('_')[0] ? ("checked=\"checked\"") : "") + " name=\"NAME\" value=\"" + (obj.Id + "_" + obj.GROUPTYPE.ToUpper()) + "\"><label for=\"IDNoeMelk" + (i - 1) + "\">" + obj.Name + "</label></li>";
            if (obj.Id.ToString() == Value.Split('_')[0])
                name = obj.Name;
        }

        return name + "@;_" + record;
    }
    [System.Web.Services.WebMethod]
    public static string BindTedadKhabItems(string Value)
    {

        dbMaskanDataContext dc = new dbMaskanDataContext();
        var objs = dc.TedadKhabs.Where(s => s.IsDelete == false).OrderBy(s => s.priority);
        if (objs.Any() == false)
            return "";

        int i = 1;
        string record = "";
        string name = "انتخاب کنید ...";
        foreach (var obj in objs)
        {
            record += " <li> "
                + "  <input type=\"radio\" onchange=\"SetvalueTohf(this, '" + obj.id + "', 'hf_TedadKhab')\"  id=\"IDTedadKhab" + (i++) + "\" " + (obj.id.ToString() == Value ? ("checked=\"checked\"") : "") + " name=\"NAME\" value=\"" + obj.id + "\"><label for=\"IDTedadKhab" + (i - 1) + "\">" + obj.Name + "</label></li>";
            if (obj.id.ToString() == Value)
                name = obj.Name;
        }

        return name + "@;_" + record;
    }
    [System.Web.Services.WebMethod]
    public static string BindDarbAzItems(string Value)
    {

        dbMaskanDataContext dc = new dbMaskanDataContext();
        var objs = dc.DarbAzs.Where(s => s.IsDelete == false).OrderBy(s => s.priority);
        if (objs.Any() == false)
            return "";

        int i = 1;
        string record = "";
        string name = "انتخاب کنید ...";
        foreach (var obj in objs)
        {
            record += " <li> "
                + "  <input type=\"radio\" onchange=\"SetvalueTohf(this, '" + obj.Id + "', 'hf_DarbAz')\"  id=\"IDDarbAz" + (i++) + "\" " + (obj.Id.ToString() == Value ? ("checked=\"checked\"") : "") + " name=\"NAME\" value=\"" + obj.Id + "\"><label for=\"IDDarbAz" + (i - 1) + "\">" + obj.Name + "</label></li>";
            if (obj.Id.ToString() == Value)
                name = obj.Name;
        }

        return name + "@;_" + record;
    }
    [System.Web.Services.WebMethod]
    public static string BindTabagheEsteghrarItems(string Value)
    {

        dbMaskanDataContext dc = new dbMaskanDataContext();
        var objs = dc.Tabghes.Where(s => s.IsDelete == false).OrderBy(s => s.priority);
        if (objs.Any() == false)
            return "";

        int i = 1;
        string record = "";
        string name = "انتخاب کنید ...";
        foreach (var obj in objs)
        {
            record += " <li> "
                + "  <input type=\"radio\" onchange=\"SetvalueTohf(this, '" + obj.Id + "', 'hf_TabagheEsteghrar')\"  id=\"IDTabagheEsteghrar" + (i++) + "\" " + (obj.Id.ToString() == Value ? ("checked=\"checked\"") : "") + " name=\"NAME\" value=\"" + obj.Id + "\"><label for=\"IDTabagheEsteghrar" + (i - 1) + "\">" + obj.Name + "</label></li>";
            if (obj.Id.ToString() == Value)
                name = obj.Name;
        }

        return name + "@;_" + record;
    }
    [System.Web.Services.WebMethod]
    public static string BindMakanItems(string Value)
    {

        dbMaskanDataContext dc = new dbMaskanDataContext();
        var objs = dc.Makans.Where(s => s.IsDeleted == false).OrderBy(s => s.Priority);
        if (objs.Any() == false)
            return "";

        int i = 1;
        string record = "";
        string name = "انتخاب کنید ...";
        foreach (var obj in objs)
        {
            record += " <li> "
                + "  <input type=\"radio\" onchange=\"SetvalueTohf_Makan(this, '" + obj.Id + "', 'hf_Makan')\"  id=\"IDMakan" + (i++) + "\" " + (obj.Id.ToString() == Value ? ("checked=\"checked\"") : "") + " name=\"NAME\" value=\"" + obj.Id + "\"><label for=\"IDMakan" + (i - 1) + "\">" + obj.Name + "</label></li>";
            if (obj.Id.ToString() == Value)
                name = obj.Name;
        }

        return name + "@;_" + record;
    }
    [System.Web.Services.WebMethod]
    public static string BindMantagheItems(string Value, string valueMakan)
    {

        dbMaskanDataContext dc = new dbMaskanDataContext();
        var objs = dc.Mantaghes.Where(s => s.IsDeleted == false && (s.MakanId.ToString() == valueMakan)).OrderBy(s => s.priority).ThenBy(s => s.Name);

        int i = 1;
        string record = "";
        string name = "انتخاب کنید ...";
        if (valueMakan != "")
            name = "انتخاب کنید ...";
        else
            name = "ابتدا نوع مکان را انتخاب نمایید...";
        foreach (var obj in objs)
        {
            record += " <li> "
                + "  <input type=\"radio\" onchange=\"SetvalueTohf(this, '" + (obj.Id) + "', 'hf_Mantaghe')\"  id=\"IDMantaghe" + (i++) + "\" " + (obj.Id.ToString() == Value ? ("checked=\"checked\"") : "") + " name=\"NAME\" value=\"" + (obj.Id) + "\"><label for=\"IDMantaghe" + (i - 1) + "\">" + obj.Name + "</label></li>";
            if (obj.Id.ToString() == Value)
                name = obj.Name;
        }

        return name + "@;_" + record;
    }
    [System.Web.Services.WebMethod]
    public static string BindNoeKarbariItems(string Value, string valuenemelk)
    {
        string vale_noemelk = valuenemelk.Split('_')[0];
        dbMaskanDataContext dc = new dbMaskanDataContext();
        var objs = dc.NoeKarbaris.Where(s => s.IsDeleted == false && (s.NeMelkId.ToString() == vale_noemelk)).OrderBy(s => s.priority).ThenBy(s => s.Name);

        int i = 1;
        string record = "";
        string name = "";


        foreach (var obj in objs)
        {
            record += " <li> "
                + "  <input type=\"checkbox\" onchange=\"SetMultivalueTohf(this, '" + (obj.Id) + "', 'hf_NoeKarbari')\"  id=\"IDNoeKarbari" + (i++) + "\" " + (Value.Contains(obj.Id.ToString() + ", ") ? ("checked=\"checked\"") : "") + " name=\"NAME\" value=\"" + (obj.Id) + "\"><label for=\"IDNoeKarbari" + (i - 1) + "\">" + obj.Name + "</label></li>";
            if (Value.Contains(obj.Id.ToString() + ", "))
                name += obj.Name + ", ";
        }
        if (name == "")
            name = "انتخاب کنید ...";
        if (valuenemelk != "")
            name = "انتخاب کنید ...";
        else
            name = "ابتدا نوع ملک را انتخاب نمایید...";

        return name + "@;_" + record;
    }


    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (CheckValidate())
        {
            Save();
        }
    }

    private bool CheckValidate()
    {


        string Grope = "";

        string Msg = "لطفا به نکات زیر توجه نمایید:" + "<br/>";
        int i = 1;
        bool result = true;
        decimal Tmp = 0;

        if (txt_FullnameMalek.Text.Trim() == "")
        {
            Msg += (i++) + " - " + "نام و نام خانوادگی را وارد نمایید" + "<br/>";
            result = false;
        }
        if (txt_Tamas_Malek.Text.Trim() == "")
        {
            Msg += (i++) + " - " + "شماره تماس را وارد نمایید" + "<br/>";
            result = false;
        }
        if (hf_noemameleValue.Value.Trim() == "")
        {
            Msg += (i++) + " - " + "نوع معامله را انتخاب نمایید." + "<br/>";
            result = false;
        }
        if (hf_NoeMelK.Value.Trim() == "")
        {
            Msg += (i++) + " - " + "نوع ملک را انتخاب نمایید." + "<br/>";
            result = false;
        }
        else
            Grope = hf_NoeMelK.Value.Split('_')[1].ToUpper(); ;


        bool hasNoeKarbari = false;
        foreach (string row in hf_NoeKarbari.Value.Split(','))
        {
            if (row != null && row.Trim() != "")
            {
                hasNoeKarbari = true;
                break;
            }
        }
        if (hasNoeKarbari == false && Grope == "ZAMIN" && hf_noemameleValue.Value.Trim() == ((int)DataValueIds.NoeMoavezeIds.KharidVaForosh).ToString())
        {
            Msg += (++i).ToString() + " - " + "حداقل یک نوع کاربری را انتخاب نمایید." + "</br>";
            result = false;
        }
        if (hf_Makan.Value.Trim() == "" && Grope == "ZAMIN" && hf_noemameleValue.Value.Trim() == ((int)DataValueIds.NoeMoavezeIds.KharidVaForosh).ToString())
        {
            Msg += (i++) + " - " + "مکان را انتخاب نمایید." + "<br/>";
            result = false;
        }
        if (hf_noemameleValue.Value.Trim() != "" && hf_NoeMelK.Value.Trim() != "")
        {
            if (txtAddress.Text.Trim() == "")
            {
                Msg += (i++) + " - " + "آدرس را وارد نمایید" + "<br/>";
                result = false;
            }
        }
        if (!decimal.TryParse("0" + txtMetrazh.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "متراژ را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (hf_noemameleValue.Value.Trim() == ((int)DataValueIds.NoeMoavezeIds.RahnVaEjare).ToString())
        {
            if (!decimal.TryParse("0" + txttedadtabaghat.Text.Replace(",", "").Trim(), out Tmp))
            {
                Msg += (++i).ToString() + " - " + "تعداد طبقات ملک را صحیح وارد نمایید" + "</br>";
                result = false;
            }
            if (!decimal.TryParse("0" + txtRahn.Text.Replace(",", "").Trim(), out Tmp))
            {
                Msg += (++i).ToString() + " - " + "مبلغ رهن را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            if (!decimal.TryParse("0" + txtEjare.Text.Replace(",", "").Trim(), out Tmp))
            {
                Msg += (++i).ToString() + " - " + "مبلغ اجاره را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
        }
        if (hf_noemameleValue.Value.Trim() == ((int)DataValueIds.NoeMoavezeIds.KharidVaForosh).ToString() || hf_noemameleValue.Value.Trim() == ((int)DataValueIds.NoeMoavezeIds.PishForosh).ToString())
        {
            if (!decimal.TryParse("0" + txtghymat.Text.Replace(",", "").Trim(), out Tmp))
            {
                Msg += (++i).ToString() + " - " + "قیمت را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            if (Grope == "MELK")
            {
                if (!decimal.TryParse("0" + txtvam.Text.Replace(",", "").Trim(), out Tmp))
                {
                    Msg += (++i).ToString() + " - " + "وام را به صورت عددی و صحیح وارد نمایید." + "</br>";
                    result = false;
                }
            }
        }
        if (!result)
            litscript.Text = "<script> ShowErrorMessage(\"'\"" + Msg + "\"'\"); </script>";

        return result;
    }

    private void Save()
    {

        var obj = new Maskan();
        obj.DateSabt_English = DateTime.Now;
        obj.DateSabt_Persian = DateShamsi.GetCurrentDate();
        dc.Maskans.InsertOnSubmit(obj);
        obj.ShowInList = false;
        obj.IsAgahi = true;
        obj.IsAgahiRead = false;

        obj.IsParvandeMaskanBePayanResideAst = false;
        obj.DarbAz = dc.DarbAzs.SingleOrDefault(s => s.Id.ToString() == hf_DarbAz.Value);
        obj.Makan = dc.Makans.SingleOrDefault(s => s.Id.ToString() == hf_Makan.Value);
        int noemoavezeid = hf_noemameleValue.Value == "1" ? (int)DataValueIds.NoeMoavezeIds.RahnVaEjare : (hf_noemameleValue.Value == "2" ? (int)DataValueIds.NoeMoavezeIds.KharidVaForosh : (hf_noemameleValue.Value == "3" ? (int)DataValueIds.NoeMoavezeIds.PishForosh : (1)));
        obj.NoeMoaveze = dc.NoeMoavezes.SingleOrDefault(s => s.Id == noemoavezeid);
        obj.NoeMelk = dc.NoeMelks.SingleOrDefault(s => s.Id.ToString() == hf_NoeMelK.Value.Split('_')[0]);

        if (obj.NoeMelk != null && obj.NoeMelk.GROUPTYPE == "ZAMIN")
        {
            obj.Pelak = txtpelak.Text.Trim();
        }
        if (obj.NoeMelk != null && obj.NoeMelk.GROUPTYPE == "MELK")
        {
            obj.TedadKhab = dc.TedadKhabs.SingleOrDefault(s => s.id.ToString() == hf_TedadKhab.Value);
            obj.Tabghe = dc.Tabghes.SingleOrDefault(s => s.Id.ToString() == hf_TabagheEsteghrar.Value);
            obj.TedadTabaghat = txttedadtabaghat.Text.Replace(",", "").Trim() == "" ? (int?)null : int.Parse(txttedadtabaghat.Text.Replace(",", "").Trim());
            obj.Mablagh_Rahn = txtRahn.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtRahn.Text.Replace(",", "").Trim());
            obj.Mablagh_Ejare = txtEjare.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtEjare.Text.Replace(",", "").Trim());

        }
        obj.Metrazh = txtMetrazh.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtMetrazh.Text.Replace(",", "").Trim());


        obj.Mantaghe = dc.Mantaghes.SingleOrDefault(s => s.Id.ToString() == hf_Mantaghe.Value);

        obj.AddressKamel = txtAddress.Text.Trim();
        obj.lat = hflatlng.Value.Split(',')[0];
        obj.lng = hflnglng.Value.Split(',')[1];
        if (obj.NoeMoaveze != null)
        {
            if ((int)DataValueIds.NoeMoavezeIds.KharidVaForosh == obj.NoeMoaveze.Id || (int)DataValueIds.NoeMoavezeIds.PishForosh == obj.NoeMoaveze.Id)
            {
                obj.Ghymat = txtghymat.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtghymat.Text.Replace(",", "").Trim());
                if (obj.NoeMelk != null && obj.NoeMelk.GROUPTYPE == "MELK")
                {
                    obj.Vam = txtvam.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtvam.Text.Replace(",", "").Trim());
                }
            }
        }


        obj.Dsc_ShakhsiBarayUser = txtDsc.Text.Trim();
        obj.FullNameSahebkhane = txt_FullnameMalek.Text.Trim();
        obj.ShomareTelSahebkhane = txt_FullnameMalek.Text.Trim();

        if (obj.NoeMelk != null && obj.NoeMelk.GROUPTYPE == "ZAMIN")
        {
            List<int> lstboxNoeKarbariId = new List<int>();
            foreach (string row in hf_NoeKarbari.Value.Split(','))
            {
                if (row.Trim() != "" && row.Trim() != null)
                    lstboxNoeKarbariId.Add(int.Parse(row.Trim()));
            }

            foreach (var Idnoekarbari in lstboxNoeKarbariId.Distinct())
            {
                MaskanNoeKarbari item = new MaskanNoeKarbari();
                item.UID = Guid.NewGuid();

                item.NoeKarbari = dc.NoeKarbaris.First(s => s.Id == Idnoekarbari);
                item.Maskan = obj;
                dc.MaskanNoeKarbaris.InsertOnSubmit(item);

            }
        }

        dc.SubmitChanges();
        Response.Redirect(ArssPayamUtility.GetEncodedQueryString("SabtMelk.aspx?args={0}", "status=ok"));
    }
}