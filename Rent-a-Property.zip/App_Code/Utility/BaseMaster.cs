﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Drawing;
using System.Web.UI;

using System.Data;
using System.Web.Caching;
using System.Threading;
using DataAccess;

/// <summary>
/// Summary description for BaseMaster
/// </summary>
public class BaseMaster : System.Web.UI.MasterPage
{
    public User_ CurrentUser;
    public int? USERID
    {
        get
        {
            return Session["USERID"] == null ? (int?)null : (int)Session["USERID"];
        }
    }


    protected override void OnInit(EventArgs e)
    {
        dbMaskanDataContext dc = new dbMaskanDataContext();
        CurrentUser = dc.User_s.SingleOrDefault(s => s.Id == USERID);
        if (CurrentUser == null)
            Response.Redirect("/login.aspx");
        base.OnInit(e);
    }


    #region Message
    private Control FindMsgBoxControl()
    {
        Control uc = this.FindControl("ucmodeldialog");

        if (uc == null)
        {
            MasterPage mstr = this.Master;
            while (mstr != null)
            {
                uc = (Control)mstr.FindControl("ucmodeldialog");
                if (uc == null)
                    mstr = mstr.Master;
                else
                    break;
            }
        }
        return uc;

    }
    public void ShowSeccessMessage(string msg)
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[1];
        Type[0] = typeof(string);
        MethodInfo method = uc.GetType().GetMethod("ShowSeccessMessage", Type.ToArray());

        object[] prms = new object[1];
        prms[0] = msg;
        method.Invoke(uc, prms);
    }
    public void ShowErrorMessage(string msg)
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[1];
        Type[0] = typeof(string);
        MethodInfo method = uc.GetType().GetMethod("ShowErrorMessage", Type.ToArray());

        object[] prms = new object[1];
        prms[0] = msg;
        method.Invoke(uc, prms);
    }
    public void ShowInfoMessage(string msg)
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[1];
        Type[0] = typeof(string);
        MethodInfo method = uc.GetType().GetMethod("ShowInfoMessage", Type.ToArray());

        object[] prms = new object[1];
        prms[0] = msg;
        method.Invoke(uc, prms);
    }
    public string GetEmailFromForgatPassword()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];

        MethodInfo method = uc.GetType().GetMethod("GetEmailFromForgatPassword", Type.ToArray());

        object[] prms = new object[0];


        return ((string)method.Invoke(uc, prms)).Trim();
    }
    #endregion



}