﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OfficeOpenXml;
using OfficeOpenXml.Drawing.Chart;
using OfficeOpenXml.Style;
using OfficeOpenXml.Table;
using System.Data;
using System.Reflection;

/// <summary>
/// Summary description for EPPlus
/// </summary>
public class ExcelExporter
{

    private List<string> _Columns;
    private List<string> _ColumnsDataName;
    private IEnumerable<object> _DataSource;
    private DataTable _DataSourceDataTable;
    private string _Title;


    string[] ColumnAlfabet = new string[] { 
        #region
                                                "", "A" , "B" ,"C" ,"D" , "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" ,
                                                   "AA","AB" ,"AC","AD","AE","AF","AG","AH","AI","AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS","AT","AU","AV","AW","AX","AY","AZ" ,
                                                   "BA","BB" ,"BC","BD","BE","BF","BG","BH","BI","BJ","BK","BL","BM","BN","BO","BP","BQ","BR","BS","BT","BU","BV","BW","BX","BY","BZ" ,
                                                   "CA","CB" ,"CC","CD","CE","CF","CG","CH","CI","CJ","CK","CL","CM","CN","CO","CP","CQ","CR","CS","CT","CU","CV","CW","CX","CY","CZ" ,
                                                   "DA","DB" ,"DC","DD","DE","DF","DG","DH","DI","DJ","DK","DL","DM","DN","DO","DP","DQ","DR","DS","DT","DU","DV","DW","DX","DY","DZ" ,
                                                   "EA","EB" ,"EC","ED","EE","EF","EG","EH","EI","EJ","EK","EL","EM","EN","EO","EP","EQ","ER","ES","ET","EU","EV","EW","EX","EY","EZ" ,
                                                   "FA","FB" ,"FC","FD","FE","FF","FG","FH","FI","FJ","FK","FL","FM","FN","FO","FP","FQ","FR","FS","FT","FU","FV","FW","FX","FY","FZ" ,
                                                   "GA","GB" ,"GC","GD","GE","GF","GG","GH","GI","GJ","GK","GL","GM","GN","GO","GP","GQ","GR","GS","GT","GU","GV","GW","GX","GY","GZ" ,
                                                   "HA","HB" ,"HC","HD","HE","HF","HG","HH","HI","HJ","HK","HL","HM","HN","HO","HP","HQ","HR","HS","HT","HU","HV","HW","HX","HY","HZ" ,
                                                   "IA","IB" ,"IC","ID","IE","IF","IG","IH","II","IJ","IK","IL","IM","IN","IO","IP","IQ","IR","IS","IT","IU","IV","IW","IX","IY","IZ" ,
                                                   "JA","JB" ,"JC","JD","JE","JF","JG","JH","JI","JJ","JK","JL","JM","JN","JO","JP","JQ","JR","JS","JT","JU","JV","JW","JX","JY","JZ" ,
                                                   "KA","KB" ,"KC","KD","KE","KF","KG","KH","KI","KJ","KK","KL","KM","KN","KO","KP","KQ","KR","KS","KT","KU","KV","KW","KX","KY","KZ" ,
                                                   "LA","LB" ,"LC","LD","LE","LF","LG","LH","LI","LJ","LK","LL","LM","LN","LO","LP","LQ","LR","LS","LT","LU","LV","LW","LX","LY","LZ" ,
                                                   "MA","MB" ,"MC","MD","ME","MF","MG","MH","MI","MJ","MK","ML","MM","MN","MO","MP","MQ","MR","MS","MT","MU","MV","MW","MX","MY","MZ" ,
                                                   "NA","NB" ,"NC","ND","NE","NF","NG","NH","NI","NJ","NK","NL","NM","NN","NO","NP","NQ","NR","NS","NT","NU","NV","NW","NX","NY","NZ" ,
                                                   "OA","OB" ,"OC","OD","OE","OF","OG","OH","OI","OJ","OK","OL","OM","ON","OO","OP","OQ","OR","OS","OT","OU","OV","OW","OX","OY","OZ" ,
                                                   "PA","PB" ,"PC","PD","PE","PF","PG","PH","PI","PJ","PK","PL","PM","PN","PO","PP","PQ","PR","PS","PT","PU","PV","PW","PX","PY","PZ" ,
                                                   "QA","QB" ,"QC","QD","QE","QF","QG","QH","QI","QJ","QK","QL","QM","QN","QO","QP","QQ","QR","QS","QT","QU","QV","QW","QX","QY","QZ" ,
                                                   "RA","RB" ,"RC","RD","RE","RF","RG","RH","RI","RJ","RK","RL","RM","RN","RO","RP","RQ","RR","RS","RT","RU","RV","RW","RX","RY","RZ" ,
                                                   "SA","SB" ,"SC","SD","SE","SF","SG","SH","SI","SJ","SK","SL","SM","SN","SO","SP","SQ","SR","SS","ST","SU","SV","SW","SX","SY","SZ" ,
                                                   "TA","TB" ,"TC","TD","TE","TF","TG","TH","TI","TJ","TK","TL","TM","TN","TO","TP","TQ","TR","TS","TT","TU","TV","TW","TX","TY","TZ" ,
                                                   "UA","UB" ,"UC","UD","UE","UF","UG","UH","UI","UJ","UK","UL","UM","UN","UO","UP","UQ","UR","US","UT","UU","UV","UW","UX","UY","UZ" ,
                                                   "VA","VB" ,"VC","VD","VE","VF","VG","VH","VI"    
    #endregion
    };



    /// <summary>
    /// دیتا سورس و عنوان گزارش را در سازنده دریافت میکند ، ستون ها باید بعد از این با متد AddColumn اضافه شوند
    /// </summary>
    /// <param name="dataSource"></param>
    /// <param name="reportTite"></param>
    public ExcelExporter(IEnumerable<object> dataSource, string reportTite)
    {
        _Columns = new List<string>();
        _ColumnsDataName = new List<string>();
        _DataSource = dataSource;
        _Title = reportTite;
    }

    public void AddColumn(string farsiName, string DataName)
    {
        _Columns.Add(farsiName);
        _ColumnsDataName.Add(DataName);
    }

    public ExcelExporter(IEnumerable<object> dataSource, string reportTite, List<string> columns, List<string> columnsDataName)
    {
        _Columns = columns;
        _ColumnsDataName = columnsDataName;
        _DataSource = dataSource;
        _Title = reportTite;
    }

    public ExcelExporter(DataTable dataSource, string reportTite, List<string> columns, List<string> columnsDataName)
    {
        _Columns = columns;
        _ColumnsDataName = columnsDataName;
        _DataSourceDataTable = dataSource;
        _Title = reportTite;
    }

    public void Export(string fileName, string _HeaderTitle, bool RightToLeft = false)
    {
        ExcelPackage pck = new ExcelPackage();

        var sheet = pck.Workbook.Worksheets.Add(string.IsNullOrWhiteSpace(_Title) ? "Sheet1" : _Title);

        if (_Columns.Any())
        {

            int ColIndex = 1;

            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Merge = true;
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Value = _HeaderTitle;
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Fill.PatternType = ExcelFillStyle.Solid;
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Silver);

            
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Font.Bold = true;

            //sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Style.Border.BorderAround(ExcelBorderStyle.Thin, System.Drawing.Color.Gray);
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Border.Left.Style = ExcelBorderStyle.Thin;
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Border.Right.Style = ExcelBorderStyle.Thin;
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Border.Top.Style = ExcelBorderStyle.Thin;
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Border.Left.Color.SetColor(System.Drawing.Color.Gray);
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Border.Right.Color.SetColor(System.Drawing.Color.Gray);
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Border.Top.Color.SetColor(System.Drawing.Color.Gray);
            sheet.Cells[ColumnAlfabet[ColIndex] + "1:" + ColumnAlfabet[_Columns.Count] + "1"].Style.Border.Bottom.Color.SetColor(System.Drawing.Color.Gray);



         

            ColIndex = 1;
            foreach (string Header in _Columns)
            {
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Value = Header;
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Fill.PatternType = ExcelFillStyle.Solid;
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Gainsboro);
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                //sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Border.BorderAround(ExcelBorderStyle.Thin, System.Drawing.Color.Gray);
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Border.Left.Color.SetColor(System.Drawing.Color.Gray);
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Border.Right.Color.SetColor(System.Drawing.Color.Gray);
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Border.Top.Color.SetColor(System.Drawing.Color.Gray);
                sheet.Cells[ColumnAlfabet[ColIndex] + "2"].Style.Border.Bottom.Color.SetColor(System.Drawing.Color.Gray);



                ColIndex++;
            }

            int rowIndex = 3;
            foreach (object obj in _DataSource)
            {
                ColIndex = 1;
                foreach (string DataSourceColumnName in _ColumnsDataName)
                {
                    PropertyInfo propertyInfo = obj.GetType().GetProperty(DataSourceColumnName);
                    object val = propertyInfo.GetValue(obj, null);

                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Value = val;
                    //sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.BorderAround(ExcelBorderStyle.Thin, System.Drawing.Color.Gray);
                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.Left.Color.SetColor(System.Drawing.Color.Gray);
                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.Right.Color.SetColor(System.Drawing.Color.Gray);
                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.Top.Color.SetColor(System.Drawing.Color.Gray);
                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.Bottom.Color.SetColor(System.Drawing.Color.Gray);
                    sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                    ColIndex++;
                }
                rowIndex++;
            }


            sheet.View.RightToLeft = true;

            string WholeSheetAddress = sheet.Dimension.Address;

            //sheet.Cells[WholeSheetAddress].Style.Border.BorderAround(ExcelBorderStyle.Thin, System.Drawing.Color.Gray);
            sheet.Cells[WholeSheetAddress].Style.Font.Name = "Tahoma";
            sheet.Cells[WholeSheetAddress].Style.Font.Size = 10F;
            sheet.Cells[WholeSheetAddress].AutoFitColumns();
            sheet.Cells[WholeSheetAddress].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
            //sheet.Cells[WholeSheetAddress].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
            sheet.Cells[WholeSheetAddress].Style.ReadingOrder = ExcelReadingOrder.RightToLeft;

            sheet.DefaultRowHeight = 20;
        }

        HttpContext.Current.Response.BinaryWrite(pck.GetAsByteArray());
        HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        HttpContext.Current.Response.AddHeader("content-disposition", "attachment;  filename=" + fileName + ".xlsx");
        HttpContext.Current.Response.End();
    }

    public void ExportWithDataTableDataSource(string fileName, bool RightToLeft = false)
    {
        ExcelPackage pck = new ExcelPackage();
        var sheet = pck.Workbook.Worksheets.Add(string.IsNullOrWhiteSpace(_Title) ? "Sheet1" : _Title);

        if (_Columns.Any())
        {
            int ColOrder = 0;
            foreach (string DataSourceColumnName in _ColumnsDataName)
            {
                if (_DataSourceDataTable.Columns.Contains(DataSourceColumnName))
                    _DataSourceDataTable.Columns[DataSourceColumnName].SetOrdinal(ColOrder++);
                else
                    _DataSourceDataTable.Columns.Remove(DataSourceColumnName);
            }

            int ColIndex = 1;
            foreach (string Header in _Columns)
            {
                sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Value = Header;
                sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Style.Fill.PatternType = ExcelFillStyle.Solid;
                sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Silver);
                ColIndex++;
            }

            sheet.Cells["A2"].LoadFromDataTable(_DataSourceDataTable, false);
            sheet.View.RightToLeft = true;

            string WholeSheetAddress = sheet.Dimension.Address;

            sheet.Cells[WholeSheetAddress].Style.Font.Name = "Tahoma";
            sheet.Cells[WholeSheetAddress].Style.Font.Size = 10F;
            //sheet.Cells[WholeSheetAddress].Style.Border.BorderAround(ExcelBorderStyle.Thin, System.Drawing.Color.Gray);
            sheet.Cells[WholeSheetAddress].Style.Border.Left.Style = ExcelBorderStyle.Thin;
            sheet.Cells[WholeSheetAddress].Style.Border.Right.Style = ExcelBorderStyle.Thin;
            sheet.Cells[WholeSheetAddress].Style.Border.Top.Style = ExcelBorderStyle.Thin;
            sheet.Cells[WholeSheetAddress].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            sheet.Cells[WholeSheetAddress].Style.Border.Left.Color.SetColor(System.Drawing.Color.Gray);
            sheet.Cells[WholeSheetAddress].Style.Border.Right.Color.SetColor(System.Drawing.Color.Gray);
            sheet.Cells[WholeSheetAddress].Style.Border.Top.Color.SetColor(System.Drawing.Color.Gray);
            sheet.Cells[WholeSheetAddress].Style.Border.Bottom.Color.SetColor(System.Drawing.Color.Gray);
            sheet.Cells[WholeSheetAddress].AutoFitColumns();
            sheet.Cells[WholeSheetAddress].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
            sheet.Cells[WholeSheetAddress].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
            sheet.Cells[WholeSheetAddress].Style.ReadingOrder = ExcelReadingOrder.RightToLeft;

            sheet.DefaultRowHeight = 20;
        }

        HttpContext.Current.Response.BinaryWrite(pck.GetAsByteArray());
        HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        HttpContext.Current.Response.AddHeader("content-disposition", "attachment;  filename=" + fileName + ".xlsx");
        HttpContext.Current.Response.End();


        //bool HasColor = _DataSourceDataTable.Columns.Contains("RowBackgroundColor");


    }

    //public void Export(DataTable dataSource,List<string> lstDataSourceColumnNames , List<string> HeaderNames,string fileName, bool RightToLeft = true)
    //{

    //    int ColOrder = 0;
    //    foreach (string DataSourceColumnName in lstDataSourceColumnNames)
    //    {
    //        if (dataSource.Columns.Contains(DataSourceColumnName))
    //            dataSource.Columns[DataSourceColumnName].SetOrdinal(ColOrder++);
    //        else
    //            dataSource.Columns.Remove(DataSourceColumnName);
    //    }


    //    ExcelPackage pck = new ExcelPackage();
    //    var sheet = pck.Workbook.Worksheets.Add("Sheet1");

    //    int ColIndex = 1;
    //    foreach (string Header in HeaderNames)
    //    {
    //        sheet.Cells[ColumnAlfabet[ColIndex]+"1"].Value = Header;
    //        sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Style.Fill.PatternType = ExcelFillStyle.Solid;
    //        sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Silver);
    //        ColIndex++;
    //    }

    //    sheet.Cells["A2"].LoadFromDataTable(dataSource, false);
    //    sheet.View.RightToLeft = true;

    //    string WholeSheetAddress = sheet.Dimension.Address;

    //    sheet.Cells[WholeSheetAddress].Style.Font.Name = "Tahoma";
    //    sheet.Cells[WholeSheetAddress].Style.Font.Size = 10F;
    //    sheet.Cells[WholeSheetAddress].Style.Border.BorderAround(ExcelBorderStyle.Thin, System.Drawing.Color.Gray);
    //    sheet.Cells[WholeSheetAddress].AutoFitColumns();
    //    sheet.Cells[WholeSheetAddress].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
    //    sheet.Cells[WholeSheetAddress].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;

    //    sheet.DefaultRowHeight = 20;

    //    HttpContext.Current.Response.BinaryWrite(pck.GetAsByteArray());
    //    HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    //    HttpContext.Current.Response.AddHeader("content-disposition", "attachment;  filename="+fileName+".xlsx");
    //    HttpContext.Current.Response.End();
    //}

    //public void Export(IEnumerable<object> dataSource, List<string> lstDataSourceColumnNames, List<string> HeaderNames, string fileName, bool RightToLeft = true)
    //{

    //    ExcelPackage pck = new ExcelPackage();
    //    var sheet = pck.Workbook.Worksheets.Add("Sheet1");

    //    int ColIndex = 1;
    //    foreach (string Header in HeaderNames)
    //    {
    //        sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Value = Header;
    //        sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Style.Fill.PatternType = ExcelFillStyle.Solid;
    //        sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Silver);
    //        sheet.Cells[ColumnAlfabet[ColIndex] + "1"].Style.Border.BorderAround(ExcelBorderStyle.Thin, System.Drawing.Color.Gray);
    //        ColIndex++;
    //    }

    //    int rowIndex = 2;
    //    foreach (object obj in dataSource)
    //    {
    //        ColIndex = 1;
    //        foreach (string DataSourceColumnName in lstDataSourceColumnNames)
    //        {
    //            PropertyInfo propertyInfo = obj.GetType().GetProperty(DataSourceColumnName);
    //            object val = propertyInfo.GetValue(obj, null);

    //            sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Value = val;
    //            sheet.Cells[ColumnAlfabet[ColIndex] + rowIndex].Style.Border.BorderAround(ExcelBorderStyle.Thin, System.Drawing.Color.Gray);
    //            ColIndex++;
    //        }
    //        rowIndex++;
    //    }


    //    sheet.View.RightToLeft = true;

    //    string WholeSheetAddress = sheet.Dimension.Address;

    //    //sheet.Cells[WholeSheetAddress].Style.Border.BorderAround(ExcelBorderStyle.Thin, System.Drawing.Color.Gray);
    //    sheet.Cells[WholeSheetAddress].Style.Font.Name = "Tahoma";
    //    sheet.Cells[WholeSheetAddress].Style.Font.Size = 10F;
    //    sheet.Cells[WholeSheetAddress].AutoFitColumns();
    //    sheet.Cells[WholeSheetAddress].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
    //    sheet.Cells[WholeSheetAddress].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;

    //    sheet.DefaultRowHeight = 20;

    //    HttpContext.Current.Response.BinaryWrite(pck.GetAsByteArray());
    //    HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    //    HttpContext.Current.Response.AddHeader("content-disposition", "attachment;  filename=" + fileName + ".xlsx");
    //    HttpContext.Current.Response.End();
    //}

}
