﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;
using System.Web.UI;
using System.Reflection;
using DataAccess;
/// <summary>
/// Summary description for BaseMaster
/// </summary>
public class PrimeryPage : System.Web.UI.Page
{


    #region Message
    private Control FindMsgBoxControl()
    {
        Control uc = this.FindControl("ucmodeldialog");

        if (uc == null)
        {
            MasterPage mstr = this.Master;
            while (mstr != null)
            {
                uc = (Control)mstr.FindControl("ucmodeldialog");
                if (uc == null)
                    mstr = mstr.Master;
                else
                    break;
            }
        }
        return uc;

    }
    public void ShowSeccessMessage(string msg)
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[1];
        Type[0] = typeof(string);
        MethodInfo method = uc.GetType().GetMethod("ShowSeccessMessage", Type.ToArray());

        object[] prms = new object[1];
        prms[0] = msg;
        method.Invoke(uc, prms);
    }
    public void ShowErrorMessage(string msg)
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[1];
        Type[0] = typeof(string);
        MethodInfo method = uc.GetType().GetMethod("ShowErrorMessage", Type.ToArray());

        object[] prms = new object[1];
        prms[0] = msg;
        method.Invoke(uc, prms);
    }
    public void ShowInfoMessage(string msg)
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[1];
        Type[0] = typeof(string);
        MethodInfo method = uc.GetType().GetMethod("ShowInfoMessage", Type.ToArray());

        object[] prms = new object[1];
        prms[0] = msg;
        method.Invoke(uc, prms);
    }
    public string GetEmailFromForgatPassword()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];

        MethodInfo method = uc.GetType().GetMethod("GetEmailFromForgatPassword", Type.ToArray());

        object[] prms = new object[0];


        return ((string)method.Invoke(uc, prms)).Trim();
    }
    #endregion


   
}