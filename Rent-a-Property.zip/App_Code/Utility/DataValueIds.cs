﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DataValueIds
/// </summary>
public static class DataValueIds
{
    public enum NoeMoavezeIds
    {
        RahnVaEjare=1,
        KharidVaForosh=2,
        PishForosh = 3
    }

}