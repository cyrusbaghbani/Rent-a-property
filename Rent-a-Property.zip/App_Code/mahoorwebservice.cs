﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for mahoorwebservice
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class mahoorwebservice : System.Web.Services.WebService
{

    public mahoorwebservice()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld()
    {
        return "Hello World";
    }


    [WebMethod]
    public bool CheckUserAndPass(string username, string password)
    {
        dbMaskanDataContext dc = new dbMaskanDataContext();
        return dc.User_s.Any(s => s.UserName.ToLower() == username.ToLower() && s.Password == Utility.EncryptedQueryString.GetMD5Hash(password));
    }

}
