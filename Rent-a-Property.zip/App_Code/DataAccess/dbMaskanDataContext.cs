﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbMaskanDataContext
/// </summary>
[global::System.Data.Linq.Mapping.DatabaseAttribute(Name = "db_Maskan")]
public partial class dbMaskanDataContext : System.Data.Linq.DataContext
{

    private static System.Data.Linq.Mapping.MappingSource mappingSource = new AttributeMappingSource();

    #region Extensibility Method Definitions
    partial void OnCreated();
    partial void InsertAmlak_Porofile(Amlak_Porofile instance);
    partial void UpdateAmlak_Porofile(Amlak_Porofile instance);
    partial void DeleteAmlak_Porofile(Amlak_Porofile instance);
    partial void InsertNoeDarkhast(NoeDarkhast instance);
    partial void UpdateNoeDarkhast(NoeDarkhast instance);
    partial void DeleteNoeDarkhast(NoeDarkhast instance);
    partial void InsertUser_(User_ instance);
    partial void UpdateUser_(User_ instance);
    partial void DeleteUser_(User_ instance);
    partial void InsertDarbAz(DarbAz instance);
    partial void UpdateDarbAz(DarbAz instance);
    partial void DeleteDarbAz(DarbAz instance);
    partial void InsertDarkhastMaskan(DarkhastMaskan instance);
    partial void UpdateDarkhastMaskan(DarkhastMaskan instance);
    partial void DeleteDarkhastMaskan(DarkhastMaskan instance);
    partial void InsertKlid(Klid instance);
    partial void UpdateKlid(Klid instance);
    partial void DeleteKlid(Klid instance);
    partial void InsertMakan(Makan instance);
    partial void UpdateMakan(Makan instance);
    partial void DeleteMakan(Makan instance);
    partial void InsertMantaghe(Mantaghe instance);
    partial void UpdateMantaghe(Mantaghe instance);
    partial void DeleteMantaghe(Mantaghe instance);
    partial void InsertMaskan(Maskan instance);
    partial void UpdateMaskan(Maskan instance);
    partial void DeleteMaskan(Maskan instance);
    partial void InsertMaskanImage(MaskanImage instance);
    partial void UpdateMaskanImage(MaskanImage instance);
    partial void DeleteMaskanImage(MaskanImage instance);
    partial void InsertMaskanNoeKarbari(MaskanNoeKarbari instance);
    partial void UpdateMaskanNoeKarbari(MaskanNoeKarbari instance);
    partial void DeleteMaskanNoeKarbari(MaskanNoeKarbari instance);
    partial void InsertNoeKarbari(NoeKarbari instance);
    partial void UpdateNoeKarbari(NoeKarbari instance);
    partial void DeleteNoeKarbari(NoeKarbari instance);
    partial void InsertNoeMelk(NoeMelk instance);
    partial void UpdateNoeMelk(NoeMelk instance);
    partial void DeleteNoeMelk(NoeMelk instance);
    partial void InsertNoeMoaveze(NoeMoaveze instance);
    partial void UpdateNoeMoaveze(NoeMoaveze instance);
    partial void DeleteNoeMoaveze(NoeMoaveze instance);
    partial void InsertTabghe(Tabghe instance);
    partial void UpdateTabghe(Tabghe instance);
    partial void DeleteTabghe(Tabghe instance);
    partial void InsertTedadKhab(TedadKhab instance);
    partial void UpdateTedadKhab(TedadKhab instance);
    partial void DeleteTedadKhab(TedadKhab instance);
    partial void InsertTempImage(TempImage instance);
    partial void UpdateTempImage(TempImage instance);
    partial void DeleteTempImage(TempImage instance);
    #endregion

    public dbMaskanDataContext() :
        base(global::System.Configuration.ConfigurationManager.ConnectionStrings["db_MaskanConnectionString"].ConnectionString, mappingSource)
    {
        OnCreated();
    }

    public dbMaskanDataContext(string connection) :
        base(connection, mappingSource)
    {
        OnCreated();
    }

    public dbMaskanDataContext(System.Data.IDbConnection connection) :
        base(connection, mappingSource)
    {
        OnCreated();
    }

    public dbMaskanDataContext(string connection, System.Data.Linq.Mapping.MappingSource mappingSource) :
        base(connection, mappingSource)
    {
        OnCreated();
    }

    public dbMaskanDataContext(System.Data.IDbConnection connection, System.Data.Linq.Mapping.MappingSource mappingSource) :
        base(connection, mappingSource)
    {
        OnCreated();
    }

    public System.Data.Linq.Table<Amlak_Porofile> Amlak_Porofiles
    {
        get
        {
            return this.GetTable<Amlak_Porofile>();
        }
    }

    public System.Data.Linq.Table<User_> User_s
    {
        get
        {
            return this.GetTable<User_>();
        }
    }

    public System.Data.Linq.Table<DarbAz> DarbAzs
    {
        get
        {
            return this.GetTable<DarbAz>();
        }
    }

    public System.Data.Linq.Table<DarkhastMaskan> DarkhastMaskans
    {
        get
        {
            return this.GetTable<DarkhastMaskan>();
        }
    }

    public System.Data.Linq.Table<Klid> Klids
    {
        get
        {
            return this.GetTable<Klid>();
        }
    }

    public System.Data.Linq.Table<Makan> Makans
    {
        get
        {
            return this.GetTable<Makan>();
        }
    }

    public System.Data.Linq.Table<Mantaghe> Mantaghes
    {
        get
        {
            return this.GetTable<Mantaghe>();
        }
    }

    public System.Data.Linq.Table<Maskan> Maskans
    {
        get
        {
            return this.GetTable<Maskan>();
        }
    }

    public System.Data.Linq.Table<MaskanImage> MaskanImages
    {
        get
        {
            return this.GetTable<MaskanImage>();
        }
    }

    public System.Data.Linq.Table<MaskanNoeKarbari> MaskanNoeKarbaris
    {
        get
        {
            return this.GetTable<MaskanNoeKarbari>();
        }
    }

    public System.Data.Linq.Table<NoeKarbari> NoeKarbaris
    {
        get
        {
            return this.GetTable<NoeKarbari>();
        }
    }

    public System.Data.Linq.Table<NoeMelk> NoeMelks
    {
        get
        {
            return this.GetTable<NoeMelk>();
        }
    }

    public System.Data.Linq.Table<NoeMoaveze> NoeMoavezes
    {
        get
        {
            return this.GetTable<NoeMoaveze>();
        }
    }

    public System.Data.Linq.Table<Tabghe> Tabghes
    {
        get
        {
            return this.GetTable<Tabghe>();
        }
    }
    public System.Data.Linq.Table<NoeDarkhast> NoeDarkhasts
    {
        get
        {
            return this.GetTable<NoeDarkhast>();
        }
    }
    public System.Data.Linq.Table<TedadKhab> TedadKhabs
    {
        get
        {
            return this.GetTable<TedadKhab>();
        }
    }

    public System.Data.Linq.Table<TempImage> TempImages
    {
        get
        {
            return this.GetTable<TempImage>();
        }
    }
}