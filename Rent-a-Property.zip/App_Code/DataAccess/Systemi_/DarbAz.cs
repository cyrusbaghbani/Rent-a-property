﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Linq;
using System.Web;

namespace DataAccess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.DarbAz")]
    public partial class DarbAz : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private System.Nullable<int> _priority;

        private string _Dsc;

        private bool _IsDelete;

        private string _Name;

        private EntitySet<Maskan> _Maskans;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnpriorityChanging(System.Nullable<int> value);
        partial void OnpriorityChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnIsDeleteChanging(bool value);
        partial void OnIsDeleteChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        #endregion

        public DarbAz()
        {
            this._Maskans = new EntitySet<Maskan>(new Action<Maskan>(this.attach_Maskans), new Action<Maskan>(this.detach_Maskans));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "Int NOT NULL", IsPrimaryKey = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_priority", DbType = "Int")]
        public System.Nullable<int> priority
        {
            get
            {
                return this._priority;
            }
            set
            {
                if ((this._priority != value))
                {
                    this.OnpriorityChanging(value);
                    this.SendPropertyChanging();
                    this._priority = value;
                    this.SendPropertyChanged("priority");
                    this.OnpriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDelete", DbType = "Bit NOT NULL")]
        public bool IsDelete
        {
            get
            {
                return this._IsDelete;
            }
            set
            {
                if ((this._IsDelete != value))
                {
                    this.OnIsDeleteChanging(value);
                    this.SendPropertyChanging();
                    this._IsDelete = value;
                    this.SendPropertyChanged("IsDelete");
                    this.OnIsDeleteChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(200)")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "DarbAz_Maskan", Storage = "_Maskans", ThisKey = "Id", OtherKey = "DarbAzId")]
        public EntitySet<Maskan> Maskans
        {
            get
            {
                return this._Maskans;
            }
            set
            {
                this._Maskans.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Maskans(Maskan entity)
        {
            this.SendPropertyChanging();
            entity.DarbAz = this;
        }

        private void detach_Maskans(Maskan entity)
        {
            this.SendPropertyChanging();
            entity.DarbAz = null;
        }
    }
}