﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Linq;
using System.Web;

namespace DataAccess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Mantaghe")]
    public partial class Mantaghe : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _Name;

        private System.Nullable<int> _priority;

        private string _Dsc;

        private bool _IsDeleted;

        private EntitySet<Maskan> _Maskans;

        private int _MakanId;

        private EntityRef<Makan> _Makan;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnpriorityChanging(System.Nullable<int> value);
        partial void OnpriorityChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnMakanIdChanging(int value);
        partial void OnMakanIdChanged();
        #endregion

        public Mantaghe()
        {
            this._Makan = default(EntityRef<Makan>);
            this._Maskans = new EntitySet<Maskan>(new Action<Maskan>(this.attach_Maskans), new Action<Maskan>(this.detach_Maskans));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "Int NOT NULL", IsPrimaryKey = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(500)")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_priority", DbType = "Int")]
        public System.Nullable<int> priority
        {
            get
            {
                return this._priority;
            }
            set
            {
                if ((this._priority != value))
                {
                    this.OnpriorityChanging(value);
                    this.SendPropertyChanging();
                    this._priority = value;
                    this.SendPropertyChanged("priority");
                    this.OnpriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Mantaghe_Maskan", Storage = "_Maskans", ThisKey = "Id", OtherKey = "MantagheId")]
        public EntitySet<Maskan> Maskans
        {
            get
            {
                return this._Maskans;
            }
            set
            {
                this._Maskans.Assign(value);
            }
        }


        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MakanId", DbType = "Int NOT NULL")]
        public int MakanId
        {
            get
            {
                return this._MakanId;
            }
            set
            {
                if ((this._MakanId != value))
                {
                    if (this._Makan.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMakanIdChanging(value);
                    this.SendPropertyChanging();
                    this._MakanId = value;
                    this.SendPropertyChanged("MakanId");
                    this.OnMakanIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Makan_Mantaghe", Storage = "_Makan", ThisKey = "MakanId", OtherKey = "Id", IsForeignKey = true)]
        public Makan Makan
        {
            get
            {
                return this._Makan.Entity;
            }
            set
            {
                Makan previousValue = this._Makan.Entity;
                if (((previousValue != value)
                            || (this._Makan.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Makan.Entity = null;
                        previousValue.Mantaghes.Remove(this);
                    }
                    this._Makan.Entity = value;
                    if ((value != null))
                    {
                        value.Mantaghes.Add(this);
                        this._MakanId = value.Id;
                    }
                    else
                    {
                        this._MakanId = default(int);
                    }
                    this.SendPropertyChanged("Makan");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Maskans(Maskan entity)
        {
            this.SendPropertyChanging();
            entity.Mantaghe = this;
        }

        private void detach_Maskans(Maskan entity)
        {
            this.SendPropertyChanging();
            entity.Mantaghe = null;
        }
    }
}