﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Linq;
using System.Web;

namespace DataAccess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Makan")]
    public partial class Makan : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _Name;

        private System.Nullable<int> _Priority;

        private bool _IsDeleted;

        private string _Dsc;

        private EntitySet<Maskan> _Maskans;

        private EntitySet<Mantaghe> _Mantaghes;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnPriorityChanging(System.Nullable<int> value);
        partial void OnPriorityChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        #endregion

        public Makan()
        {
            this._Mantaghes = new EntitySet<Mantaghe>(new Action<Mantaghe>(this.attach_Mantaghes), new Action<Mantaghe>(this.detach_Mantaghes));
            this._Maskans = new EntitySet<Maskan>(new Action<Maskan>(this.attach_Maskans), new Action<Maskan>(this.detach_Maskans));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "Int NOT NULL", IsPrimaryKey = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(500)")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Priority", DbType = "Int")]
        public System.Nullable<int> Priority
        {
            get
            {
                return this._Priority;
            }
            set
            {
                if ((this._Priority != value))
                {
                    this.OnPriorityChanging(value);
                    this.SendPropertyChanging();
                    this._Priority = value;
                    this.SendPropertyChanged("Priority");
                    this.OnPriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Makan_Maskan", Storage = "_Maskans", ThisKey = "Id", OtherKey = "MakanId")]
        public EntitySet<Maskan> Maskans
        {
            get
            {
                return this._Maskans;
            }
            set
            {
                this._Maskans.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Makan_Mantaghe", Storage = "_Mantaghes", ThisKey = "Id", OtherKey = "MakanId")]
        public EntitySet<Mantaghe> Mantaghes
        {
            get
            {
                return this._Mantaghes;
            }
            set
            {
                this._Mantaghes.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Maskans(Maskan entity)
        {
            this.SendPropertyChanging();
            entity.Makan = this;
        }

        private void detach_Maskans(Maskan entity)
        {
            this.SendPropertyChanging();
            entity.Makan = null;
        }

        private void attach_Mantaghes(Mantaghe entity)
        {
            this.SendPropertyChanging();
            entity.Makan = this;
        }

        private void detach_Mantaghes(Mantaghe entity)
        {
            this.SendPropertyChanging();
            entity.Makan = null;
        }
    }

}