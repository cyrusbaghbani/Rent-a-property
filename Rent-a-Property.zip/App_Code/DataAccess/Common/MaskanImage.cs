﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Linq;
using System.Web;

namespace DataAccess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.MaskanImage")]
    public partial class MaskanImage : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private string _Address;

        private int _MaskanId;

        private string _Dsc;

        private System.Nullable<System.DateTime> _Datetime;

        private EntityRef<Maskan> _Maskan;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnAddressChanging(string value);
        partial void OnAddressChanged();
        partial void OnMaskanIdChanging(int value);
        partial void OnMaskanIdChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnDatetimeChanging(System.Nullable<System.DateTime> value);
        partial void OnDatetimeChanged();
        #endregion

        public MaskanImage()
        {
            this._Maskan = default(EntityRef<Maskan>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Address", DbType = "NVarChar(MAX)")]
        public string Address
        {
            get
            {
                return this._Address;
            }
            set
            {
                if ((this._Address != value))
                {
                    this.OnAddressChanging(value);
                    this.SendPropertyChanging();
                    this._Address = value;
                    this.SendPropertyChanged("Address");
                    this.OnAddressChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MaskanId", DbType = "Int NOT NULL")]
        public int MaskanId
        {
            get
            {
                return this._MaskanId;
            }
            set
            {
                if ((this._MaskanId != value))
                {
                    if (this._Maskan.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMaskanIdChanging(value);
                    this.SendPropertyChanging();
                    this._MaskanId = value;
                    this.SendPropertyChanged("MaskanId");
                    this.OnMaskanIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Datetime", DbType = "DateTime")]
        public System.Nullable<System.DateTime> Datetime
        {
            get
            {
                return this._Datetime;
            }
            set
            {
                if ((this._Datetime != value))
                {
                    this.OnDatetimeChanging(value);
                    this.SendPropertyChanging();
                    this._Datetime = value;
                    this.SendPropertyChanged("Datetime");
                    this.OnDatetimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Maskan_MaskanImage", Storage = "_Maskan", ThisKey = "MaskanId", OtherKey = "Id", IsForeignKey = true)]
        public Maskan Maskan
        {
            get
            {
                return this._Maskan.Entity;
            }
            set
            {
                Maskan previousValue = this._Maskan.Entity;
                if (((previousValue != value)
                            || (this._Maskan.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Maskan.Entity = null;
                        previousValue.MaskanImages.Remove(this);
                    }
                    this._Maskan.Entity = value;
                    if ((value != null))
                    {
                        value.MaskanImages.Add(this);
                        this._MaskanId = value.Id;
                    }
                    else
                    {
                        this._MaskanId = default(int);
                    }
                    this.SendPropertyChanged("Maskan");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}