﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

namespace DataAccess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.MaskanNoeKarbari")]
    public partial class MaskanNoeKarbari : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private int _NoeKarbariId;

        private int _MaskanId;

        private string _Dsc;

        private EntityRef<Maskan> _Maskan;

        private EntityRef<NoeKarbari> _NoeKarbari;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnNoeKarbariIdChanging(int value);
        partial void OnNoeKarbariIdChanged();
        partial void OnMaskanIdChanging(int value);
        partial void OnMaskanIdChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        #endregion

        public MaskanNoeKarbari()
        {
            this._Maskan = default(EntityRef<Maskan>);
            this._NoeKarbari = default(EntityRef<NoeKarbari>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NoeKarbariId", DbType = "Int NOT NULL")]
        public int NoeKarbariId
        {
            get
            {
                return this._NoeKarbariId;
            }
            set
            {
                if ((this._NoeKarbariId != value))
                {
                    if (this._NoeKarbari.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnNoeKarbariIdChanging(value);
                    this.SendPropertyChanging();
                    this._NoeKarbariId = value;
                    this.SendPropertyChanged("NoeKarbariId");
                    this.OnNoeKarbariIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MaskanId", DbType = "Int NOT NULL")]
        public int MaskanId
        {
            get
            {
                return this._MaskanId;
            }
            set
            {
                if ((this._MaskanId != value))
                {
                    if (this._Maskan.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMaskanIdChanging(value);
                    this.SendPropertyChanging();
                    this._MaskanId = value;
                    this.SendPropertyChanged("MaskanId");
                    this.OnMaskanIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Maskan_MaskanNoeKarbari", Storage = "_Maskan", ThisKey = "MaskanId", OtherKey = "Id", IsForeignKey = true)]
        public Maskan Maskan
        {
            get
            {
                return this._Maskan.Entity;
            }
            set
            {
                Maskan previousValue = this._Maskan.Entity;
                if (((previousValue != value)
                            || (this._Maskan.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Maskan.Entity = null;
                        previousValue.MaskanNoeKarbaris.Remove(this);
                    }
                    this._Maskan.Entity = value;
                    if ((value != null))
                    {
                        value.MaskanNoeKarbaris.Add(this);
                        this._MaskanId = value.Id;
                    }
                    else
                    {
                        this._MaskanId = default(int);
                    }
                    this.SendPropertyChanged("Maskan");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "NoeKarbari_MaskanNoeKarbari", Storage = "_NoeKarbari", ThisKey = "NoeKarbariId", OtherKey = "Id", IsForeignKey = true)]
        public NoeKarbari NoeKarbari
        {
            get
            {
                return this._NoeKarbari.Entity;
            }
            set
            {
                NoeKarbari previousValue = this._NoeKarbari.Entity;
                if (((previousValue != value)
                            || (this._NoeKarbari.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._NoeKarbari.Entity = null;
                        previousValue.MaskanNoeKarbaris.Remove(this);
                    }
                    this._NoeKarbari.Entity = value;
                    if ((value != null))
                    {
                        value.MaskanNoeKarbaris.Add(this);
                        this._NoeKarbariId = value.Id;
                    }
                    else
                    {
                        this._NoeKarbariId = default(int);
                    }
                    this.SendPropertyChanged("NoeKarbari");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}