﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

namespace DataAccess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.DarkhastMaskan")]
    public partial class DarkhastMaskan : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private string _NameFrestande;

        private string _EmailFrestande;

        private string _TelFrestande;

        private string _Dsc_Darkhast;

        private string _Javab;

        private System.Nullable<System.DateTime> _DateTimeErsal;

        private System.Nullable<System.DateTime> _DateTimeJavab;

        private string _DateErsal;

        private string _TimeErsal;

        private string _DatePasokh;

        private string _TimePasokh;

        private bool _IsRead;

        private bool _IsDeleted;
        private int _NoeDarkhastId;

        private EntityRef<NoeDarkhast> _NoeDarkhast;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnNameFrestandeChanging(string value);
        partial void OnNameFrestandeChanged();
        partial void OnEmailFrestandeChanging(string value);
        partial void OnEmailFrestandeChanged();
        partial void OnTelFrestandeChanging(string value);
        partial void OnTelFrestandeChanged();
        partial void OnDsc_DarkhastChanging(string value);
        partial void OnDsc_DarkhastChanged();
        partial void OnJavabChanging(string value);
        partial void OnJavabChanged();
        partial void OnDateTimeErsalChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeErsalChanged();
        partial void OnDateTimeJavabChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeJavabChanged();
        partial void OnDateErsalChanging(string value);
        partial void OnDateErsalChanged();
        partial void OnTimeErsalChanging(string value);
        partial void OnTimeErsalChanged();
        partial void OnDatePasokhChanging(string value);
        partial void OnDatePasokhChanged();
        partial void OnTimePasokhChanging(string value);
        partial void OnTimePasokhChanged();
        partial void OnIsReadChanging(bool value);
        partial void OnIsReadChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnNoeDarkhastIdChanging(int value);
        partial void OnNoeDarkhastIdChanged();
        #endregion

        public DarkhastMaskan()
        {
            this._NoeDarkhast = default(EntityRef<NoeDarkhast>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NameFrestande", DbType = "NVarChar(500)")]
        public string NameFrestande
        {
            get
            {
                return this._NameFrestande;
            }
            set
            {
                if ((this._NameFrestande != value))
                {
                    this.OnNameFrestandeChanging(value);
                    this.SendPropertyChanging();
                    this._NameFrestande = value;
                    this.SendPropertyChanged("NameFrestande");
                    this.OnNameFrestandeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EmailFrestande", DbType = "NVarChar(500)")]
        public string EmailFrestande
        {
            get
            {
                return this._EmailFrestande;
            }
            set
            {
                if ((this._EmailFrestande != value))
                {
                    this.OnEmailFrestandeChanging(value);
                    this.SendPropertyChanging();
                    this._EmailFrestande = value;
                    this.SendPropertyChanged("EmailFrestande");
                    this.OnEmailFrestandeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TelFrestande", DbType = "NVarChar(500)")]
        public string TelFrestande
        {
            get
            {
                return this._TelFrestande;
            }
            set
            {
                if ((this._TelFrestande != value))
                {
                    this.OnTelFrestandeChanging(value);
                    this.SendPropertyChanging();
                    this._TelFrestande = value;
                    this.SendPropertyChanged("TelFrestande");
                    this.OnTelFrestandeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc_Darkhast", DbType = "NVarChar(MAX)")]
        public string Dsc_Darkhast
        {
            get
            {
                return this._Dsc_Darkhast;
            }
            set
            {
                if ((this._Dsc_Darkhast != value))
                {
                    this.OnDsc_DarkhastChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc_Darkhast = value;
                    this.SendPropertyChanged("Dsc_Darkhast");
                    this.OnDsc_DarkhastChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Javab", DbType = "NVarChar(MAX)")]
        public string Javab
        {
            get
            {
                return this._Javab;
            }
            set
            {
                if ((this._Javab != value))
                {
                    this.OnJavabChanging(value);
                    this.SendPropertyChanging();
                    this._Javab = value;
                    this.SendPropertyChanged("Javab");
                    this.OnJavabChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeErsal", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeErsal
        {
            get
            {
                return this._DateTimeErsal;
            }
            set
            {
                if ((this._DateTimeErsal != value))
                {
                    this.OnDateTimeErsalChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeErsal = value;
                    this.SendPropertyChanged("DateTimeErsal");
                    this.OnDateTimeErsalChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeJavab", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeJavab
        {
            get
            {
                return this._DateTimeJavab;
            }
            set
            {
                if ((this._DateTimeJavab != value))
                {
                    this.OnDateTimeJavabChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeJavab = value;
                    this.SendPropertyChanged("DateTimeJavab");
                    this.OnDateTimeJavabChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateErsal", DbType = "NVarChar(10)")]
        public string DateErsal
        {
            get
            {
                return this._DateErsal;
            }
            set
            {
                if ((this._DateErsal != value))
                {
                    this.OnDateErsalChanging(value);
                    this.SendPropertyChanging();
                    this._DateErsal = value;
                    this.SendPropertyChanged("DateErsal");
                    this.OnDateErsalChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeErsal", DbType = "NVarChar(8)")]
        public string TimeErsal
        {
            get
            {
                return this._TimeErsal;
            }
            set
            {
                if ((this._TimeErsal != value))
                {
                    this.OnTimeErsalChanging(value);
                    this.SendPropertyChanging();
                    this._TimeErsal = value;
                    this.SendPropertyChanged("TimeErsal");
                    this.OnTimeErsalChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatePasokh", DbType = "NVarChar(10)")]
        public string DatePasokh
        {
            get
            {
                return this._DatePasokh;
            }
            set
            {
                if ((this._DatePasokh != value))
                {
                    this.OnDatePasokhChanging(value);
                    this.SendPropertyChanging();
                    this._DatePasokh = value;
                    this.SendPropertyChanged("DatePasokh");
                    this.OnDatePasokhChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimePasokh", DbType = "NVarChar(8)")]
        public string TimePasokh
        {
            get
            {
                return this._TimePasokh;
            }
            set
            {
                if ((this._TimePasokh != value))
                {
                    this.OnTimePasokhChanging(value);
                    this.SendPropertyChanging();
                    this._TimePasokh = value;
                    this.SendPropertyChanged("TimePasokh");
                    this.OnTimePasokhChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsRead", DbType = "Bit NOT NULL")]
        public bool IsRead
        {
            get
            {
                return this._IsRead;
            }
            set
            {
                if ((this._IsRead != value))
                {
                    this.OnIsReadChanging(value);
                    this.SendPropertyChanging();
                    this._IsRead = value;
                    this.SendPropertyChanged("IsRead");
                    this.OnIsReadChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NoeDarkhastId", DbType = "Int NOT NULL")]
        public int NoeDarkhastId
        {
            get
            {
                return this._NoeDarkhastId;
            }
            set
            {
                if ((this._NoeDarkhastId != value))
                {
                    if (this._NoeDarkhast.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnNoeDarkhastIdChanging(value);
                    this.SendPropertyChanging();
                    this._NoeDarkhastId = value;
                    this.SendPropertyChanged("NoeDarkhastId");
                    this.OnNoeDarkhastIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "NoeDarkhast_DarkhastMaskan", Storage = "_NoeDarkhast", ThisKey = "NoeDarkhastId", OtherKey = "id", IsForeignKey = true)]
        public NoeDarkhast NoeDarkhast
        {
            get
            {
                return this._NoeDarkhast.Entity;
            }
            set
            {
                NoeDarkhast previousValue = this._NoeDarkhast.Entity;
                if (((previousValue != value)
                            || (this._NoeDarkhast.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._NoeDarkhast.Entity = null;
                        previousValue.DarkhastMaskans.Remove(this);
                    }
                    this._NoeDarkhast.Entity = value;
                    if ((value != null))
                    {
                        value.DarkhastMaskans.Add(this);
                        this._NoeDarkhastId = value.id;
                    }
                    else
                    {
                        this._NoeDarkhastId = default(int);
                    }
                    this.SendPropertyChanged("NoeDarkhast");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}