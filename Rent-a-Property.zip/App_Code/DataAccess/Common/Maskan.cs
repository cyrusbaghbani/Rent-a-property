﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

namespace DataAccess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Maskan")]
    public partial class Maskan : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private System.Nullable<int> _TedadKhabId;

        private System.Nullable<int> _TabghaeForoshiId;

        private System.Nullable<decimal> _Mablagh_Rahn;

        private System.Nullable<decimal> _Mablagh_Ejare;

        private System.Nullable<decimal> _Metrazh;

        private string _DateTakhlie;

        private string _DateSabt_Persian;

        private System.Nullable<System.DateTime> _DateSabt_English;

        private System.Nullable<decimal> _Vam;

        private System.Nullable<decimal> _Ghymat;

        private System.Nullable<int> _MantagheId;

        private string _Dsc;

        private string _AddressKamel;

        private string _lat;

        private string _lng;

        private string _FullNameSahebkhane;

        private string _FullNameMostajer;

        private string _ShomareTelMostajer;

        private string _ShomareTelSahebkhane;

        private string _Dsc_ShakhsiBarayUser;

        private System.Nullable<int> _KilidId;

        private bool _IsParvandeMaskanBePayanResideAst;

        private string _Pelak;

        private System.Nullable<int> _DarbAzId;

        private System.Nullable<decimal> _Tol_Abad_Zamin;

        private System.Nullable<decimal> _Arz_Abad_Zamin;

        private System.Nullable<int> _NoeMoavezeId;

        private System.Nullable<int> _NoeMelkId;

        private System.Nullable<int> _TedadTabaghat;

        private string _code;

        private bool _IsDeleted;

        private System.Nullable<int> _MakanId;

        private string _AxShahrdari;

        private string _Dsc_Okazion;

        private System.Nullable<int> _Priority;

        private string _Title_Okaziom;

        private bool _IsOkazion;

        private string _LittleAddress_Baray_Namayesh_Dar_Site;

        private EntitySet<MaskanImage> _MaskanImages;

        private EntitySet<MaskanNoeKarbari> _MaskanNoeKarbaris;

        private EntityRef<DarbAz> _DarbAz;

        private EntityRef<Klid> _Klid;

        private EntityRef<Makan> _Makan;

        private EntityRef<Mantaghe> _Mantaghe;

        private EntityRef<NoeMelk> _NoeMelk;

        private EntityRef<NoeMoaveze> _NoeMoaveze;

        private EntityRef<Tabghe> _Tabghe;

        private EntityRef<TedadKhab> _TedadKhab;

        private bool _ShowInList = true;

        private bool _IsAgahi = false;

        private bool _IsAgahiRead = false;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnTedadKhabIdChanging(System.Nullable<int> value);
        partial void OnTedadKhabIdChanged();
        partial void OnTabghaeForoshiIdChanging(System.Nullable<int> value);
        partial void OnTabghaeForoshiIdChanged();
        partial void OnMablagh_RahnChanging(System.Nullable<decimal> value);
        partial void OnMablagh_RahnChanged();
        partial void OnMablagh_EjareChanging(System.Nullable<decimal> value);
        partial void OnMablagh_EjareChanged();
        partial void OnMetrazhChanging(System.Nullable<decimal> value);
        partial void OnMetrazhChanged();
        partial void OnDateTakhlieChanging(string value);
        partial void OnDateTakhlieChanged();
        partial void OnDateSabt_PersianChanging(string value);
        partial void OnDateSabt_PersianChanged();
        partial void OnDateSabt_EnglishChanging(System.Nullable<System.DateTime> value);
        partial void OnDateSabt_EnglishChanged();
        partial void OnVamChanging(System.Nullable<decimal> value);
        partial void OnVamChanged();
        partial void OnGhymatChanging(System.Nullable<decimal> value);
        partial void OnGhymatChanged();
        partial void OnMantagheIdChanging(System.Nullable<int> value);
        partial void OnMantagheIdChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnAddressKamelChanging(string value);
        partial void OnAddressKamelChanged();
        partial void OnlatChanging(string value);
        partial void OnlatChanged();
        partial void OnlngChanging(string value);
        partial void OnlngChanged();
        partial void OnFullNameSahebkhaneChanging(string value);
        partial void OnFullNameSahebkhaneChanged();
        partial void OnFullNameMostajerChanging(string value);
        partial void OnFullNameMostajerChanged();
        partial void OnShomareTelMostajerChanging(string value);
        partial void OnShomareTelMostajerChanged();
        partial void OnShomareTelSahebkhaneChanging(string value);
        partial void OnShomareTelSahebkhaneChanged();
        partial void OnDsc_ShakhsiBarayUserChanging(string value);
        partial void OnDsc_ShakhsiBarayUserChanged();
        partial void OnKilidIdChanging(System.Nullable<int> value);
        partial void OnKilidIdChanged();
        partial void OnIsParvandeMaskanBePayanResideAstChanging(bool value);
        partial void OnIsParvandeMaskanBePayanResideAstChanged();
        partial void OnPelakChanging(string value);
        partial void OnPelakChanged();
        partial void OnDarbAzIdChanging(System.Nullable<int> value);
        partial void OnDarbAzIdChanged();
        partial void OnTol_Abad_ZaminChanging(System.Nullable<decimal> value);
        partial void OnTol_Abad_ZaminChanged();
        partial void OnArz_Abad_ZaminChanging(System.Nullable<decimal> value);
        partial void OnArz_Abad_ZaminChanged();
        partial void OnNoeMoavezeIdChanging(System.Nullable<int> value);
        partial void OnNoeMoavezeIdChanged();
        partial void OnNoeMelkIdChanging(System.Nullable<int> value);
        partial void OnNoeMelkIdChanged();
        partial void OnTedadTabaghatChanging(System.Nullable<int> value);
        partial void OnTedadTabaghatChanged();
        partial void OncodeChanging(string value);
        partial void OncodeChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnMakanIdChanging(System.Nullable<int> value);
        partial void OnMakanIdChanged();
        partial void OnAxShahrdariChanging(string value);
        partial void OnAxShahrdariChanged();
        partial void OnDsc_OkazionChanging(string value);
        partial void OnDsc_OkazionChanged();
        partial void OnPriorityChanging(System.Nullable<int> value);
        partial void OnPriorityChanged();
        partial void OnTitle_OkaziomChanging(string value);
        partial void OnTitle_OkaziomChanged();
        partial void OnIsOkazionChanging(bool value);
        partial void OnIsOkazionChanged();
        partial void OnLittleAddress_Baray_Namayesh_Dar_SiteChanging(string value);
        partial void OnLittleAddress_Baray_Namayesh_Dar_SiteChanged();
        partial void OnShowInListChanging(bool value);
        partial void OnShowInListChanged();
        partial void OnIsAgahiChanging(bool value);
        partial void OnIsAgahiChanged();
        partial void OnIsAgahiReadChanging(bool value);
        partial void OnIsAgahiReadChanged();
        #endregion

        public Maskan()
        {
            this._MaskanImages = new EntitySet<MaskanImage>(new Action<MaskanImage>(this.attach_MaskanImages), new Action<MaskanImage>(this.detach_MaskanImages));
            this._MaskanNoeKarbaris = new EntitySet<MaskanNoeKarbari>(new Action<MaskanNoeKarbari>(this.attach_MaskanNoeKarbaris), new Action<MaskanNoeKarbari>(this.detach_MaskanNoeKarbaris));
            this._DarbAz = default(EntityRef<DarbAz>);
            this._Klid = default(EntityRef<Klid>);
            this._Makan = default(EntityRef<Makan>);
            this._Mantaghe = default(EntityRef<Mantaghe>);
            this._NoeMelk = default(EntityRef<NoeMelk>);
            this._NoeMoaveze = default(EntityRef<NoeMoaveze>);
            this._Tabghe = default(EntityRef<Tabghe>);
            this._TedadKhab = default(EntityRef<TedadKhab>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TedadKhabId", DbType = "Int")]
        public System.Nullable<int> TedadKhabId
        {
            get
            {
                return this._TedadKhabId;
            }
            set
            {
                if ((this._TedadKhabId != value))
                {
                    if (this._TedadKhab.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnTedadKhabIdChanging(value);
                    this.SendPropertyChanging();
                    this._TedadKhabId = value;
                    this.SendPropertyChanged("TedadKhabId");
                    this.OnTedadKhabIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TabghaeForoshiId", DbType = "Int")]
        public System.Nullable<int> TabghaeForoshiId
        {
            get
            {
                return this._TabghaeForoshiId;
            }
            set
            {
                if ((this._TabghaeForoshiId != value))
                {
                    if (this._Tabghe.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnTabghaeForoshiIdChanging(value);
                    this.SendPropertyChanging();
                    this._TabghaeForoshiId = value;
                    this.SendPropertyChanged("TabghaeForoshiId");
                    this.OnTabghaeForoshiIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Mablagh_Rahn", DbType = "Decimal(18,0)")]
        public System.Nullable<decimal> Mablagh_Rahn
        {
            get
            {
                return this._Mablagh_Rahn;
            }
            set
            {
                if ((this._Mablagh_Rahn != value))
                {
                    this.OnMablagh_RahnChanging(value);
                    this.SendPropertyChanging();
                    this._Mablagh_Rahn = value;
                    this.SendPropertyChanged("Mablagh_Rahn");
                    this.OnMablagh_RahnChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Mablagh_Ejare", DbType = "Decimal(18,0)")]
        public System.Nullable<decimal> Mablagh_Ejare
        {
            get
            {
                return this._Mablagh_Ejare;
            }
            set
            {
                if ((this._Mablagh_Ejare != value))
                {
                    this.OnMablagh_EjareChanging(value);
                    this.SendPropertyChanging();
                    this._Mablagh_Ejare = value;
                    this.SendPropertyChanged("Mablagh_Ejare");
                    this.OnMablagh_EjareChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Metrazh", DbType = "Decimal(18,0)")]
        public System.Nullable<decimal> Metrazh
        {
            get
            {
                return this._Metrazh;
            }
            set
            {
                if ((this._Metrazh != value))
                {
                    this.OnMetrazhChanging(value);
                    this.SendPropertyChanging();
                    this._Metrazh = value;
                    this.SendPropertyChanged("Metrazh");
                    this.OnMetrazhChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTakhlie", DbType = "NVarChar(500)")]
        public string DateTakhlie
        {
            get
            {
                return this._DateTakhlie;
            }
            set
            {
                if ((this._DateTakhlie != value))
                {
                    this.OnDateTakhlieChanging(value);
                    this.SendPropertyChanging();
                    this._DateTakhlie = value;
                    this.SendPropertyChanged("DateTakhlie");
                    this.OnDateTakhlieChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateSabt_Persian", DbType = "NVarChar(10)")]
        public string DateSabt_Persian
        {
            get
            {
                return this._DateSabt_Persian;
            }
            set
            {
                if ((this._DateSabt_Persian != value))
                {
                    this.OnDateSabt_PersianChanging(value);
                    this.SendPropertyChanging();
                    this._DateSabt_Persian = value;
                    this.SendPropertyChanged("DateSabt_Persian");
                    this.OnDateSabt_PersianChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateSabt_English", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateSabt_English
        {
            get
            {
                return this._DateSabt_English;
            }
            set
            {
                if ((this._DateSabt_English != value))
                {
                    this.OnDateSabt_EnglishChanging(value);
                    this.SendPropertyChanging();
                    this._DateSabt_English = value;
                    this.SendPropertyChanged("DateSabt_English");
                    this.OnDateSabt_EnglishChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Vam", DbType = "Decimal(18,0)")]
        public System.Nullable<decimal> Vam
        {
            get
            {
                return this._Vam;
            }
            set
            {
                if ((this._Vam != value))
                {
                    this.OnVamChanging(value);
                    this.SendPropertyChanging();
                    this._Vam = value;
                    this.SendPropertyChanged("Vam");
                    this.OnVamChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Ghymat", DbType = "Decimal(18,0)")]
        public System.Nullable<decimal> Ghymat
        {
            get
            {
                return this._Ghymat;
            }
            set
            {
                if ((this._Ghymat != value))
                {
                    this.OnGhymatChanging(value);
                    this.SendPropertyChanging();
                    this._Ghymat = value;
                    this.SendPropertyChanged("Ghymat");
                    this.OnGhymatChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MantagheId", DbType = "Int")]
        public System.Nullable<int> MantagheId
        {
            get
            {
                return this._MantagheId;
            }
            set
            {
                if ((this._MantagheId != value))
                {
                    if (this._Mantaghe.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMantagheIdChanging(value);
                    this.SendPropertyChanging();
                    this._MantagheId = value;
                    this.SendPropertyChanged("MantagheId");
                    this.OnMantagheIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LittleAddress_Baray_Namayesh_Dar_Site", DbType = "NVarChar(MAX)")]
        public string LittleAddress_Baray_Namayesh_Dar_Site
        {
            get
            {
                return this._LittleAddress_Baray_Namayesh_Dar_Site;
            }
            set
            {
                if ((this._LittleAddress_Baray_Namayesh_Dar_Site != value))
                {
                    this.OnLittleAddress_Baray_Namayesh_Dar_SiteChanging(value);
                    this.SendPropertyChanging();
                    this._LittleAddress_Baray_Namayesh_Dar_Site = value;
                    this.SendPropertyChanged("LittleAddress_Baray_Namayesh_Dar_Site");
                    this.OnLittleAddress_Baray_Namayesh_Dar_SiteChanged();
                }
            }
        }


        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AddressKamel", DbType = "NVarChar(MAX)")]
        public string AddressKamel
        {
            get
            {
                return this._AddressKamel;
            }
            set
            {
                if ((this._AddressKamel != value))
                {
                    this.OnAddressKamelChanging(value);
                    this.SendPropertyChanging();
                    this._AddressKamel = value;
                    this.SendPropertyChanged("AddressKamel");
                    this.OnAddressKamelChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_lat", DbType = "NVarChar(500)")]
        public string lat
        {
            get
            {
                return this._lat;
            }
            set
            {
                if ((this._lat != value))
                {
                    this.OnlatChanging(value);
                    this.SendPropertyChanging();
                    this._lat = value;
                    this.SendPropertyChanged("lat");
                    this.OnlatChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_lng", DbType = "NVarChar(500)")]
        public string lng
        {
            get
            {
                return this._lng;
            }
            set
            {
                if ((this._lng != value))
                {
                    this.OnlngChanging(value);
                    this.SendPropertyChanging();
                    this._lng = value;
                    this.SendPropertyChanged("lng");
                    this.OnlngChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FullNameSahebkhane", DbType = "NVarChar(500)")]
        public string FullNameSahebkhane
        {
            get
            {
                return this._FullNameSahebkhane;
            }
            set
            {
                if ((this._FullNameSahebkhane != value))
                {
                    this.OnFullNameSahebkhaneChanging(value);
                    this.SendPropertyChanging();
                    this._FullNameSahebkhane = value;
                    this.SendPropertyChanged("FullNameSahebkhane");
                    this.OnFullNameSahebkhaneChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FullNameMostajer", DbType = "NVarChar(500)")]
        public string FullNameMostajer
        {
            get
            {
                return this._FullNameMostajer;
            }
            set
            {
                if ((this._FullNameMostajer != value))
                {
                    this.OnFullNameMostajerChanging(value);
                    this.SendPropertyChanging();
                    this._FullNameMostajer = value;
                    this.SendPropertyChanged("FullNameMostajer");
                    this.OnFullNameMostajerChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ShomareTelMostajer", DbType = "NVarChar(500)")]
        public string ShomareTelMostajer
        {
            get
            {
                return this._ShomareTelMostajer;
            }
            set
            {
                if ((this._ShomareTelMostajer != value))
                {
                    this.OnShomareTelMostajerChanging(value);
                    this.SendPropertyChanging();
                    this._ShomareTelMostajer = value;
                    this.SendPropertyChanged("ShomareTelMostajer");
                    this.OnShomareTelMostajerChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ShomareTelSahebkhane", DbType = "NVarChar(500)")]
        public string ShomareTelSahebkhane
        {
            get
            {
                return this._ShomareTelSahebkhane;
            }
            set
            {
                if ((this._ShomareTelSahebkhane != value))
                {
                    this.OnShomareTelSahebkhaneChanging(value);
                    this.SendPropertyChanging();
                    this._ShomareTelSahebkhane = value;
                    this.SendPropertyChanged("ShomareTelSahebkhane");
                    this.OnShomareTelSahebkhaneChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc_ShakhsiBarayUser", DbType = "NVarChar(500)")]
        public string Dsc_ShakhsiBarayUser
        {
            get
            {
                return this._Dsc_ShakhsiBarayUser;
            }
            set
            {
                if ((this._Dsc_ShakhsiBarayUser != value))
                {
                    this.OnDsc_ShakhsiBarayUserChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc_ShakhsiBarayUser = value;
                    this.SendPropertyChanged("Dsc_ShakhsiBarayUser");
                    this.OnDsc_ShakhsiBarayUserChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_KilidId", DbType = "Int")]
        public System.Nullable<int> KilidId
        {
            get
            {
                return this._KilidId;
            }
            set
            {
                if ((this._KilidId != value))
                {
                    if (this._Klid.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnKilidIdChanging(value);
                    this.SendPropertyChanging();
                    this._KilidId = value;
                    this.SendPropertyChanged("KilidId");
                    this.OnKilidIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsParvandeMaskanBePayanResideAst", DbType = "Bit NOT NULL")]
        public bool IsParvandeMaskanBePayanResideAst
        {
            get
            {
                return this._IsParvandeMaskanBePayanResideAst;
            }
            set
            {
                if ((this._IsParvandeMaskanBePayanResideAst != value))
                {
                    this.OnIsParvandeMaskanBePayanResideAstChanging(value);
                    this.SendPropertyChanging();
                    this._IsParvandeMaskanBePayanResideAst = value;
                    this.SendPropertyChanged("IsParvandeMaskanBePayanResideAst");
                    this.OnIsParvandeMaskanBePayanResideAstChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Pelak", DbType = "NVarChar(500)")]
        public string Pelak
        {
            get
            {
                return this._Pelak;
            }
            set
            {
                if ((this._Pelak != value))
                {
                    this.OnPelakChanging(value);
                    this.SendPropertyChanging();
                    this._Pelak = value;
                    this.SendPropertyChanged("Pelak");
                    this.OnPelakChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DarbAzId", DbType = "Int")]
        public System.Nullable<int> DarbAzId
        {
            get
            {
                return this._DarbAzId;
            }
            set
            {
                if ((this._DarbAzId != value))
                {
                    if (this._DarbAz.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnDarbAzIdChanging(value);
                    this.SendPropertyChanging();
                    this._DarbAzId = value;
                    this.SendPropertyChanged("DarbAzId");
                    this.OnDarbAzIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Tol_Abad_Zamin", DbType = "Decimal(18,0)")]
        public System.Nullable<decimal> Tol_Abad_Zamin
        {
            get
            {
                return this._Tol_Abad_Zamin;
            }
            set
            {
                if ((this._Tol_Abad_Zamin != value))
                {
                    this.OnTol_Abad_ZaminChanging(value);
                    this.SendPropertyChanging();
                    this._Tol_Abad_Zamin = value;
                    this.SendPropertyChanged("Tol_Abad_Zamin");
                    this.OnTol_Abad_ZaminChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Arz_Abad_Zamin", DbType = "Decimal(18,0)")]
        public System.Nullable<decimal> Arz_Abad_Zamin
        {
            get
            {
                return this._Arz_Abad_Zamin;
            }
            set
            {
                if ((this._Arz_Abad_Zamin != value))
                {
                    this.OnArz_Abad_ZaminChanging(value);
                    this.SendPropertyChanging();
                    this._Arz_Abad_Zamin = value;
                    this.SendPropertyChanged("Arz_Abad_Zamin");
                    this.OnArz_Abad_ZaminChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NoeMoavezeId", DbType = "Int")]
        public System.Nullable<int> NoeMoavezeId
        {
            get
            {
                return this._NoeMoavezeId;
            }
            set
            {
                if ((this._NoeMoavezeId != value))
                {
                    if (this._NoeMoaveze.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnNoeMoavezeIdChanging(value);
                    this.SendPropertyChanging();
                    this._NoeMoavezeId = value;
                    this.SendPropertyChanged("NoeMoavezeId");
                    this.OnNoeMoavezeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NoeMelkId", DbType = "Int")]
        public System.Nullable<int> NoeMelkId
        {
            get
            {
                return this._NoeMelkId;
            }
            set
            {
                if ((this._NoeMelkId != value))
                {
                    if (this._NoeMelk.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnNoeMelkIdChanging(value);
                    this.SendPropertyChanging();
                    this._NoeMelkId = value;
                    this.SendPropertyChanged("NoeMelkId");
                    this.OnNoeMelkIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TedadTabaghat", DbType = "Int")]
        public System.Nullable<int> TedadTabaghat
        {
            get
            {
                return this._TedadTabaghat;
            }
            set
            {
                if ((this._TedadTabaghat != value))
                {
                    this.OnTedadTabaghatChanging(value);
                    this.SendPropertyChanging();
                    this._TedadTabaghat = value;
                    this.SendPropertyChanged("TedadTabaghat");
                    this.OnTedadTabaghatChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_code", DbType = "NVarChar(500)")]
        public string code
        {
            get
            {
                return this._code;
            }
            set
            {
                if ((this._code != value))
                {
                    this.OncodeChanging(value);
                    this.SendPropertyChanging();
                    this._code = value;
                    this.SendPropertyChanged("code");
                    this.OncodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MakanId", DbType = "Int")]
        public System.Nullable<int> MakanId
        {
            get
            {
                return this._MakanId;
            }
            set
            {
                if ((this._MakanId != value))
                {
                    if (this._Makan.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMakanIdChanging(value);
                    this.SendPropertyChanging();
                    this._MakanId = value;
                    this.SendPropertyChanged("MakanId");
                    this.OnMakanIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Maskan_MaskanImage", Storage = "_MaskanImages", ThisKey = "Id", OtherKey = "MaskanId")]
        public EntitySet<MaskanImage> MaskanImages
        {
            get
            {
                return this._MaskanImages;
            }
            set
            {
                this._MaskanImages.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Maskan_MaskanNoeKarbari", Storage = "_MaskanNoeKarbaris", ThisKey = "Id", OtherKey = "MaskanId")]
        public EntitySet<MaskanNoeKarbari> MaskanNoeKarbaris
        {
            get
            {
                return this._MaskanNoeKarbaris;
            }
            set
            {
                this._MaskanNoeKarbaris.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "DarbAz_Maskan", Storage = "_DarbAz", ThisKey = "DarbAzId", OtherKey = "Id", IsForeignKey = true)]
        public DarbAz DarbAz
        {
            get
            {
                return this._DarbAz.Entity;
            }
            set
            {
                DarbAz previousValue = this._DarbAz.Entity;
                if (((previousValue != value)
                            || (this._DarbAz.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._DarbAz.Entity = null;
                        previousValue.Maskans.Remove(this);
                    }
                    this._DarbAz.Entity = value;
                    if ((value != null))
                    {
                        value.Maskans.Add(this);
                        this._DarbAzId = value.Id;
                    }
                    else
                    {
                        this._DarbAzId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("DarbAz");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Klid_Maskan", Storage = "_Klid", ThisKey = "KilidId", OtherKey = "Id", IsForeignKey = true)]
        public Klid Klid
        {
            get
            {
                return this._Klid.Entity;
            }
            set
            {
                Klid previousValue = this._Klid.Entity;
                if (((previousValue != value)
                            || (this._Klid.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Klid.Entity = null;
                        previousValue.Maskans.Remove(this);
                    }
                    this._Klid.Entity = value;
                    if ((value != null))
                    {
                        value.Maskans.Add(this);
                        this._KilidId = value.Id;
                    }
                    else
                    {
                        this._KilidId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Klid");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Makan_Maskan", Storage = "_Makan", ThisKey = "MakanId", OtherKey = "Id", IsForeignKey = true)]
        public Makan Makan
        {
            get
            {
                return this._Makan.Entity;
            }
            set
            {
                Makan previousValue = this._Makan.Entity;
                if (((previousValue != value)
                            || (this._Makan.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Makan.Entity = null;
                        previousValue.Maskans.Remove(this);
                    }
                    this._Makan.Entity = value;
                    if ((value != null))
                    {
                        value.Maskans.Add(this);
                        this._MakanId = value.Id;
                    }
                    else
                    {
                        this._MakanId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Makan");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Mantaghe_Maskan", Storage = "_Mantaghe", ThisKey = "MantagheId", OtherKey = "Id", IsForeignKey = true)]
        public Mantaghe Mantaghe
        {
            get
            {
                return this._Mantaghe.Entity;
            }
            set
            {
                Mantaghe previousValue = this._Mantaghe.Entity;
                if (((previousValue != value)
                            || (this._Mantaghe.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Mantaghe.Entity = null;
                        previousValue.Maskans.Remove(this);
                    }
                    this._Mantaghe.Entity = value;
                    if ((value != null))
                    {
                        value.Maskans.Add(this);
                        this._MantagheId = value.Id;
                    }
                    else
                    {
                        this._MantagheId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Mantaghe");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "NoeMelk_Maskan", Storage = "_NoeMelk", ThisKey = "NoeMelkId", OtherKey = "Id", IsForeignKey = true)]
        public NoeMelk NoeMelk
        {
            get
            {
                return this._NoeMelk.Entity;
            }
            set
            {
                NoeMelk previousValue = this._NoeMelk.Entity;
                if (((previousValue != value)
                            || (this._NoeMelk.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._NoeMelk.Entity = null;
                        previousValue.Maskans.Remove(this);
                    }
                    this._NoeMelk.Entity = value;
                    if ((value != null))
                    {
                        value.Maskans.Add(this);
                        this._NoeMelkId = value.Id;
                    }
                    else
                    {
                        this._NoeMelkId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("NoeMelk");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "NoeMoaveze_Maskan", Storage = "_NoeMoaveze", ThisKey = "NoeMoavezeId", OtherKey = "Id", IsForeignKey = true)]
        public NoeMoaveze NoeMoaveze
        {
            get
            {
                return this._NoeMoaveze.Entity;
            }
            set
            {
                NoeMoaveze previousValue = this._NoeMoaveze.Entity;
                if (((previousValue != value)
                            || (this._NoeMoaveze.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._NoeMoaveze.Entity = null;
                        previousValue.Maskans.Remove(this);
                    }
                    this._NoeMoaveze.Entity = value;
                    if ((value != null))
                    {
                        value.Maskans.Add(this);
                        this._NoeMoavezeId = value.Id;
                    }
                    else
                    {
                        this._NoeMoavezeId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("NoeMoaveze");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Tabghe_Maskan", Storage = "_Tabghe", ThisKey = "TabghaeForoshiId", OtherKey = "Id", IsForeignKey = true)]
        public Tabghe Tabghe
        {
            get
            {
                return this._Tabghe.Entity;
            }
            set
            {
                Tabghe previousValue = this._Tabghe.Entity;
                if (((previousValue != value)
                            || (this._Tabghe.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Tabghe.Entity = null;
                        previousValue.Maskans.Remove(this);
                    }
                    this._Tabghe.Entity = value;
                    if ((value != null))
                    {
                        value.Maskans.Add(this);
                        this._TabghaeForoshiId = value.Id;
                    }
                    else
                    {
                        this._TabghaeForoshiId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Tabghe");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "TedadKhab_Maskan", Storage = "_TedadKhab", ThisKey = "TedadKhabId", OtherKey = "id", IsForeignKey = true)]
        public TedadKhab TedadKhab
        {
            get
            {
                return this._TedadKhab.Entity;
            }
            set
            {
                TedadKhab previousValue = this._TedadKhab.Entity;
                if (((previousValue != value)
                            || (this._TedadKhab.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._TedadKhab.Entity = null;
                        previousValue.Maskans.Remove(this);
                    }
                    this._TedadKhab.Entity = value;
                    if ((value != null))
                    {
                        value.Maskans.Add(this);
                        this._TedadKhabId = value.id;
                    }
                    else
                    {
                        this._TedadKhabId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("TedadKhab");
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AxShahrdari", DbType = "NVarChar(MAX)")]
        public string AxShahrdari
        {
            get
            {
                return this._AxShahrdari;
            }
            set
            {
                if ((this._AxShahrdari != value))
                {
                    this.OnAxShahrdariChanging(value);
                    this.SendPropertyChanging();
                    this._AxShahrdari = value;
                    this.SendPropertyChanged("AxShahrdari");
                    this.OnAxShahrdariChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc_Okazion", DbType = "NVarChar(MAX)")]
        public string Dsc_Okazion
        {
            get
            {
                return this._Dsc_Okazion;
            }
            set
            {
                if ((this._Dsc_Okazion != value))
                {
                    this.OnDsc_OkazionChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc_Okazion = value;
                    this.SendPropertyChanged("Dsc_Okazion");
                    this.OnDsc_OkazionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Priority", DbType = "Int")]
        public System.Nullable<int> Priority
        {
            get
            {
                return this._Priority;
            }
            set
            {
                if ((this._Priority != value))
                {
                    this.OnPriorityChanging(value);
                    this.SendPropertyChanging();
                    this._Priority = value;
                    this.SendPropertyChanged("Priority");
                    this.OnPriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Title_Okaziom", DbType = "NVarChar(500)")]
        public string Title_Okaziom
        {
            get
            {
                return this._Title_Okaziom;
            }
            set
            {
                if ((this._Title_Okaziom != value))
                {
                    this.OnTitle_OkaziomChanging(value);
                    this.SendPropertyChanging();
                    this._Title_Okaziom = value;
                    this.SendPropertyChanged("Title_Okaziom");
                    this.OnTitle_OkaziomChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsOkazion", DbType = "Bit NOT NULL")]
        public bool IsOkazion
        {
            get
            {
                return this._IsOkazion;
            }
            set
            {
                if ((this._IsOkazion != value))
                {
                    this.OnIsOkazionChanging(value);
                    this.SendPropertyChanging();
                    this._IsOkazion = value;
                    this.SendPropertyChanged("IsOkazion");
                    this.OnIsOkazionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ShowInList", DbType = "Bit NOT NULL")]
        public bool ShowInList
        {
            get
            {
                return this._ShowInList;
            }
            set
            {
                if ((this._ShowInList != value))
                {
                    this.OnShowInListChanging(value);
                    this.SendPropertyChanging();
                    this._ShowInList = value;
                    this.SendPropertyChanged("ShowInList");
                    this.OnShowInListChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsAgahi", DbType = "Bit NOT NULL")]
        public bool IsAgahi
        {
            get
            {
                return this._IsAgahi;
            }
            set
            {
                if ((this._IsAgahi != value))
                {
                    this.OnIsAgahiChanging(value);
                    this.SendPropertyChanging();
                    this._IsAgahi = value;
                    this.SendPropertyChanged("IsAgahi");
                    this.OnIsAgahiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsAgahiRead", DbType = "Bit NOT NULL")]
        public bool IsAgahiRead
        {
            get
            {
                return this._IsAgahiRead;
            }
            set
            {
                if ((this._IsAgahiRead != value))
                {
                    this.OnIsAgahiReadChanging(value);
                    this.SendPropertyChanging();
                    this._IsAgahiRead = value;
                    this.SendPropertyChanged("IsAgahiRead");
                    this.OnIsAgahiReadChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_MaskanImages(MaskanImage entity)
        {
            this.SendPropertyChanging();
            entity.Maskan = this;
        }

        private void detach_MaskanImages(MaskanImage entity)
        {
            this.SendPropertyChanging();
            entity.Maskan = null;
        }

        private void attach_MaskanNoeKarbaris(MaskanNoeKarbari entity)
        {
            this.SendPropertyChanging();
            entity.Maskan = this;
        }

        private void detach_MaskanNoeKarbaris(MaskanNoeKarbari entity)
        {
            this.SendPropertyChanging();
            entity.Maskan = null;
        }
    }
}