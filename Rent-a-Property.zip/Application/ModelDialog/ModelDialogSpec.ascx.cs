﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_ModelDialog_ModelDialogSpec : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        dbMaskanDataContext dc=new dbMaskanDataContext();
        litScript_Show_Dialog.Text = "";
        cboNoeMelk_EtelaatSystemi.DataSource = dc.NoeMelks.Where(s => s.GROUPTYPE == "ZAMIN").OrderBy(s => s.priority).ToList();
        cboNoeMelk_EtelaatSystemi.DataBind();
        cboNoeMelk_EtelaatSystemi.Items.Insert(0,new ListItem("انتخاب کنید",""));
    }
    public void ShowErrorMessage(string msg)
    {
        DIV_CONTENT_TEXT.InnerHtml = msg;
        DIV_TITLE_TEXT.InnerHtml = "خطا";
        DIV_TITLE_TEXT.Style.Add("color", "#f44619");
        DIVLINE_HEADER_CONTENT.Style.Add("background-color", "#f44619");
        Img_Help_ICON_Dialog.ImageUrl = "~/Application/Images/DialogIcon/error-64.png";
        litScript_Show_Dialog.Text = " <script type=\"text/javascript\">   setTimeout(ShowModelDialog, 500); </script> ";
        DIV_FORGOT_PASSWORD_DIALOG_INFO.Style.Add("display", "none");
    }
    public void ShowInfoMessage(string msg)
    {
        DIV_CONTENT_TEXT.InnerHtml = msg;
        DIV_TITLE_TEXT.InnerHtml = "اطلاعات";
        DIV_TITLE_TEXT.Style.Add("color", "#19b2e8");
        DIVLINE_HEADER_CONTENT.Style.Add("background-color", "#19b2e8");
        Img_Help_ICON_Dialog.ImageUrl = "~/Application/Images/DialogIcon/help-64.png";
        litScript_Show_Dialog.Text = " <script type=\"text/javascript\">   setTimeout(ShowModelDialog, 500); </script> ";
        DIV_FORGOT_PASSWORD_DIALOG_INFO.Style.Add("display", "none");
    }
    public void ShowSeccessMessage(string msg)
    {

        DIV_CONTENT_TEXT.InnerHtml = msg;
        DIV_TITLE_TEXT.InnerHtml = "پیام";
        DIV_TITLE_TEXT.Style.Add("color", "green");
        DIVLINE_HEADER_CONTENT.Style.Add("background-color", "green");
        Img_Help_ICON_Dialog.ImageUrl = "~/Application/Images/DialogIcon/ok-64.png";
        litScript_Show_Dialog.Text = " <script type=\"text/javascript\">   setTimeout(ShowModelDialog, 500); </script> ";
        DIV_FORGOT_PASSWORD_DIALOG_INFO.Style.Add("display", "none");
    }

    public string GetEmailFromForgatPassword()
    {
        return txtbox_EMAIL_DIALOG.Text.Trim();
    }

    public string GetName_EtelaatSystemi()
    {
        return txtName_EtelaatSystemi.Text.Trim();
    }
    public int? Getpriority_EtelaatSystemi()
    {
        int tmp = 0;
        return int.TryParse(txtpriority_EtelaatSystemi.Text.Trim(), out tmp) ? tmp : (int?)null;
    }

    public string GetValue_EtelaatSystemi_NoeKarbari_NoeMelkValue()
    {
        return hf_EtelaatSystemi_NoeMelkCambo.Value;
    }




}