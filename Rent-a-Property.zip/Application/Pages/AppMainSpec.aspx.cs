﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Pages_AppMainSpec : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        cboVaziatMelk.Focus();
        Form.DefaultButton = btnsave.UniqueID;
        if (!IsPostBack)
        {
            BindCambo();
            Display();
        }
        setLatlng();
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {

        List<string> LstTempid_image = new List<string>();
        foreach (var q in hfImageIds.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_image.Add(q.Replace("Temp", ""));
            }
        }
        DeleteList(LstTempid_image);
        ReturnToLastPage();
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (Checkvalidate())
        {
            Save();
            ReturnToLastPage();
        }
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        BindFileUploadImage();
    }
    protected void lstImagegallery_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "DeleteImage")
        {
            DeleteImage(e.CommandArgument.ToString());
            ldsresultImage.RaiseViewChanged();
        }
    }

    protected void ldsresultImage_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }

    private object Search()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        List<string> Lstid_image = new List<string>();
        List<string> LstTempid_image = new List<string>();
        foreach (var q in hfImageIds.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_image.Add(q.Replace("Temp", ""));
            }
            else
            {
                Lstid_image.Add(q);
            }
        }


        var queryTempImages = (from p in dc.TempImages
                               where
                                LstTempid_image.Contains(p.UID.ToString())
                               select new
                               {
                                   Url = "~" + ImagePath + p.Address,
                                   UID = "Temp" + p.UID.ToString().ToLower()
                               }).ToList();
        var queryImages = (from p in dc.MaskanImages
                           where
                            Lstid_image.Contains(p.UID.ToString())
                            &&
                            p.MaskanId.ToString() == ID
                           select new
                           {
                               Url = "~" + ImagePath + p.Address,
                               UID = p.UID.ToString().ToLower()
                           }).ToList();
        return queryTempImages.Concat(queryImages);
    }

    private void BindCambo()
    {
        cboNeMoaveze.DataSource = dc.NoeMoavezes.OrderBy(s => s.priority);
        cboNeMoaveze.DataBind();
        cboNeMoaveze.Items.Insert(0, new ListItem("انتخاب کنید", "0"));

        cboNoeMelk.DataSource = dc.NoeMelks.OrderBy(s => s.priority);
        cboNoeMelk.DataBind();
        cboNoeMelk.Items.Insert(0, new ListItem("انتخاب کنید", "0"));

        cboTedadKhab.DataSource = dc.TedadKhabs.OrderBy(s => s.priority);
        cboTedadKhab.DataBind();
        cboTedadKhab.Items.Insert(0, new ListItem("انتخاب کنید", "0"));

        cboTabagheForosh.DataSource = dc.Tabghes.OrderBy(s => s.priority);
        cboTabagheForosh.DataBind();
        cboTabagheForosh.Items.Insert(0, new ListItem("انتخاب کنید", "0"));

        cboKlid.DataSource = dc.Klids.OrderBy(s => s.priority);
        cboKlid.DataBind();
        cboKlid.Items.Insert(0, new ListItem("انتخاب کنید", "0"));
    }
    private void Display()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == ID);
        if (obj == null)
            return;
        if (obj.IsDeleted)
            ReturnToLastPage();

        if (obj.IsParvandeMaskanBePayanResideAst == true)
            cboVaziatMelk.SelectedIndex = 1;
        else
            cboVaziatMelk.SelectedIndex = 0;

        txtCode.Text = obj.code;
        if (obj.NoeMoavezeId == null)
            cboNeMoaveze.SelectedIndex = 0;
        else
            cboNeMoaveze.SelectedValue = obj.NoeMoavezeId.ToString();

        if (obj.NoeMelkId == null)
            cboNoeMelk.SelectedIndex = 0;
        else
            cboNoeMelk.SelectedValue = obj.NoeMelkId.ToString();

        if (obj.TedadKhabId == null)
            cboTedadKhab.SelectedIndex = 0;
        else
            cboTedadKhab.SelectedValue = obj.TedadKhabId.ToString();

        if (obj.TabghaeForoshiId == null)
            cboTabagheForosh.SelectedIndex = 0;
        else
            cboTabagheForosh.SelectedValue = obj.TabghaeForoshiId.ToString();

        txtTedadTabaghatMelk.Text = obj.TedadTabaghat == null ? "" : obj.TedadTabaghat.ToString();
        txtMetrazh.Text = obj.Metrazh == null ? "" : obj.Metrazh.Value.ToString("###,###");
        txtTarikhTakhlie.Text = obj.DateTakhlie;

        if (obj.KilidId == null)
            cboKlid.SelectedIndex = 0;
        else
            cboKlid.SelectedValue = obj.KilidId.ToString();

        //txtMantaghe.Text = obj.Mantaghe;
        txtPlak.Text = obj.Pelak;
        txtAddresskamel.Text = obj.AddressKamel;
        txtlat.Text = obj.lat;
        txtlng.Text = obj.lng;
        hflatlng.Value = obj.lat + "," + obj.lng;
        txtTol.Text = obj.Tol_Abad_Zamin == null ? "" : obj.Tol_Abad_Zamin.Value.ToString("###,###");
        txtVam.Text = obj.Vam == null ? "" : obj.Vam.Value.ToString("###,###");
        txtArz.Text = obj.Arz_Abad_Zamin == null ? "" : obj.Arz_Abad_Zamin.Value.ToString("###,###");
        txtGhymatMelk.Text = obj.Ghymat == null ? "" : obj.Ghymat.Value.ToString("###,###");
        txtRahn.Text = obj.Mablagh_Rahn == null ? "" : obj.Mablagh_Rahn.Value.ToString("###,###");
        txtEjare.Text = obj.Mablagh_Ejare == null ? "" : obj.Mablagh_Ejare.Value.ToString("###,###");
        txtDscNamayeshDarsait.Text = obj.Dsc;
        txtDsc_Malek.Text = obj.Dsc_ShakhsiBarayUser;
        txtFullNameMostajer.Text = obj.FullNameMostajer;
        txtFullNameSahebkhane.Text = obj.FullNameSahebkhane;
        txtShomareTelMostajer.Text = obj.ShomareTelMostajer;
        txtShomareTelSahebkhane.Text = obj.ShomareTelSahebkhane;

        if (obj.MaskanImages.Any())
            hfImageIds.Value = obj.MaskanImages.Select(s => s.UID.ToString().ToLower()).Aggregate((a, b) => a + "," + b) + ",";
        else
            hfImageIds.Value = "";

    }
    private void Save()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == ID);
        if (obj == null)
        {
            obj = new Maskan();
            dc.Maskans.InsertOnSubmit(obj);
        }

        obj.IsParvandeMaskanBePayanResideAst = cboVaziatMelk.SelectedIndex == 1;
        obj.code = txtCode.Text.Trim();
        obj.NoeMoaveze = dc.NoeMoavezes.SingleOrDefault(s => s.Id.ToString() == cboNeMoaveze.SelectedValue);
        obj.NoeMelk = dc.NoeMelks.SingleOrDefault(s => s.Id.ToString() == cboNoeMelk.SelectedValue);
        obj.TedadKhab = dc.TedadKhabs.SingleOrDefault(s => s.id.ToString() == cboTedadKhab.SelectedValue);
        obj.Tabghe = dc.Tabghes.SingleOrDefault(s => s.Id.ToString() == cboTabagheForosh.SelectedValue);
        obj.TedadTabaghat = txtTedadTabaghatMelk.Text.Replace(",", "").Trim() == "" ? (int?)null : int.Parse(txtTedadTabaghatMelk.Text.Replace(",", "").Trim());
        obj.Metrazh = txtMetrazh.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtMetrazh.Text.Replace(",", "").Trim());
        obj.DateTakhlie = txtTarikhTakhlie.Text.Trim();
        obj.Klid = dc.Klids.SingleOrDefault(s => s.Id.ToString() == cboKlid.SelectedValue);
       // obj.Mantaghe = txtMantaghe.Text.Trim();
        obj.Pelak = txtPlak.Text.Trim();
        obj.AddressKamel = txtAddresskamel.Text.Trim();
        obj.lat = hflatlng.Value.Split(',')[0];
        obj.lng = hflatlng.Value.Split(',')[1];
        obj.Tol_Abad_Zamin = txtTol.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtTol.Text.Replace(",", "").Trim());
        obj.Arz_Abad_Zamin = txtArz.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtArz.Text.Replace(",", "").Trim());
        obj.Vam = txtVam.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtVam.Text.Replace(",", "").Trim());
        obj.Ghymat = txtGhymatMelk.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtGhymatMelk.Text.Replace(",", "").Trim());
        obj.Mablagh_Rahn = txtRahn.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtRahn.Text.Replace(",", "").Trim());
        obj.Mablagh_Ejare = txtEjare.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtEjare.Text.Replace(",", "").Trim());
        obj.Dsc = txtDscNamayeshDarsait.Text.Trim();
        obj.Dsc_ShakhsiBarayUser = txtDsc_Malek.Text.Trim();
        obj.FullNameMostajer = txtFullNameMostajer.Text.Trim();
        obj.FullNameSahebkhane = txtFullNameSahebkhane.Text.Trim();
        obj.ShomareTelMostajer = txtShomareTelMostajer.Text.Trim();
        obj.ShomareTelSahebkhane = txtShomareTelSahebkhane.Text.Trim();
        dc.SubmitChanges();
        List<string> Lstid_image = new List<string>();
        List<string> LstTempid_image = new List<string>();
        foreach (var q in hfImageIds.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_image.Add(q.Replace("Temp", ""));
            }
            else
            {
                Lstid_image.Add(q);
            }
        }

        List<MaskanImage> lstDeleteMaskan = dc.MaskanImages.Where(s => s.MaskanId == obj.Id && !Lstid_image.Contains(s.UID.ToString())).ToList();
        List<string> lstadr = lstDeleteMaskan.Any() ? (new List<string>()) : lstDeleteMaskan.Select(s => s.Address).ToList();

        if (lstDeleteMaskan.Any())
            dc.MaskanImages.DeleteAllOnSubmit(lstDeleteMaskan);

        foreach (var str in LstTempid_image)
        {
            var tmp = dc.TempImages.SingleOrDefault(s => s.UID.ToString() == str);
            if (tmp == null)
                return;

            var newimg = new MaskanImage();
            newimg.UID = Guid.NewGuid();
            newimg.Maskan = obj;
            newimg.Address = newimg.UID.ToString() + Path.GetExtension(tmp.Address);
            dc.MaskanImages.InsertOnSubmit(newimg);
            dc.TempImages.DeleteOnSubmit(tmp);
            string path = Server.MapPath("~" + ImagePath + tmp.Address);
            if (File.Exists(path))
                File.Move(path, Server.MapPath("~" + ImagePath + newimg.Address));

        }

        dc.SubmitChanges();


        DeleteList(lstadr);

    }
    private void setLatlng()
    {
        txtlat.Text = hflatlng.Value.Split(',')[0];
        txtlng.Text = hflatlng.Value.Split(',')[1];
    }
    private void DeleteList(List<string> lstadr)
    {
        foreach (var str in lstadr)
        {
            try
            {
                string path = Server.MapPath("~" + ImagePath + str);
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
            catch
            {
            }
        }
    }
    private bool Checkvalidate()
    {
        bool result = true;
        string Msg = "لطفا به نکات زیر توجه نمایید : " + "</br>";
        decimal Tmp = 0;
        int i = 0;

        if (txtCode.Text.Trim() == "")
        {
            Msg += (++i).ToString() + " - " + "لطفا کد را وارد نمایید." + "</br>";
            result = false;
        }
        if (cboNeMoaveze.SelectedIndex == 0)
        {
            Msg += (++i).ToString() + " - " + "نوع معامله را مشخص نمایید" + "</br>";
            result = false;
        }
        if (cboNoeMelk.SelectedIndex == 0)
        {
            Msg += (++i).ToString() + " - " + "نوع ملک را وارد نمایید" + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtTedadTabaghatMelk.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "تعداد طبقات ملک را صحیح وارد نمایید" + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtMetrazh.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "متراژ را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtTol.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "طول زمین را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtArz.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "عرض زمین را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtVam.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "وام را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtGhymatMelk.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "قیمت ملک را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtRahn.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "رهن را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtEjare.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "اجاره را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }

        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }
    private void ReturnToLastPage()
    {
        Response.Redirect(ArssPayamUtility.GetEncodedQueryString("AppMain.aspx?args={0}", "index=old"));
    }


    private void BindFileUploadImage()
    {
        if (fuImage.HasFile)
            CheckSelectedFile(fuImage, 204800);
    }

    /// <summary>
    /// چک می کند که آیا فایل آپلود شده با فرمت های خواسته شده تطابق دارد یا خیر
    /// </summary>
    /// <param name="fu">کامپوننت فایل آپلودی که از آن استفاده شده تا عکس را انتخاب کند</param>
    /// <param name="lenght">اندازه ی عکس</param>
    /// <param name="message">نام عکس</param>
    /// <param name="sessionName">پارامتری که اگر عکس به صورت موقت وجود داشته باشد در آن است</param>
    /// <param name="img">کامپوننت عکس که قرار است عکس روی آن نمایش داده شود</param>
    /// <param name="btn">دکمه حذف عکس</param>
    /// <param name="lnk">لینک مخصوص به دانلود عکس</param>
    private void CheckSelectedFile(FileUpload fu, int lenght)
    {
        string[] contentTypes = { "image/pjpeg", "image/jpeg", "image/x-png", "image/png" };//فرمت های مجاز
        string[] extention = { ".jpg", ".jpeg", ".png" };//پسوند های مجاز

        if (!fu.HasFile)//اگر فایل آپلود آدرس عکس را داشت
            ShowErrorMessage("لطفا تصویر " + "مورد نظر" + " را انتخاب نمایید.");
        else if (fu.HasFile && !contentTypes.Contains(fu.PostedFile.ContentType.ToString()))//اگر عکس وجود دارد آیا فرمت ها را رعایت کرده است
            ShowErrorMessage("لطفا تصویر " + "مورد نظر" + " را متناسب با ویژگی های داده شده انتخاب نمایید.");
        else
        {

            var obj = new TempImage();
            obj.UID = Guid.NewGuid();
            obj.Address = "Temp" + obj.UID + Path.GetExtension(fu.FileName);
            dc.TempImages.InsertOnSubmit(obj);
            dc.SubmitChanges();
            fu.SaveAs(Server.MapPath("~" + ImagePath + obj.Address));//به صورت موقت عکس را ذخیره کرد
            hfImageIds.Value += "Temp" + obj.UID + ",";
            ldsresultImage.RaiseViewChanged();
        }
    }
    private void DeleteImage(string Id)
    {
        hfImageIds.Value = hfImageIds.Value.Replace(Id + ",", "");
        if (!Id.StartsWith("Temp"))
        {
            ldsresultImage.RaiseViewChanged();
            return;
        }
        Id = Id.Replace("Temp", "");
        var obj = dc.TempImages.SingleOrDefault(s => s.UID.ToString() == Id);
        if (obj != null)
        {
            try
            {
                string path = Server.MapPath("~" + ImagePath + obj.Address);
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
                dc.TempImages.DeleteOnSubmit(obj);
            }
            catch { }
        }
        dc.SubmitChanges();
        ldsresultImage.RaiseViewChanged();
    }
}