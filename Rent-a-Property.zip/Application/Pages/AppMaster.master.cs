﻿using Limilabs.Client.IMAP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Application_Pages_AppMaster : BaseMaster
{
    protected void Page_Load(object sender, EventArgs e)
    {

        Display();
        ActiveMenu();
    }

    private void Display()
    {
        dbMaskanDataContext dc = new dbMaskanDataContext();
        lblFullname.Text = " نام کاربری : " + CurrentUser.FullName;
        lblcurrentDate.Text = "تاریخ جاری : " + DateShamsi.GetShamsiDayOfWeek((DayOfWeek)DateShamsi.GetDayOfWeek(DateShamsi.GetCurrentDate()))
            + " " + DateShamsi.GetCurrentDate().Split('/')[2]
            + " " + DateShamsi.GetShamsiMonth(int.Parse(DateShamsi.GetCurrentDate().Split('/')[1]))
            + " " + DateShamsi.GetCurrentDate().Split('/')[0];

        int count = dc.DarkhastMaskans.Count(s => s.IsRead == false && s.IsDeleted == false);
        liDarkhastMaskan.Text = "درخواست مسکن " + (count == 0 ? "" : ("(" + count + ")"));

        int mailcount = Mailer.CountMail();
        liMail.Text = "صندوق پیام " + (mailcount == 0 ? "" : ("(" + mailcount + ")"));


        var objs = dc.Maskans.Where(s => s.IsDeleted == false && s.IsAgahi == true && s.IsAgahiRead == false && s.ShowInList == false && s.NoeMelkId != null && s.NoeMoavezeId != null).Select(s => new { Gtype = s.NoeMelk.GROUPTYPE, noemoaveze = s.NoeMoavezeId }).ToList();

        if (objs.Any(s => s.Gtype == "MELK" && s.noemoaveze == (int)(DataValueIds.NoeMoavezeIds.RahnVaEjare)))
        {
            liRahnVaEjareMelk.Text = "رهن و اجاره ملک (" + objs.Count(s => s.Gtype == "MELK" && s.noemoaveze == (int)(DataValueIds.NoeMoavezeIds.RahnVaEjare)) + ")";
        }
        if (objs.Any(s => s.Gtype == "MELK" && (s.noemoaveze == (int)(DataValueIds.NoeMoavezeIds.KharidVaForosh) || s.noemoaveze == (int)(DataValueIds.NoeMoavezeIds.PishForosh))))
        {
            liKharidvaforoshMelk.Text = "خرید و فروش ملک (" + objs.Count(s => s.Gtype == "MELK" && (s.noemoaveze == (int)(DataValueIds.NoeMoavezeIds.KharidVaForosh) || s.noemoaveze == (int)(DataValueIds.NoeMoavezeIds.PishForosh))) + ")";
        }
        if (objs.Any(s => s.Gtype == "ZAMIN" && s.noemoaveze == (int)(DataValueIds.NoeMoavezeIds.KharidVaForosh)))
        {
            liZamin.Text = "باغ شهری و زمین (" + objs.Count(s => s.Gtype == "ZAMIN" && s.noemoaveze == (int)(DataValueIds.NoeMoavezeIds.KharidVaForosh)) + ")";
        }
    }
    private void ActiveMenu()
    {
        string currenturl = HttpContext.Current.Request.Url.AbsolutePath;
        if (currenturl.ToLower().Contains("melks.aspx") || currenturl.ToLower().Contains("melkspec.aspx"))
        {
            liRahnVaEjareMelk.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("profile.aspx"))
        {
            liProfile.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("okazion.aspx"))
        {
            liokazion.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("zamins.aspx") || currenturl.ToLower().Contains("zaminspec.aspx"))
        {
            liZamin.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("melkforoshi.aspx") || currenturl.ToLower().Contains("melkforoshispec.aspx"))
        {
            liKharidvaforoshMelk.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("darkhastmaskan.aspx") || currenturl.ToLower().Contains("darkhastmaskanspec.aspx"))
        {
            liDarkhastMaskan.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("etelaatsystemi.aspx"))
        {
            liEtelaaSystemi.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("changepassword.aspx"))
        {
            lichangePassword.CssClass = "active";
        }
    }
    protected void liExit_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("~/login.aspx");
    }
}
