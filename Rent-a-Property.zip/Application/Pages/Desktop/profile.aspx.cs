﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Pages_Desktop_profile : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        txtName.Focus();
        Form.DefaultButton = btnsave.UniqueID;
        if (!IsPostBack)
        {
            Display();
        }
        setLatlng();
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (Checkvalidate())
        {
            Save();
            ShowSeccessMessage("</br>" + "اطلاعات با موفقیت ثبت گردید.");
        }
    }

    private void Display()
    {

        var obj = dc.Amlak_Porofiles.FirstOrDefault();
        if (obj == null || obj.IsDeleted)
            Response.Redirect("~/login.aspx");


        txtName.Text = obj.Name;
        txtShomareTel.Text = obj.Tel;
        txtEmail.Text = obj.Email;
        txtAddress.Text = obj.Address;
        txtfax.Text = obj.Fax;

        txtlat.Text = obj.Lat;
        txtlng.Text = obj.lng;
        hflatlng.Value = obj.Lat + "," + obj.lng;


    }
    private void Save()
    {

        var obj = dc.Amlak_Porofiles.FirstOrDefault();
        if (obj == null)
        {
            return;
        }


        obj.Fax = txtfax.Text.Trim();
        obj.Address = txtAddress.Text.Trim();
        obj.Email = txtEmail.Text.Trim();
        obj.Tel = txtShomareTel.Text.Trim();
     //   obj.Name = txtName.Text.Trim();

        txtlat.Text = obj.Lat;
        txtlng.Text = obj.lng;
        obj.Lat = hflatlng.Value.Split(',')[0];
        obj.lng = hflatlng.Value.Split(',')[1];


        dc.SubmitChanges();


    }
    private void setLatlng()
    {
        txtlat.Text = hflatlng.Value.Split(',')[0];
        txtlng.Text = hflatlng.Value.Split(',')[1];
    }
    private bool Checkvalidate()
    {
        bool result = true;
        string Msg = "لطفا به نکات زیر توجه نمایید : " + "</br>";
        int i = 0;

        if (txtEmail.Text.Trim() != "" && !Validation.IsEmail(txtEmail.Text.Trim()))
        {
            Msg += (++i).ToString() + " - " + "لطفا پست الکترونیکی خود را صحیح وارد نمایید." + "</br>";
            result = false;
        }


        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }

}