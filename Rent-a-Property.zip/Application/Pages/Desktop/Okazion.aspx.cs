﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Application_Pages_Desktop_Okazion : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();



    protected void Page_Load(object sender, EventArgs e)
    {
        Form.DefaultButton = btnNoWork.UniqueID;
        if (!IsPostBack)
        {
            Display();

        }
    }

    protected void btnNew_Click(object sender, EventArgs e)
    {
        NEWFormOkazion();
        CloseProgress();
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRow")
        {
            DeleteRecord(e.CommandArgument.ToString());
          
        }
        if (e.CommandName == "EditRow")
        {
            EDitRow(e.CommandArgument.ToString());

            CloseProgress();
        }
    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void brnSearch_Click(object sender, EventArgs e)
    {
        SearchOkazion();
        CloseProgress();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearForm();
        ClosePannel();
        liSearch_Grid.RaiseViewChanged();
        CloseProgress();

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (CheckValidate())
        {

            Save();
            ClearForm();
            ClosePannel();
           
            liSearch_Grid.RaiseViewChanged();
            
        }
    }


    private void SearchOkazion()
    {
        var obj = dc.Maskans.Where(s => s.code.ToString() == txtCode.Text.Trim() && s.IsDeleted == false).FirstOrDefault();
        txtCode.Focus();
        if (obj == null)
        {
            ShowError("رکورد مورد نظر یافت نشد");
            NEWFormOkazion();
            return;
        }
        if (obj.IsParvandeMaskanBePayanResideAst == true)
        {
            ShowError("پرونده ملک قبلا بسته شده است");
            NEWFormOkazion();
            return;
        }
        if (obj.IsOkazion == true)
        {
            lblOkazionEDit.Text = "ویرایش مشخصات اکازیون";
        }
        
        txtDsc_Okazion.Text = obj.Dsc_Okazion;
        txtCode.Text = obj.code;
        hflatlng.Value = obj.lat + "," + obj.lng;
        txtlat.Text = obj.lat;
        txtlng.Text = obj.lng;
        txtOnvan_Okazion.Text = obj.Title_Okaziom;
        txtPrioroty_Okazion.Text = obj.Priority == null ? "" : obj.Priority.Value.ToString();
        txtPrioroty_Okazion.ReadOnly = false;
        txtOnvan_Okazion.ReadOnly = false;
        txtDsc_Okazion.ReadOnly = false;
        btnMap.OnClientClick = "ShowMapModelDialog('hflatlng','txtlat','txtlng'); return false;";
        btnNew.Style.Add("display", "none");
        DIV_PANEL.Style.Add("display", "");
    }
    private void EDitRow(string Id)
    {
        var obj = dc.Maskans.Where(s => s.Id.ToString() == Id && s.IsDeleted == false && s.IsOkazion == true && s.IsParvandeMaskanBePayanResideAst == false).FirstOrDefault();
        if (obj == null)
        {
            ShowError("رکورد مورد نظر یافت نشد");
            liSearch_Grid.RaiseViewChanged();
            return;
        }
       
        brnSearch.Visible = false;
        txtCode.ReadOnly = true;
        txtOnvan_Okazion.Focus();
        txtDsc_Okazion.Text = obj.Dsc_Okazion;
        txtCode.Text = obj.code;
        hflatlng.Value = obj.lat + "," + obj.lng;
        txtlat.Text = obj.lat;
        txtlng.Text = obj.lng;
        txtOnvan_Okazion.Text = obj.Title_Okaziom;
        txtPrioroty_Okazion.Text = obj.Priority == null ? "" : obj.Priority.Value.ToString();
        txtPrioroty_Okazion.ReadOnly = false;
        txtOnvan_Okazion.ReadOnly = false;
        txtDsc_Okazion.ReadOnly = false;
        btnMap.OnClientClick = "ShowMapModelDialog('hflatlng','txtlat','txtlng'); return false;";
        lblOkazionEDit.Text = "ویرایش مشخصات اکازیون";
        btnNew.Style.Add("display", "none");
        DIV_PANEL.Style.Add("display", "");

    }
    private void ClearForm()
    {
        txtCode.Focus();
        txtDsc_Okazion.Text = "";
        txtCode.Text = "";
        hflatlng.Value = ",";
        txtlat.Text = "";
        txtlng.Text = "";
        txtOnvan_Okazion.Text = "";
        txtPrioroty_Okazion.Text = "";
        btnMap.OnClientClick = "ShowMapModelDialog('hflatlng','txtlat','txtlng'); return false;";
    }
    private void ClosePannel()
    {
        btnNew.Style.Add("display", "");
        DIV_PANEL.Style.Add("display", "none");
    }
    private object Search()
    {


        var Query = from p in dc.Maskans
                    where
                    p.IsDeleted == false
                    &&
                    p.IsOkazion == true
                    &&
                    p.IsParvandeMaskanBePayanResideAst == false
                    select new
                    {
                        p.Id,
                        Code = p.code,
                        p.Title_Okaziom,
                        p.Dsc_Okazion,
                        p.Priority,
                        showMap = (p.lat != null && p.lat.Trim() != "")
                    };


        if (Query.Count() >= 9)
            btnNew.Visible = false;
        else
            btnNew.Visible = true;

        return Query.OrderBy(s => s.Priority);


    }
    private void Display()
    {
        DIV_PANEL.Style.Add("display", "none");
    }
    private void DeleteRecord(string Id)
    {
        var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == Id);
        obj.IsOkazion = false;
        dc.SubmitChanges();
        ShowSeccess("</br>" + "رکورد با موفقیت حذف گردید");




        liSearch_Grid.RaiseViewChanged();

    }
    private void Save()
    {
        var q = dc.Maskans.FirstOrDefault(s => s.code == txtCode.Text.Trim());
        if (q == null)
        {
            CloseProgress();
            return;
        }
        q.IsOkazion = true;
        q.lat = hflatlng.Value.Split(',')[0];
        q.lng = hflatlng.Value.Split(',')[1];
        q.Dsc_Okazion = txtDsc_Okazion.Text.Trim();
        q.Title_Okaziom = txtOnvan_Okazion.Text.Trim();
        q.Priority = txtPrioroty_Okazion.Text.Trim() == "" ? (int?)null : int.Parse("0" + txtPrioroty_Okazion.Text.Trim());
        dc.SubmitChanges();
        ShowSeccess("اطلاعات با موفقیت ذخیره گردید");
    }

    private bool CheckValidate()
    {
        bool result = true;
        int i = 0;
        string Msg = "لطفا به نکات زیر توجه نمایید";

        if (txtCode.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "کد را وارد نمایید" + "</br>";
        }
        else
        {
            var q = dc.Maskans.FirstOrDefault(s => s.code == txtCode.Text.Trim());
            if (q == null)
            {
                result = false;
                Msg += (++i).ToString() + " - " + "با کد وارد شده هیچ ملکی یافت نشد" + "</br>";
            }
            else if (q.IsDeleted == true)
            {
                result = false;
                Msg += (++i).ToString() + " - " + "این ملک قبلا حذف شده است" + "</br>";
            }
            else if (q.IsParvandeMaskanBePayanResideAst == true)
            {
                result = false;
                Msg += (++i).ToString() + " - " + "پرونده این ملک بسته شده است است" + "</br>";
            }
            else if (q.IsOkazion == false)
            {
                if (dc.Maskans.Count(s => s.IsOkazion == true && s.IsDeleted == false && s.IsParvandeMaskanBePayanResideAst == false) > 9)
                {
                    result = false;
                    Msg += (++i).ToString() + " - " + "تعداد اکازیون ها بیشتر از 9 تا نمی تواند باشد." + "</br>";
                }
            }
        }
        int Itemp=0;
        if(txtPrioroty_Okazion.Text.Trim()!=""&&!int.TryParse("0"+txtPrioroty_Okazion.Text.Trim(),out Itemp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "الویت را به صورت عددی و صحیح وارد نمایید." + "</br>";
        }
        if (!result)
        {
            ShowError(Msg);
        }
        return result;
    }
    private void NEWFormOkazion(bool ischangeTitle = true)
    {
        txtCode.ReadOnly = false;
        brnSearch.Visible = true;
        txtCode.Focus();
        txtDsc_Okazion.Text = "";
        txtCode.Text = "";
        hflatlng.Value = ",";
        txtlat.Text = "";
        txtlng.Text = "";
        txtOnvan_Okazion.Text = "";
        txtPrioroty_Okazion.Text = "";
        txtPrioroty_Okazion.ReadOnly = true;
        txtOnvan_Okazion.ReadOnly = true;
        txtDsc_Okazion.ReadOnly = true;
        btnMap.OnClientClick = "return false;";
        if (ischangeTitle)
            lblOkazionEDit.Text = "اکازیون جدید";
        btnNew.Style.Add("display", "none");
        DIV_PANEL.Style.Add("display", "");
    }
    private void CloseProgress()
    {
        string message = "progressclose();";
        ScriptManager.RegisterStartupScript(btnNew, this.GetType(), "alert", message, true);
    }
    private void ShowError(string msg)
    {
        string message = "progressclose();ShowErrorMessage('" + msg + "');";
        ScriptManager.RegisterStartupScript(btnNew, this.GetType(), "alert", message, true);
    }
    private void ShowSeccess(string msg)
    {
        string message = "progressclose();ShowSeccessMessage('" + msg + "');";
        ScriptManager.RegisterStartupScript(btnNew, this.GetType(), "alert", message, true);
    }


}