﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Application_Pages_Desktop_MelkForoshiSpec : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        cboVaziatMelk.Focus();
        Form.DefaultButton = btnsave.UniqueID;
        if (!IsPostBack)
        {
            BindCambo();
            Display();
        }
        setLatlng();

    }



    protected void btnCancel_Click(object sender, EventArgs e)
    {

        List<string> LstTempid_image = new List<string>();
        foreach (var q in hfImageIds.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_image.Add(q.Replace("Temp", ""));
            }
        }
        DeleteList(LstTempid_image);
        ReturnToLastPage();
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (Checkvalidate())
        {
            Save();
            ReturnToLastPage();
        }
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        BindFileUploadImage();
    }
    protected void lstImagegallery_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "DeleteImage")
        {
            DeleteImage(e.CommandArgument.ToString());
            ldsresultImage.RaiseViewChanged();
        }
    }

    protected void ldsresultImage_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void btnDeleteImage_Shahrdari_Click(object sender, ImageClickEventArgs e)
    {
        DeleteImageTempShahrdari();
    }
    protected void btnUploadImageShahrdari_Click(object sender, EventArgs e)
    {
        if (fu_Shahrdari.HasFile)
            SaveTempShahrdariImage();
    }
    protected void cboMakan_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindMantegh();
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        Delete();
    }




    private void BindMantegh(bool value = false)
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        string id = "";
        if (value)
        {
            var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == ID);
            if (obj != null)
                id = obj.MantagheId == null ? "" : obj.MantagheId.ToString();
        }
        cboMantaghe.DataSource = dc.Mantaghes.Where(s => s.Id.ToString() == id || s.MakanId.ToString() == cboMakan.SelectedValue).OrderBy(s => s.priority);
        cboMantaghe.DataBind();
        cboMantaghe.Items.Insert(0, new ListItem("انتخاب کنید", "0"));
        cboMantaghe.SelectedIndex = 0;
    }
    private void SaveTempShahrdariImage()
    {

        string[] contentTypes = { "image/pjpeg", "image/jpeg", "image/x-png", "image/png" };//فرمت های مجاز
        string[] extention = { ".jpg", ".jpeg", ".png" };//پسوند های مجاز

        if (!fu_Shahrdari.HasFile)//اگر فایل آپلود آدرس عکس را داشت
            ShowErrorMessage("لطفا تصویر " + "مورد نظر" + " را انتخاب نمایید.");
        else if (fu_Shahrdari.HasFile && !contentTypes.Contains(fu_Shahrdari.PostedFile.ContentType.ToString()))//اگر عکس وجود دارد آیا فرمت ها را رعایت کرده است
            ShowErrorMessage("لطفا تصویر " + "مورد نظر" + " را متناسب با ویژگی های داده شده انتخاب نمایید.");
        else
        {

            var obj = new TempImage();
            obj.UID = Guid.NewGuid();
            obj.Datetime = DateTime.Now;
            obj.Address = "TEMP_SHAHRDARI" + obj.UID + Path.GetExtension(fu_Shahrdari.FileName);
            dc.TempImages.InsertOnSubmit(obj);
            dc.SubmitChanges();
            fu_Shahrdari.SaveAs(Server.MapPath("~" + ImagePath + obj.Address));//به صورت موقت عکس را ذخیره کرد

            DeleteImageTempShahrdari();
            hfIdValue_Shahrdari.Value = obj.UID.ToString();
            img_shahrdari.Src = ImagePath + obj.Address;
            btnDeleteImage_Shahrdari.Visible = true;
        }
    }
    private void DeleteImageTempShahrdari()
    {

        if (img_shahrdari.Src.Contains("TEMP_SHAHRDARI"))
        {
            string Id = hfIdValue_Shahrdari.Value;
            var obj = dc.TempImages.SingleOrDefault(s => s.UID.ToString() == Id);
            if (obj != null)
            {
                try
                {
                    string path = Server.MapPath("~" + ImagePath + obj.Address);
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                    dc.TempImages.DeleteOnSubmit(obj);
                }
                catch { }
            }
            dc.SubmitChanges();
        }
        img_shahrdari.Src = SetNoImage();
    }
    private string SetNoImage()
    {
        btnDeleteImage_Shahrdari.Visible = false;
        hfIdValue_Shahrdari.Value = "";
        return "~/Application/Images/Icons/NO-IMAGE-AVAILABLE.jpg";
    }

    private object Search()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        List<string> Lstid_image = new List<string>();
        List<string> LstTempid_image = new List<string>();
        foreach (var q in hfImageIds.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_image.Add(q.Replace("Temp", ""));
            }
            else
            {
                Lstid_image.Add(q);
            }
        }


        var queryTempImages = (from p in dc.TempImages
                               where
                                LstTempid_image.Contains(p.UID.ToString())
                               select new
                               {
                                   Url = "~" + ImagePath + p.Address,
                                   UID = "Temp" + p.UID.ToString().ToLower()
                               }).ToList();
        var queryImages = (from p in dc.MaskanImages
                           where
                            Lstid_image.Contains(p.UID.ToString())
                            &&
                            p.MaskanId.ToString() == ID
                           select new
                           {
                               Url = "~" + ImagePath + p.Address,
                               UID = p.UID.ToString().ToLower()
                           }).ToList();
        return queryTempImages.Concat(queryImages);
    }

    private void BindCambo()
    {

        cboNoeMoamele.DataSource = dc.NoeMoavezes.Where(s =>
            s.Id == (int)DataValueIds.NoeMoavezeIds.PishForosh
            ||
            s.Id == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh).OrderBy(s => s.priority);

        cboNoeMoamele.DataBind();
        cboNoeMoamele.Items.Insert(0, new ListItem("انتخاب کنید", "0"));
        cboNoeMoamele.Attributes.Add("onchange", "changelblvalue('" + lblTarikhTkhlie.ClientID + "','" + cboNoeMoamele.ClientID + "','" + (int)DataValueIds.NoeMoavezeIds.PishForosh + "','تاریخ تحویل','" + (int)DataValueIds.NoeMoavezeIds.KharidVaForosh + "','تاریخ تخلیه','تاریخ تخلیه/تحویل'); return false;");
        LitScript.Text = "<script language=\"javascript\" type=\"text/javascript\"> "
            + "changelblvalue('" + lblTarikhTkhlie.ClientID + "','" + cboNoeMoamele.ClientID + "','" + (int)DataValueIds.NoeMoavezeIds.PishForosh + "','تاریخ تحویل','" + (int)DataValueIds.NoeMoavezeIds.KharidVaForosh + "','تاریخ تخلیه','تاریخ تخلیه/تحویل');"
            + " </script>";

        cboMakan.DataSource = dc.Makans.OrderBy(s => s.Priority);
        cboMakan.DataBind();
        cboMakan.Items.Insert(0, new ListItem("انتخاب کنید", "0"));

        cboDarbAz.DataSource = dc.DarbAzs.OrderBy(s => s.priority);
        cboDarbAz.DataBind();
        cboDarbAz.Items.Insert(0, new ListItem("انتخاب کنید", "0"));

        cboNoeMelk.DataSource = dc.NoeMelks.Where(s => s.GROUPTYPE == "MELK").OrderBy(s => s.priority);
        cboNoeMelk.DataBind();
        cboNoeMelk.Items.Insert(0, new ListItem("انتخاب کنید", "0"));

        cboTedadKhab.DataSource = dc.TedadKhabs.OrderBy(s => s.priority);
        cboTedadKhab.DataBind();
        cboTedadKhab.Items.Insert(0, new ListItem("انتخاب کنید", "0"));

        cboTabagheForosh.DataSource = dc.Tabghes.OrderBy(s => s.priority);
        cboTabagheForosh.DataBind();
        cboTabagheForosh.Items.Insert(0, new ListItem("انتخاب کنید", "0"));

        cboKlid.DataSource = dc.Klids.OrderBy(s => s.priority);
        cboKlid.DataBind();
        cboKlid.Items.Insert(0, new ListItem("انتخاب کنید", "0"));
    }
    private void Display()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == ID);
        if (obj == null)
        {
            string date = DateShamsi.GetCurrentDate();
            date = date.Substring(2, 2) + date.Substring(5, 2);
            var tmp = dc.Maskans.Where(s => s.code != null && s.code.StartsWith(date)).Max(s => s.code);
            txtCode.Text = (tmp == null || tmp.Trim() == "") ? (date + "0001") : (date + (int.Parse(tmp.Substring(5)) + 1).ToString("0000"));
            img_shahrdari.Src = SetNoImage();
            return;
        }
        if (obj.IsDeleted)
            ReturnToLastPage();
        obj.IsAgahiRead = true;
        dc.SubmitChanges();
        if (obj.ShowInList == false && obj.IsAgahi == true)
        {
            btnsave.Text = "تایید و ذخیره آگهی";
            btnsave.Width = 165;
            btnDelete.Visible = true;
        }



        if (obj.IsParvandeMaskanBePayanResideAst == true)
            cboVaziatMelk.SelectedIndex = 1;
        else
            cboVaziatMelk.SelectedIndex = 0;

        if (obj.code == null || obj.code.Trim() == "")
        {
            string date = DateShamsi.GetCurrentDate();
            date = date.Substring(2, 2) + date.Substring(5, 2);
            var tmp = dc.Maskans.Where(s => s.code != null && s.code.StartsWith(date)).Max(s => s.code);
            txtCode.Text = (tmp == null || tmp.Trim() == "") ? (date + "001") : (date + (int.Parse(tmp.Substring(5)) + 1).ToString("000"));
        }
        else
            txtCode.Text = obj.code;


        if (obj.NoeMelkId == null)
            cboNoeMelk.SelectedIndex = 0;
        else
            cboNoeMelk.SelectedValue = obj.NoeMelkId.ToString();

        if (obj.TedadKhabId == null)
            cboTedadKhab.SelectedIndex = 0;
        else
            cboTedadKhab.SelectedValue = obj.TedadKhabId.ToString();

        if (obj.TabghaeForoshiId == null)
            cboTabagheForosh.SelectedIndex = 0;
        else
            cboTabagheForosh.SelectedValue = obj.TabghaeForoshiId.ToString();

        if (obj.DarbAzId == null)
            cboDarbAz.SelectedIndex = 0;
        else
            cboDarbAz.SelectedValue = obj.DarbAzId.ToString();
        if (obj.MakanId == null)
            cboMakan.SelectedIndex = 0;
        else
            cboMakan.SelectedValue = obj.MakanId.ToString();

        BindMantegh(true);
        if (obj.MantagheId == null)
            cboMantaghe.SelectedIndex = 0;
        else
            cboMantaghe.SelectedValue = obj.MantagheId.ToString();

        txtTedadTabaghatMelk.Text = obj.TedadTabaghat == null ? "" : obj.TedadTabaghat.ToString();
        txtMetrazh.Text = obj.Metrazh == null ? "" : obj.Metrazh.Value.ToString("###,###");
        txtTarikhTakhlie.Text = obj.DateTakhlie;



        if (obj.KilidId == null)
            cboKlid.SelectedIndex = 0;
        else
            cboKlid.SelectedValue = obj.KilidId.ToString();


        if (obj.NoeMoavezeId == null)
            cboNoeMoamele.SelectedIndex = 0;
        else
            cboNoeMoamele.SelectedValue = obj.NoeMoavezeId.ToString();



        txtAddresskamel.Text = obj.AddressKamel;
        txtlat.Text = obj.lat;
        txtlng.Text = obj.lng;
        hflatlng.Value = obj.lat + "," + obj.lng;
        txtvam.Text = obj.Vam == null ? "" : obj.Vam.Value.ToString("###,###");
        txtghymat.Text = obj.Ghymat == null ? "" : obj.Ghymat.Value.ToString("###,###");
        txtDscNamayeshDarsait.Text = obj.Dsc;
        txtDsc_Malek.Text = obj.Dsc_ShakhsiBarayUser;
        txtFullNameMostajer.Text = obj.FullNameMostajer;
        txtFullNameSahebkhane.Text = obj.FullNameSahebkhane;
        txtShomareTelMostajer.Text = obj.ShomareTelMostajer;
        txtShomareTelSahebkhane.Text = obj.ShomareTelSahebkhane;
        txtAdrKotah.Text = obj.LittleAddress_Baray_Namayesh_Dar_Site;

        if (obj.MaskanImages.Any())
            hfImageIds.Value = obj.MaskanImages.Select(s => s.UID.ToString().ToLower()).Aggregate((a, b) => a + "," + b) + ",";
        else
            hfImageIds.Value = "";

        if (File.Exists(Server.MapPath("~" + ImagePath + obj.AxShahrdari)))
        {
            img_shahrdari.Src = ImagePath + obj.AxShahrdari;
        }
        else
            img_shahrdari.Src = SetNoImage();

        cboNamayeshMelkDarOkazion.SelectedIndex = obj.IsOkazion == false ? 0 : 1;
        txtDsc_Okazion.Text = obj.Dsc_Okazion;
        txtPrioroty_Okazion.Text = obj.Priority == null ? "" : obj.Priority.Value.ToString();
        txtOnvan_Okazion.Text = obj.Title_Okaziom;

    }
    private void Save()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == ID);
        if (obj == null)
        {
            obj = new Maskan();
            obj.DateSabt_English = DateTime.Now;
            obj.DateSabt_Persian = DateShamsi.GetCurrentDate();
            dc.Maskans.InsertOnSubmit(obj);
            obj.IsAgahi = false;
            obj.IsAgahiRead = true;
        }
        obj.ShowInList = true;
        if (obj.code == null || obj.code == "")
        {
            string datetmp = DateShamsi.GetCurrentDate();
            datetmp = datetmp.Substring(2, 2) + datetmp.Substring(5, 2);
            var tmp = dc.Maskans.Where(s => s.code != null && s.code.StartsWith(datetmp)).Max(s => s.code);
            txtCode.Text = (tmp == null || tmp.Trim() == "") ? (datetmp + "001") : (datetmp + (int.Parse(tmp.Substring(5)) + 1).ToString("000"));
        }

        obj.code = txtCode.Text.Trim();
        obj.IsParvandeMaskanBePayanResideAst = cboVaziatMelk.SelectedIndex == 1;
        obj.LittleAddress_Baray_Namayesh_Dar_Site = txtAdrKotah.Text.Trim();
        obj.NoeMoaveze = dc.NoeMoavezes.SingleOrDefault(s => s.Id.ToString() == cboNoeMoamele.SelectedValue);
        obj.DarbAz = dc.DarbAzs.SingleOrDefault(s => s.Id.ToString() == cboDarbAz.SelectedValue);
        obj.Makan = dc.Makans.SingleOrDefault(s => s.Id.ToString() == cboMakan.SelectedValue);
        obj.NoeMelk = dc.NoeMelks.SingleOrDefault(s => s.Id.ToString() == cboNoeMelk.SelectedValue);
        obj.TedadKhab = dc.TedadKhabs.SingleOrDefault(s => s.id.ToString() == cboTedadKhab.SelectedValue);
        obj.Tabghe = dc.Tabghes.SingleOrDefault(s => s.Id.ToString() == cboTabagheForosh.SelectedValue);
        obj.TedadTabaghat = txtTedadTabaghatMelk.Text.Replace(",", "").Trim() == "" ? (int?)null : int.Parse(txtTedadTabaghatMelk.Text.Replace(",", "").Trim());
        obj.Metrazh = txtMetrazh.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtMetrazh.Text.Replace(",", "").Trim());
        obj.DateTakhlie = txtTarikhTakhlie.Text.Trim();
        obj.Klid = dc.Klids.SingleOrDefault(s => s.Id.ToString() == cboKlid.SelectedValue);
        obj.Mantaghe = dc.Mantaghes.SingleOrDefault(s => s.Id.ToString() == cboMantaghe.SelectedValue);

        obj.AddressKamel = txtAddresskamel.Text.Trim();
        obj.lat = hflatlng.Value.Split(',')[0];
        obj.lng = hflatlng.Value.Split(',')[1];
        obj.Vam = txtvam.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtvam.Text.Replace(",", "").Trim());
        obj.Ghymat = txtghymat.Text.Replace(",", "").Trim() == "" ? (decimal?)null : decimal.Parse(txtghymat.Text.Replace(",", "").Trim());
        obj.Dsc = txtDscNamayeshDarsait.Text.Trim();
        obj.Dsc_ShakhsiBarayUser = txtDsc_Malek.Text.Trim();
        obj.FullNameMostajer = txtFullNameMostajer.Text.Trim();
        obj.FullNameSahebkhane = txtFullNameSahebkhane.Text.Trim();
        obj.ShomareTelMostajer = txtShomareTelMostajer.Text.Trim();
        obj.ShomareTelSahebkhane = txtShomareTelSahebkhane.Text.Trim();

        obj.IsOkazion = cboNamayeshMelkDarOkazion.SelectedIndex == 1;
        obj.Dsc_Okazion = txtDsc_Okazion.Text.Trim();
        int Itmp = 0;
        obj.Priority = int.TryParse(txtPrioroty_Okazion.Text.Trim(), out Itmp) ? int.Parse("0" + txtPrioroty_Okazion.Text.Trim()) : (int?)null;
        obj.Title_Okaziom = txtOnvan_Okazion.Text.Trim();


        if (hfIdValue_Shahrdari.Value != "" && img_shahrdari.Src.Contains("TEMP_SHAHRDARI"))
        {
            if (File.Exists(Server.MapPath("~" + ImagePath + obj.AxShahrdari)))
                File.Delete(Server.MapPath("~" + ImagePath + obj.AxShahrdari));
            var tmpaxshahrdari = dc.TempImages.SingleOrDefault(s => s.UID.ToString() == hfIdValue_Shahrdari.Value);
            if (tmpaxshahrdari != null)
            {
                string path = Server.MapPath("~" + ImagePath + tmpaxshahrdari.Address);
                obj.AxShahrdari = "AXSHAHRDARI_" + Guid.NewGuid() + Path.GetExtension(tmpaxshahrdari.Address);
                if (File.Exists(path))
                    File.Move(path, Server.MapPath("~" + ImagePath + obj.AxShahrdari));
                DeleteImageTempShahrdari();
            }
        }
        else if (hfIdValue_Shahrdari.Value == "" && !img_shahrdari.Src.Contains("AXSHAHRDARI_") && obj.AxShahrdari != null && obj.AxShahrdari.Trim() != "")
        {
            string path = Server.MapPath("~" + ImagePath + obj.AxShahrdari);
            obj.AxShahrdari = null;
            if (File.Exists(path))
                File.Delete(path);
        }

        dc.SubmitChanges();
        List<string> Lstid_image = new List<string>();
        List<string> LstTempid_image = new List<string>();
        foreach (var q in hfImageIds.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_image.Add(q.Replace("Temp", ""));
            }
            else
            {
                Lstid_image.Add(q);
            }
        }

        List<MaskanImage> lstDeleteMaskan = dc.MaskanImages.Where(s => s.MaskanId == obj.Id && !Lstid_image.Contains(s.UID.ToString())).ToList();
        List<string> lstadr = lstDeleteMaskan.Any() ? (new List<string>()) : lstDeleteMaskan.Select(s => s.Address).ToList();

        if (lstDeleteMaskan.Any())
            dc.MaskanImages.DeleteAllOnSubmit(lstDeleteMaskan);

        foreach (var str in LstTempid_image)
        {
            var tmp = dc.TempImages.SingleOrDefault(s => s.UID.ToString() == str);
            if (tmp == null)
                return;

            var newimg = new MaskanImage();
            newimg.UID = Guid.NewGuid();
            newimg.Maskan = obj;
            newimg.Datetime = DateTime.Now;

            newimg.Address = newimg.UID.ToString() + Path.GetExtension(tmp.Address);
            dc.MaskanImages.InsertOnSubmit(newimg);
            dc.TempImages.DeleteOnSubmit(tmp);
            string path = Server.MapPath("~" + ImagePath + tmp.Address);
            if (File.Exists(path))
                File.Move(path, Server.MapPath("~" + ImagePath + newimg.Address));

        }

        dc.SubmitChanges();
        if (obj.IsParvandeMaskanBePayanResideAst == true)
        {
            obj.IsOkazion = false;
            lstadr = dc.MaskanImages.Where(s => s.MaskanId == obj.Id).Select(s => s.Address).ToList();
            if (dc.MaskanImages.Where(s => s.MaskanId == obj.Id).Any())
                dc.MaskanImages.DeleteAllOnSubmit(dc.MaskanImages.Where(s => s.MaskanId == obj.Id));
            dc.SubmitChanges();
        }

        DeleteList(lstadr);

    }
    private void Delete()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == ID);
        if (obj == null)
        {
            ShowErrorMessage("</br>" + "رکورد یافت نشد");
            return;
        }
        if (obj.AxShahrdari != null)
        {
            string path = Server.MapPath("~" + ImagePath + obj.AxShahrdari);
            obj.AxShahrdari = null;
            if (File.Exists(path))
                File.Delete(path);
        }
        if (hfIdValue_Shahrdari.Value != "" && img_shahrdari.Src.Contains("TEMP_SHAHRDARI"))
        {
            var tmpaxshahrdari = dc.TempImages.SingleOrDefault(s => s.UID.ToString() == hfIdValue_Shahrdari.Value);
            if (tmpaxshahrdari != null)
            {
                string path = Server.MapPath("~" + ImagePath + tmpaxshahrdari.Address);

                if (File.Exists(path))
                    File.Delete(path);
                DeleteImageTempShahrdari();
            }
        }

        dc.SubmitChanges();
        List<string> Lstid_image = new List<string>();
        List<string> LstTempid_image = new List<string>();
        foreach (var q in hfImageIds.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_image.Add(q.Replace("Temp", ""));
            }
            else
            {
                Lstid_image.Add(q);
            }
        }

        List<MaskanImage> lstDeleteMaskan = dc.MaskanImages.Where(s => s.MaskanId == obj.Id).ToList();
        List<string> lstadr = lstDeleteMaskan.Any() ? (new List<string>()) : lstDeleteMaskan.Select(s => s.Address).ToList();

        if (lstDeleteMaskan.Any())
            dc.MaskanImages.DeleteAllOnSubmit(lstDeleteMaskan);

        foreach (var str in LstTempid_image)
        {
            var tmp = dc.TempImages.SingleOrDefault(s => s.UID.ToString() == str);
            if (tmp == null)
                return;

            dc.TempImages.DeleteOnSubmit(tmp);
            string path = Server.MapPath("~" + ImagePath + tmp.Address);
            if (File.Exists(path))
                File.Delete(path);

        }
        dc.SubmitChanges();
        DeleteList(lstadr);
        obj.IsDeleted = true;
        dc.SubmitChanges();
        ShowSeccessMessage("</br>" + "رکورد با موفقیت حذف گردید");
        ReturnToLastPage();
    }
    private void setLatlng()
    {
        txtlat.Text = hflatlng.Value.Split(',')[0];
        txtlng.Text = hflatlng.Value.Split(',')[1];
    }
    private void DeleteList(List<string> lstadr)
    {
        foreach (var str in lstadr)
        {
            try
            {
                string path = Server.MapPath("~" + ImagePath + str);
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
            catch
            {
            }
        }
    }
    private bool Checkvalidate()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        int ITmp = 0;
        bool result = true;
        string Msg = "لطفا به نکات زیر توجه نمایید : " + "</br>";
        decimal Tmp = 0;
        int i = 0;

        if (txtCode.Text.Trim() == "")
        {
            Msg += (++i).ToString() + " - " + "لطفا کد را وارد نمایید." + "</br>";
            result = false;
        }
        //if (cboMakan.SelectedIndex == 0)
        //{
        //    Msg += (++i).ToString() + " - " + "مکان را مشخص نمایید" + "</br>";
        //    result = false;
        //}
        if (cboNoeMoamele.SelectedIndex == 0)
        {
            Msg += (++i).ToString() + " - " + "نوع معامله را مشخص نمایید" + "</br>";
            result = false;
        }
        if (cboNoeMelk.SelectedIndex == 0)
        {
            Msg += (++i).ToString() + " - " + "نوع ملک را مشخص نمایید" + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtTedadTabaghatMelk.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "تعداد طبقات ملک را صحیح وارد نمایید" + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtMetrazh.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "متراژ را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtghymat.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "قیمت را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (!decimal.TryParse("0" + txtvam.Text.Replace(",", "").Trim(), out Tmp))
        {
            Msg += (++i).ToString() + " - " + "وام را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (!int.TryParse("0" + txtPrioroty_Okazion.Text.Trim(), out ITmp))
        {
            Msg += (++i).ToString() + " - " + "اولویت نمایش اکازیون را به صورت عددی و صحیح وارد نمایید." + "</br>";
            result = false;
        }
        if (cboVaziatMelk.SelectedIndex == 0)
        {

            if (cboNamayeshMelkDarOkazion.SelectedIndex == 1)
            {
                ID = ID == null ? "" : ID;
                int count = dc.Maskans.Count(s => s.IsDeleted == false && s.IsOkazion == true && s.Id.ToString() != ID);
                if ((string.IsNullOrEmpty(ID.Trim()) ? (count + 1) : count) >= 9)
                {
                    Msg += (++i).ToString() + " - " + "بیش از 9 اکازیون نمی توان داشت، لطفا ابتدا یکی از اکازیون های قبلی را غیر فعال کرده سپس اکازیون جدید را ثبت نمایید." + "</br>";
                    result = false;
                }
            }
        }

        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }
    private void ReturnToLastPage()
    {
        DeleteImageTempShahrdari();
        Response.Redirect(ArssPayamUtility.GetEncodedQueryString("MelkForoshi.aspx?args={0}", "index=old"));
    }


    private void BindFileUploadImage()
    {
        if (fuImage.HasFile)
            CheckSelectedFile(fuImage, 204800);
    }

    /// <summary>
    /// چک می کند که آیا فایل آپلود شده با فرمت های خواسته شده تطابق دارد یا خیر
    /// </summary>
    /// <param name="fu">کامپوننت فایل آپلودی که از آن استفاده شده تا عکس را انتخاب کند</param>
    /// <param name="lenght">اندازه ی عکس</param>
    /// <param name="message">نام عکس</param>
    /// <param name="sessionName">پارامتری که اگر عکس به صورت موقت وجود داشته باشد در آن است</param>
    /// <param name="img">کامپوننت عکس که قرار است عکس روی آن نمایش داده شود</param>
    /// <param name="btn">دکمه حذف عکس</param>
    /// <param name="lnk">لینک مخصوص به دانلود عکس</param>
    private void CheckSelectedFile(FileUpload fu, int lenght)
    {
        string[] contentTypes = { "image/pjpeg", "image/jpeg", "image/x-png", "image/png" };//فرمت های مجاز
        string[] extention = { ".jpg", ".jpeg", ".png" };//پسوند های مجاز

        if (!fu.HasFile)//اگر فایل آپلود آدرس عکس را داشت
            ShowErrorMessage("لطفا تصویر " + "مورد نظر" + " را انتخاب نمایید.");
        else if (fu.HasFile && !contentTypes.Contains(fu.PostedFile.ContentType.ToString()))//اگر عکس وجود دارد آیا فرمت ها را رعایت کرده است
            ShowErrorMessage("لطفا تصویر " + "مورد نظر" + " را متناسب با ویژگی های داده شده انتخاب نمایید.");
        else
        {

            var obj = new TempImage();
            obj.UID = Guid.NewGuid();
            obj.Datetime = DateTime.Now;
            obj.Address = "Temp" + obj.UID + Path.GetExtension(fu.FileName);
            dc.TempImages.InsertOnSubmit(obj);
            dc.SubmitChanges();
            fu.SaveAs(Server.MapPath("~" + ImagePath + obj.Address));//به صورت موقت عکس را ذخیره کرد
            hfImageIds.Value += "Temp" + obj.UID + ",";
            ldsresultImage.RaiseViewChanged();
        }
    }
    private void DeleteImage(string Id)
    {
        hfImageIds.Value = hfImageIds.Value.Replace(Id + ",", "");
        if (!Id.StartsWith("Temp"))
        {
            ldsresultImage.RaiseViewChanged();
            return;
        }
        Id = Id.Replace("Temp", "");
        var obj = dc.TempImages.SingleOrDefault(s => s.UID.ToString() == Id);
        if (obj != null)
        {
            try
            {
                string path = Server.MapPath("~" + ImagePath + obj.Address);
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
                dc.TempImages.DeleteOnSubmit(obj);
            }
            catch { }
        }
        dc.SubmitChanges();
        ldsresultImage.RaiseViewChanged();
    }


}