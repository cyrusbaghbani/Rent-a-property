﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Application_Pages_Desktop_Zamins : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    public int OldIndex
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["OldIndex"] != null)
            {

                return Convert.ToInt32(Request.Cookies["SearchCookieZamin"]["OldIndex"]);
            }

            return 0;
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["OldIndex"] = value.ToString();
        }
    }
    public string ghymatTextAz
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["ghymatTextAz"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["ghymatTextAz"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["ghymatTextAz"] = value.ToString();
        }
    }
    public string ghymatTextTa
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["ghymatTextTa"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["ghymatTextTa"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["ghymatTextTa"] = value.ToString();
        }
    }
    public string MetrazhTextAz
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["MetrazhTextAz"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["MetrazhTextAz"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["MetrazhTextAz"] = value.ToString();
        }
    }
    public string MetrazhTextTa
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["MetrazhTextTa"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["MetrazhTextTa"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["MetrazhTextTa"] = value.ToString();
        }
    }
    public string CodeText
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["CodeText"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["CodeText"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["CodeText"] = value.ToString();
        }
    }
    public string VaziatMelkCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["VaziatMelkCambo"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["VaziatMelkCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["VaziatMelkCambo"] = value.ToString();
        }
    }
    public string KarbariCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["KarbariCambo"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["KarbariCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["KarbariCambo"] = value.ToString();
        }
    }
    public string MakanCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["MakanCambo"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["MakanCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["MakanCambo"] = value.ToString();
        }
    }
    public string DarbAzCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["DarbAzCambo"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["DarbAzCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["DarbAzCambo"] = value.ToString();
        }
    }
    public string NoeMelkCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieZamin"] != null && Request.Cookies["SearchCookieZamin"]["NoeMelkCambo"] != null)
            {

                return Request.Cookies["SearchCookieZamin"]["NoeMelkCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieZamin"]["NoeMelkCambo"] = value.ToString();
        }
    }
    public string SearchRadio
    {
        get
        {
            if (Request.Cookies["SearchRadioZamin"] != null && Request.Cookies["SearchRadioZamin"]["SearchRadio"] != null)
            {

                return Request.Cookies["SearchRadioZamin"]["SearchRadio"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchRadioZamin"]["SearchRadio"] = value.ToString();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        cboVaziatMelk.Focus();
        Form.DefaultButton = btnSearch.UniqueID;
        if (!IsPostBack)
        {
            BindCambo();
            SetOldParametr();
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        liSearch_Grid.RaiseViewChanged();
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("ZaminSpec.aspx");
    }
    protected void gvResult_PageIndexChanged(object sender, EventArgs e)
    {

        this.OldIndex = gvResult.PageIndex;

    }
    protected void gvResult_DataBound(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                    gvResult.PageIndex = OldIndex;

            }
        }
        foreach (GridViewRow row in gvResult.Rows)
        {
            string value = gvResult.DataKeys[row.RowIndex].Value.ToString();
            string[] values = value.Split(';');
            if (values[1] == "false" && values[2] == "true" && values[3] == "false")
            {
                row.BackColor = Color.FromName("#fbffa5");
                row.ToolTip = "آگهی خوانده نشده";
            }
            if (values[1] == "false" && values[2] == "true" && values[3] == "true")
            {
                row.BackColor = Color.FromName("#86ff78");
                row.ToolTip = "آگهی خوانده شده";
            }
        }
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRow")
        {
            DeleteRecord(e.CommandArgument.ToString());

        }
        if (e.CommandName == "EditRow")
        {
            Response.Redirect(ArssPayamUtility.GetEncodedQueryString("ZaminSpec.aspx?args={0}", "ID=" + e.CommandArgument));
        }
    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        ExcelExport();
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        Print();
    }

    private void ExcelExport()
    {
        decimal tmp = 0;
        decimal? MetrazhAz = decimal.TryParse(txtMetrazhAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? MetrazhTa = decimal.TryParse(txtMetrazhTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;

        decimal? ghymatAz = decimal.TryParse(txtGhymatAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? ghymatTa = decimal.TryParse(txtGhymatTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        var Query = (from p in dc.Maskans
                     where
                     p.IsDeleted == false
                     &&
                     (
                        rdAll.Checked
                        ||
                        (rdTaedShodeha.Checked && p.ShowInList == true)
                        ||
                        (rdAgahiha.Checked && p.IsAgahi)
                        ||
                        (rdAgahiHayKhandeNashode.Checked && p.IsAgahi == true && p.IsAgahiRead == false)
                        ||
                        (rdAgahiHayKhandeShode.Checked && p.IsAgahi == true && p.IsAgahiRead == true)
                     )
                     &&
                     (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "ZAMIN")
                     &&
                     (p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh)
                     &&
                     (cboVaziatMelk.SelectedIndex == 0 || (p.IsParvandeMaskanBePayanResideAst == false && cboVaziatMelk.SelectedIndex == 1) || (p.IsParvandeMaskanBePayanResideAst == true && cboVaziatMelk.SelectedIndex == 2))
                     &&
                      (p.NoeMoavezeId != null && p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh)
                     &&
                     (cboNoeMelk.SelectedIndex == 0 || (p.NoeMelkId == null && cboNoeMelk.SelectedValue == "0") || (p.NoeMelkId != null && cboNoeMelk.SelectedValue == p.NoeMelkId.Value.ToString()))
                     &&
                     (cboNoeKarbari.SelectedIndex == 0 || (cboNoeKarbari.SelectedValue == "0" && p.MaskanNoeKarbaris.Any() == false) || (p.MaskanNoeKarbaris.Any(s => cboNoeKarbari.SelectedValue == s.NoeKarbariId.ToString())))
                     &&
                     (cboDarbAz.SelectedIndex == 0 || (p.DarbAzId == null && cboDarbAz.SelectedValue == "0") || (p.DarbAzId != null && cboDarbAz.SelectedValue == p.DarbAzId.Value.ToString()))
                     &&
                     (cboMakan.SelectedIndex == 0 || (p.MakanId == null && cboMakan.SelectedValue == "0") || (p.MakanId != null && cboMakan.SelectedValue == p.MakanId.Value.ToString()))
                     &&
                     (txtCode.Text.Trim() == "" || p.code != null && p.code.Contains(txtCode.Text.Trim()))
                     &&
                     (MetrazhAz == null || (p.Metrazh != null && p.Metrazh.Value >= MetrazhAz))
                     &&
                     (MetrazhTa == null || (p.Metrazh != null && p.Metrazh.Value <= MetrazhTa))
                     &&
                     (

                          (
                              (ghymatAz == null || (p.Ghymat != null && p.Ghymat.Value >= ghymatAz))
                              &&
                              (ghymatTa == null || (p.Ghymat != null && p.Ghymat.Value <= ghymatTa))
                          )
                     )
                     select new
                     {
                         p.Id,
                         Code = p.code,
                         NoeMelkName = p.NoeMelkId == null ? "-" : p.NoeMelk.Name,
                         NoeMamele = p.NoeMoavezeId == null ? "-" : p.NoeMoaveze.Name,
                         TedadKhab = p.TedadKhabId == null ? "-" : p.TedadKhab.Name,
                         Tabghe = p.TabghaeForoshiId == null ? "-" : p.Tabghe.Name,
                         Metrazh = p.Metrazh,
                         Ejare = p.Mablagh_Ejare,
                         Klid = p.KilidId == null ? "-" : p.Klid.Name,
                         Makan = p.MakanId == null ? "-" : p.Makan.Name,
                         Mantaghe = p.MantagheId == null ? "" : p.Mantaghe.Name,
                         Darbaz = p.DarbAzId == null ? "-" : p.DarbAz.Name,
                         Rahn = p.Mablagh_Rahn,
                         Ghymat = p.Ghymat,
                         Vam = p.Vam,
                         Tol = p.Tol_Abad_Zamin == null ? "" : p.Tol_Abad_Zamin.Value.ToString(),
                         Arz = p.Arz_Abad_Zamin == null ? "" : p.Arz_Abad_Zamin.Value.ToString(),
                         NoeKarbari = p.MaskanNoeKarbaris,
                         Address = p.AddressKamel,
                         TedadTabaghat = p.TedadTabaghat == null ? "" : p.TedadTabaghat.ToString(),
                         DateTakhlie = p.DateTakhlie == null ? "" : p.DateTakhlie,
                         p.DateSabt_English,
                         Dsc_ShakhsiBarayUser = p.Dsc_ShakhsiBarayUser == null ? "" : p.Dsc_ShakhsiBarayUser,
                         Dsc = p.Dsc == null ? "" : p.Dsc,
                         Pelak = p.Pelak == null ? "" : p.Pelak,
                         MalekName = p.FullNameSahebkhane == null ? "" : p.FullNameSahebkhane,
                         telmalek = p.ShomareTelSahebkhane == null ? "" : p.ShomareTelSahebkhane,
                         mostajerName = p.FullNameMostajer == null ? "" : p.FullNameMostajer,
                         telmostajer = p.ShomareTelMostajer == null ? "" : p.ShomareTelMostajer,
                         VaziatMelk = p.IsParvandeMaskanBePayanResideAst ? "فروش رفته است" : "فروش نرفته است",
                     });


        var Query1 = (from p in Query.ToList()
                      select new
                      {
                          p.Id,
                          p.Code,
                          p.Pelak,
                          p.NoeMamele,
                          p.NoeMelkName,
                          p.TedadKhab,
                          NoeKarbari = p.NoeKarbari.Any() ? p.NoeKarbari.Select(s => s.NoeKarbari.Name).Aggregate((a, b) => a + "," + b) : "",
                          p.Tabghe,
                          Metrazh = p.Metrazh == null ? "" : p.Metrazh.Value.ToString("###,###"),
                          Ejare = p.Ejare == null ? "" : p.Ejare.Value.ToString("###,###"),
                          p.Klid,
                          p.Makan,
                          p.Mantaghe,
                          p.Tol,
                          p.Arz,
                          p.Darbaz,
                          Rahn = p.Rahn == null ? "" : p.Rahn.Value.ToString("###,###"),
                          Ghymat = p.Ghymat == null ? "" : p.Ghymat.Value.ToString("###,###"),
                          Vam = p.Vam == null ? "" : p.Vam.Value.ToString("###,###"),
                          p.Address,
                          p.TedadTabaghat,
                          p.DateTakhlie,
                          p.Dsc_ShakhsiBarayUser,
                          p.DateSabt_English,
                          p.Dsc,
                          p.MalekName,
                          p.telmalek,
                          p.mostajerName,
                          p.telmostajer,
                          p.VaziatMelk
                      }).ToList();


        string[] columnsname ={                          
                          "VaziatMelk",
                          "Code",
                          "NoeMelkName",
                          "NoeKarbari",
                          "Darbaz",
                          "Metrazh" ,   
                          "Tol",
                          "Arz",
                          "Ghymat"  ,
                          "Makan",
                          "Mantaghe",    
                          "Pelak" ,
                          "Address",                                               
                          "MalekName",
                          "telmalek",
                          "Dsc",
                          "Dsc_ShakhsiBarayUser"
                            };
        string[] Pcolumnsname ={                          
                          "وضعیت ملک",
                          "کد",
                          "نوع ملک",
                          "نوع کاربری",
                          "درب از",
                          "متراژ(مترمربع)" ,   
                          "طول (متر)",
                          "عرض (متر)",
                          "قیمت ( تومان)"  ,
                          "مکان",
                          "منطقه", 
                          "پلاک", 
                          "آدرس",                                
                          "نام و نام خانوادگی مالک",
                          "شماره تمایس با مالک",
                          "توضیحات ثبت شده در سایت",
                          "توضیحات مربوط به کاربر"
                            };

        ExcelExporter ex = new ExcelExporter(Query1.OrderByDescending(s => s.DateSabt_English), "خرید و فروش ", Pcolumnsname.ToList(), columnsname.ToList());
        ex.Export("KharidVaForosh", "گزارش خرید و فروش زمین", true);

    }
    private void Print()
    {
        string RptName = "\\KharidVaForoshZamin.mrt";

        string ReportDate = DateShamsi.GetCurrentDate();
        string ReportTime = DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second;

        Stimulsoft.Report.StiReport rpt = new Stimulsoft.Report.StiReport();
        rpt.Load(HttpContext.Current.Server.MapPath("~\\ReportFiles" + RptName));


        decimal tmp = 0;
        decimal? MetrazhAz = decimal.TryParse(txtMetrazhAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? MetrazhTa = decimal.TryParse(txtMetrazhTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;

        decimal? ghymatAz = decimal.TryParse(txtGhymatAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? ghymatTa = decimal.TryParse(txtGhymatTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        var Query = (from p in dc.Maskans
                     where
                     p.IsDeleted == false
                     &&
                     p.ShowInList == true

                     &&
                     (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "ZAMIN")
                     &&
                     (p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh)
                     &&
                     (cboVaziatMelk.SelectedIndex == 0 || (p.IsParvandeMaskanBePayanResideAst == false && cboVaziatMelk.SelectedIndex == 1) || (p.IsParvandeMaskanBePayanResideAst == true && cboVaziatMelk.SelectedIndex == 2))
                     &&
                      (p.NoeMoavezeId != null && p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh)
                     &&
                     (cboNoeMelk.SelectedIndex == 0 || (p.NoeMelkId == null && cboNoeMelk.SelectedValue == "0") || (p.NoeMelkId != null && cboNoeMelk.SelectedValue == p.NoeMelkId.Value.ToString()))
                     &&
                     (cboNoeKarbari.SelectedIndex == 0 || (cboNoeKarbari.SelectedValue == "0" && p.MaskanNoeKarbaris.Any() == false) || (p.MaskanNoeKarbaris.Any(s => cboNoeKarbari.SelectedValue == s.NoeKarbariId.ToString())))
                     &&
                     (cboDarbAz.SelectedIndex == 0 || (p.DarbAzId == null && cboDarbAz.SelectedValue == "0") || (p.DarbAzId != null && cboDarbAz.SelectedValue == p.DarbAzId.Value.ToString()))
                     &&
                     (cboMakan.SelectedIndex == 0 || (p.MakanId == null && cboMakan.SelectedValue == "0") || (p.MakanId != null && cboMakan.SelectedValue == p.MakanId.Value.ToString()))
                     &&
                     (txtCode.Text.Trim() == "" || p.code != null && p.code.Contains(txtCode.Text.Trim()))
                     &&
                     (MetrazhAz == null || (p.Metrazh != null && p.Metrazh.Value >= MetrazhAz))
                     &&
                     (MetrazhTa == null || (p.Metrazh != null && p.Metrazh.Value <= MetrazhTa))
                     &&
                     (

                          (
                              (ghymatAz == null || (p.Ghymat != null && p.Ghymat.Value >= ghymatAz))
                              &&
                              (ghymatTa == null || (p.Ghymat != null && p.Ghymat.Value <= ghymatTa))
                          )
                     )
                     select new
                     {
                         p.Id,
                         Code = p.code,
                         NoeMelkName = p.NoeMelkId == null ? "-" : p.NoeMelk.Name,
                         NoeMamele = p.NoeMoavezeId == null ? "-" : p.NoeMoaveze.Name,
                         TedadKhab = p.TedadKhabId == null ? "-" : p.TedadKhab.Name,
                         Tabghe = p.TabghaeForoshiId == null ? "-" : p.Tabghe.Name,
                         Metrazh = p.Metrazh,
                         Ejare = p.Mablagh_Ejare,
                         Klid = p.KilidId == null ? "-" : p.Klid.Name,
                         Makan = p.MakanId == null ? "-" : p.Makan.Name,
                         Mantaghe = p.MantagheId == null ? "" : p.Mantaghe.Name,
                         Darbaz = p.DarbAzId == null ? "-" : p.DarbAz.Name,
                         Rahn = p.Mablagh_Rahn,
                         Ghymat = p.Ghymat,
                         Vam = p.Vam,
                         Tol = p.Tol_Abad_Zamin == null ? "" : p.Tol_Abad_Zamin.Value.ToString(),
                         Arz = p.Arz_Abad_Zamin == null ? "" : p.Arz_Abad_Zamin.Value.ToString(),
                         NoeKarbari = p.MaskanNoeKarbaris,
                         AddressKamel = p.AddressKamel,
                         TedadTabaghat = p.TedadTabaghat == null ? "" : p.TedadTabaghat.ToString(),
                         DateTakhlie = p.DateTakhlie == null ? "" : p.DateTakhlie,
                         p.DateSabt_English,
                         Dsc_ShakhsiBarayUser = p.Dsc_ShakhsiBarayUser == null ? "" : p.Dsc_ShakhsiBarayUser,
                         Dsc = p.Dsc == null ? "" : p.Dsc,
                         Pelak = p.Pelak == null ? "" : p.Pelak,
                         MalekName = p.FullNameSahebkhane == null ? "" : p.FullNameSahebkhane,
                         telmalek = p.ShomareTelSahebkhane == null ? "" : p.ShomareTelSahebkhane,
                         mostajerName = p.FullNameMostajer == null ? "" : p.FullNameMostajer,
                         telmostajer = p.ShomareTelMostajer == null ? "" : p.ShomareTelMostajer,
                         VaziatMelk = p.IsParvandeMaskanBePayanResideAst ? "فروش رفته است" : "فروش نرفته است",
                     });


        var Query1 = (from p in Query.ToList()
                      select new
                      {
                          p.Id,
                          p.Code,
                          p.Pelak,
                          p.NoeMamele,
                          NoeMelk = p.NoeMelkName,
                          p.NoeMelkName,
                          p.TedadKhab,
                          NoeKarbari = p.NoeKarbari.Any() ? p.NoeKarbari.Select(s => s.NoeKarbari.Name).Aggregate((a, b) => a + "," + b) : "",
                          p.Tabghe,
                          Metrazh = p.Metrazh == null ? "" : p.Metrazh.Value.ToString("###,###"),
                          Ejare = p.Ejare == null ? "" : p.Ejare.Value.ToString("###,###"),
                          p.Klid,
                          p.Makan,
                          p.Mantaghe,
                          p.Tol,
                          p.Arz,
                          DarbAz = p.Darbaz,
                          Rahn = p.Rahn == null ? "" : p.Rahn.Value.ToString("###,###"),
                          Ghymat = p.Ghymat == null ? "" : p.Ghymat.Value.ToString("###,###"),
                          Vam = p.Vam == null ? "" : p.Vam.Value.ToString("###,###"),
                          Address = p.Makan + (p.Mantaghe == "" ? "" : (" - " + p.Mantaghe)),
                          p.AddressKamel,
                          p.TedadTabaghat,
                          p.DateTakhlie,
                          p.Dsc_ShakhsiBarayUser,
                          p.DateSabt_English,
                          p.Dsc,
                          p.MalekName,
                          p.telmalek,
                          p.mostajerName,
                          p.telmostajer,
                          p.VaziatMelk
                      }).ToList();

        var profile = dc.Amlak_Porofiles.FirstOrDefault();
        rpt.Dictionary.Variables["DateReport"].Value = ReportDate;
        rpt.Dictionary.Variables["Address"].Value = profile.Address;
        rpt.Dictionary.Variables["TEL"].Value = profile.Tel;
        rpt.RegData("ds", Query1.ToList().OrderByDescending(s => s.DateSabt_English));

        rpt.Render();
        System.IO.MemoryStream ms = new System.IO.MemoryStream();
        rpt.ExportDocument(Stimulsoft.Report.StiExportFormat.Pdf, ms);
        //rpt.Print(true);
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.ContentType = "application/pdf";
        HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=Report." + "pdf");
        HttpContext.Current.Response.BinaryWrite(ms.ToArray());
        HttpContext.Current.Response.End();
    }

    private object Search()
    {
        CodeText = txtCode.Text.Trim();
        ghymatTextAz = txtGhymatAz.Text.Trim();
        ghymatTextTa = txtGhymatTa.Text.Trim();
        MetrazhTextAz = txtMetrazhAz.Text.Trim();
        MetrazhTextTa = txtMetrazhTa.Text.Trim();
        NoeMelkCambo = cboNoeMelk.SelectedValue;
        MakanCambo = cboMakan.SelectedValue;
        DarbAzCambo = cboDarbAz.SelectedValue;
        VaziatMelkCambo = cboVaziatMelk.SelectedValue;
        KarbariCambo = cboNoeKarbari.SelectedValue;

        if (rdAll.Checked == true)
            SearchRadio = "all";
        else if (rdTaedShodeha.Checked == true)
            SearchRadio = "rdtaedshodeha";
        else if (rdAgahiha.Checked == true)
            SearchRadio = "rdagahiha";
        else if (rdAgahiHayKhandeNashode.Checked == true)
            SearchRadio = "rdagahihaykhandenashode";
        else if (rdAgahiHayKhandeShode.Checked == true)
            SearchRadio = "rdagahihaykhandeshode";
        else 
            SearchRadio = "all";


        decimal tmp = 0;
        decimal? MetrazhAz = decimal.TryParse(txtMetrazhAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? MetrazhTa = decimal.TryParse(txtMetrazhTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;

        decimal? ghymatAz = decimal.TryParse(txtGhymatAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? ghymatTa = decimal.TryParse(txtGhymatTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        var Query = (from p in dc.Maskans
                     where
                     p.IsDeleted == false
                     &&
                     (
                        rdAll.Checked
                        ||
                        (rdTaedShodeha.Checked && p.ShowInList == true)
                        ||
                        (rdAgahiha.Checked && p.IsAgahi)
                        ||
                        (rdAgahiHayKhandeNashode.Checked && p.IsAgahi == true && p.IsAgahiRead == false)
                        ||
                        (rdAgahiHayKhandeShode.Checked && p.IsAgahi == true && p.IsAgahiRead == true)
                     )
                     &&
                     (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "ZAMIN")
                     &&
                     (p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh)
                     &&
                     (cboVaziatMelk.SelectedIndex == 0 || (p.IsParvandeMaskanBePayanResideAst == false && cboVaziatMelk.SelectedIndex == 1) || (p.IsParvandeMaskanBePayanResideAst == true && cboVaziatMelk.SelectedIndex == 2))
                     &&
                      (p.NoeMoavezeId != null && p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh)
                     &&
                     (cboNoeMelk.SelectedIndex == 0 || (p.NoeMelkId == null && cboNoeMelk.SelectedValue == "0") || (p.NoeMelkId != null && cboNoeMelk.SelectedValue == p.NoeMelkId.Value.ToString()))
                     &&
                     (cboNoeKarbari.SelectedIndex == 0 || (cboNoeKarbari.SelectedValue == "0" && p.MaskanNoeKarbaris.Any() == false) || (p.MaskanNoeKarbaris.Any(s => cboNoeKarbari.SelectedValue == s.NoeKarbariId.ToString())))
                     &&
                     (cboDarbAz.SelectedIndex == 0 || (p.DarbAzId == null && cboDarbAz.SelectedValue == "0") || (p.DarbAzId != null && cboDarbAz.SelectedValue == p.DarbAzId.Value.ToString()))
                     &&
                     (cboMakan.SelectedIndex == 0 || (p.MakanId == null && cboMakan.SelectedValue == "0") || (p.MakanId != null && cboMakan.SelectedValue == p.MakanId.Value.ToString()))
                     &&
                     (txtCode.Text.Trim() == "" || p.code != null && p.code.Contains(txtCode.Text.Trim()))
                     &&
                     (MetrazhAz == null || (p.Metrazh != null && p.Metrazh.Value >= MetrazhAz))
                     &&
                     (MetrazhTa == null || (p.Metrazh != null && p.Metrazh.Value <= MetrazhTa))
                     &&
                     (

                          (
                              (ghymatAz == null || (p.Ghymat != null && p.Ghymat.Value >= ghymatAz))
                              &&
                              (ghymatTa == null || (p.Ghymat != null && p.Ghymat.Value <= ghymatTa))
                          )
                     )
                     select new
                     {
                         values = p.Id + ";" + (p.ShowInList == true ? "true" : "false") + ";" + (p.IsAgahi == true ? "true" : "false") + ";" + (p.IsAgahiRead == true ? "true" : "false"),
                         p.Id,
                         Code = p.code,
                         NoeMelkName = p.NoeMelkId == null ? "-" : p.NoeMelk.Name,
                         TedadKhab = p.TedadKhabId == null ? "-" : p.TedadKhab.Name,
                         Tabghe = p.TabghaeForoshiId == null ? "-" : p.Tabghe.Name,
                         Metrazh = p.Metrazh,
                         karbari = p.MaskanNoeKarbaris,
                         Makan = p.MakanId == null ? "-" : p.Makan.Name,
                         Mantaghe = p.MantagheId == null ? "-" : p.Mantaghe.Name,
                         Darbaz = p.DarbAzId == null ? "-" : p.DarbAz.Name,
                         Vam = p.Vam,
                         Ghymat = p.Ghymat,
                         Address = p.Mantaghe,
                         p.DateTakhlie,
                         url = p.IsParvandeMaskanBePayanResideAst ? "~/Application/Images/Grid/InActive.png" : "~/Application/Images/Grid/Active.png",
                         p.DateSabt_English,
                         p.Pelak,
                         Active = p.IsParvandeMaskanBePayanResideAst,
                         tooltip = p.IsParvandeMaskanBePayanResideAst ? "فروش رفته است" : "هنوز فروش نرفته است",
                         clientclick_EtelaatBishtar = "ShowInfoModelDialog('" + ((p.lat != null && p.lng != null && p.lng.Trim() != "" && p.lat.Trim() != "") ? "true" : "false") + "','" + (p.lat == null ? "" : p.lat) + "','" + (p.lng == null ? "" : p.lng) + "','" + (p.MaskanImages.Any() ? "true" : "false") + "','" + p.Id + "','ADMIN','" + ((p.AxShahrdari == null || p.AxShahrdari.Trim() == "") ? "" : (ImagePath + p.AxShahrdari)) + "'); return false;",
                         vis_Okazion = p.IsOkazion
                     });


        var Query1 = (from p in Query.ToList()
                      select new
                      {
                          p.values,
                          p.Id,
                          p.Mantaghe,
                          p.Code,
                          p.NoeMelkName,
                          p.TedadKhab,
                          p.Tabghe,
                          Metrazh = p.Metrazh == null ? "" : p.Metrazh.Value.ToString("###,###"),
                          karbari = p.karbari.Any() == false ? "-" : p.karbari.Select(s => s.NoeKarbari.Name).Aggregate((a, b) => a + "," + b),
                          Vam = p.Vam == null ? "" : p.Vam.Value.ToString("###,###"),
                          Ghymat = p.Ghymat == null ? "" : p.Ghymat.Value.ToString("###,###"),
                          p.Address,
                          p.url,
                          p.Darbaz,
                          p.Makan,
                          p.DateSabt_English,
                          p.Active,
                          p.tooltip,
                          p.DateTakhlie,
                          p.Pelak,
                          p.vis_Okazion,
                          p.clientclick_EtelaatBishtar
                      });

        lblMavaredSabtShode.Text = Query1.Count().ToString() + " مورد";
        return Query1.OrderByDescending(s => s.DateSabt_English);


    }
    private void SetOldParametr()
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
            {
                txtCode.Text = CodeText;
                txtGhymatAz.Text = ghymatTextAz;
                txtGhymatTa.Text = ghymatTextTa;
                txtMetrazhAz.Text = MetrazhTextAz;
                txtMetrazhTa.Text = MetrazhTextTa;
                cboNoeKarbari.SelectedValue = KarbariCambo;
                cboNoeMelk.SelectedValue = NoeMelkCambo;
                cboMakan.SelectedValue = MakanCambo;
                cboDarbAz.SelectedValue = DarbAzCambo;
                cboVaziatMelk.SelectedValue = VaziatMelkCambo;

                rdAll.Checked = false;
                rdTaedShodeha.Checked = false;
                rdAgahiha.Checked = false;
                rdAgahiHayKhandeNashode.Checked = false;
                rdAgahiHayKhandeShode.Checked = false;

                if (SearchRadio == "all")
                    rdAll.Checked = true;
                else if (SearchRadio == "rdtaedshodeha")
                    rdTaedShodeha.Checked = true;
                else if (SearchRadio == "rdagahiha")
                    rdAgahiha.Checked = true;
                else if (SearchRadio == "rdagahihaykhandenashode")
                    rdAgahiHayKhandeNashode.Checked = true;
                else if (SearchRadio == "rdagahihaykhandeshode")
                    rdAgahiHayKhandeShode.Checked = true;
                else
                    rdAll.Checked = true;
            }
        }
    }
    private void DeleteRecord(string Id)
    {
        var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == Id);
        if (obj == null)
        {
            ShowErrorMessage("</br>" + "رکورد یافت نشد");
            liSearch_Grid.RaiseViewChanged();
            return;
        }
        List<string> imageurl = new List<string>();
        if (obj.MaskanImages.Any())
        {
            ShowErrorMessage("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
            liSearch_Grid.RaiseViewChanged();
            return;
        }
        obj.IsDeleted = true;
        dc.SubmitChanges();
        ShowSeccessMessage("</br>" + "رکورد با موفقیت حذف گردید");
        liSearch_Grid.RaiseViewChanged();


    }
    private void BindCambo()
    {

        cboNoeKarbari.DataSource = (from p in dc.MaskanNoeKarbaris
                                    where
                                    p.Maskan.IsDeleted == false
                                    &&
                                    (p.Maskan.NoeMelkId == null || p.Maskan.NoeMelk.GROUPTYPE == "ZAMIN")
                                    &&
                                    (
                                     p.Maskan.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh
                                     ||
                                     p.Maskan.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh
                                     )
                                    select new
                                    {
                                        Id = p.NoeKarbariId == null ? 0 : p.NoeKarbariId,
                                        Name = p.NoeKarbariId == null ? "ثبت نشده" : p.NoeKarbari.Name,
                                        priority = p.NoeKarbariId == null ? (int?)null : p.NoeKarbari.priority,
                                    }).Distinct().OrderBy(s => s.priority).ToList();
        cboNoeKarbari.DataBind();
        cboNoeKarbari.Items.Insert(0, new ListItem("همه موارد", "-1"));

        cboNoeMelk.DataSource = (from p in dc.Maskans
                                 where
                                 p.IsDeleted == false
                                 &&
                                 (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "ZAMIN")
                                 &&
                                   (
                                    p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh
                                    ||
                                    p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh
                                    )
                                 select new
                                     {
                                         Id = p.NoeMelkId == null ? 0 : p.NoeMelkId,
                                         Name = p.NoeMelkId == null ? "ثبت نشده" : p.NoeMelk.Name,
                                         priority = p.NoeMelkId == null ? (int?)null : p.NoeMelk.priority,
                                     }).Distinct().OrderBy(s => s.priority).ToList();
        cboNoeMelk.DataBind();
        cboNoeMelk.Items.Insert(0, new ListItem("همه موارد", "-1"));

        cboMakan.DataSource = (from p in dc.Maskans
                               where
                               p.IsDeleted == false
                               &&
                               (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "ZAMIN")
                               &&
                                   (
                                    p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh
                                    ||
                                    p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh
                                    )
                               select new
                               {
                                   Id = p.MakanId == null ? 0 : p.MakanId,
                                   Name = p.MakanId == null ? "ثبت نشده" : p.Makan.Name,
                                   priority = p.MakanId == null ? (int?)null : p.Makan.Priority,
                               }).Distinct().OrderBy(s => s.priority).ToList();
        cboMakan.DataBind();
        cboMakan.Items.Insert(0, new ListItem("همه موارد", "-1"));

        cboDarbAz.DataSource = (from p in dc.Maskans
                                where
                                p.IsDeleted == false
                                &&
                                (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "ZAMIN")
                                &&
                                   (
                                    p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh
                                    ||
                                    p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh
                                    )
                                select new
                                {
                                    Id = p.DarbAzId == null ? 0 : p.DarbAzId,
                                    Name = p.DarbAzId == null ? "ثبت نشده" : p.DarbAz.Name,
                                    priority = p.DarbAzId == null ? (int?)null : p.DarbAz.priority,
                                }).Distinct().OrderBy(s => s.priority).ToList();
        cboDarbAz.DataBind();
        cboDarbAz.Items.Insert(0, new ListItem("همه موارد", "-1"));
    }


}