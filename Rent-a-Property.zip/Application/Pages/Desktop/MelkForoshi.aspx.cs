﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Application_Pages_Desktop_MelkForoshi : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    public int OldIndex
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["OldIndex"] != null)
            {

                return Convert.ToInt32(Request.Cookies["SearchCookieMelkForoshi"]["OldIndex"]);
            }

            return 0;
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["OldIndex"] = value.ToString();
        }
    }
    public string ghymatTextAz
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["ghymatTextAz"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["ghymatTextAz"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["ghymatTextAz"] = value.ToString();
        }
    }
    public string ghymatTextTa
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["ghymatTextTa"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["ghymatTextTa"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["ghymatTextTa"] = value.ToString();
        }
    }
    public string NoeMoameleCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["NoeMoameleCambo"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["NoeMoameleCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["NoeMoameleCambo"] = value.ToString();
        }
    }
    public string MetrazhTextAz
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["MetrazhTextAz"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["MetrazhTextAz"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["MetrazhTextAz"] = value.ToString();
        }
    }
    public string MetrazhTextTa
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["MetrazhTextTa"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["MetrazhTextTa"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["MetrazhTextTa"] = value.ToString();
        }
    }
    public string CodeText
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["CodeText"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["CodeText"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["CodeText"] = value.ToString();
        }
    }
    public string VaziatMelkCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["VaziatMelkCambo"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["VaziatMelkCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["VaziatMelkCambo"] = value.ToString();
        }
    }
    public string TedadKhabCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["TedadKhabCambo"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["TedadKhabCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["TedadKhabCambo"] = value.ToString();
        }
    }
    public string NoeMelkCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["NoeMelkCambo"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["NoeMelkCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["NoeMelkCambo"] = value.ToString();
        }
    }
    public string MakanCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieMelkForoshi"] != null && Request.Cookies["SearchCookieMelkForoshi"]["MakanCambo"] != null)
            {

                return Request.Cookies["SearchCookieMelkForoshi"]["MakanCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieMelkForoshi"]["MakanCambo"] = value.ToString();
        }
    }
    public string SearchRadio
    {
        get
        {
            if (Request.Cookies["SearchRadioMelkForoshi"] != null && Request.Cookies["SearchRadioMelkForoshi"]["SearchRadio"] != null)
            {

                return Request.Cookies["SearchRadioMelkForoshi"]["SearchRadio"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchRadioMelkForoshi"]["SearchRadio"] = value.ToString();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        cboVaziatMelk.Focus();
        Form.DefaultButton = btnSearch.UniqueID;
        if (!IsPostBack)
        {
            BindCambo();
            SetOldParametr();
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        liSearch_Grid.RaiseViewChanged();
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("MelkForoshiSpec.aspx");
    }
    protected void gvResult_PageIndexChanged(object sender, EventArgs e)
    {

        this.OldIndex = gvResult.PageIndex;

    }
    protected void gvResult_DataBound(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                    gvResult.PageIndex = OldIndex;

            }
        }

        foreach (GridViewRow row in gvResult.Rows)
        {
            string value = gvResult.DataKeys[row.RowIndex].Value.ToString();
            string[] values = value.Split(';');
            if (values[1] == "false" && values[2] == "true" && values[3] == "false")
            {
                row.BackColor = Color.FromName("#fbffa5");
                row.ToolTip = "آگهی خوانده نشده";
            }
            if (values[1] == "false" && values[2] == "true" && values[3] == "true")
            {
                row.BackColor = Color.FromName("#86ff78");
                row.ToolTip = "آگهی خوانده شده";
            }
        }


        if (cboNoeMoamele.SelectedValue == ((int)DataValueIds.NoeMoavezeIds.KharidVaForosh).ToString())
        {
            gvResult.Columns[9].HeaderText = "تاریخ تخلیه";
        }
        else if (cboNoeMoamele.SelectedValue == ((int)DataValueIds.NoeMoavezeIds.PishForosh).ToString())
        {
            gvResult.Columns[9].HeaderText = "تاریخ تحویل";
        }
        else
            gvResult.Columns[9].HeaderText = "تاریخ تخلیه/تحویل";
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRow")
        {
            DeleteRecord(e.CommandArgument.ToString());

        }
        if (e.CommandName == "EditRow")
        {
            Response.Redirect(ArssPayamUtility.GetEncodedQueryString("MelkForoshiSpec.aspx?args={0}", "ID=" + e.CommandArgument));
        }
    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        ExcelExport();
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        Print();
    }

    private void ExcelExport()
    {
        decimal tmp = 0;
        decimal? MetrazhAz = decimal.TryParse(txtMetrazhAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? MetrazhTa = decimal.TryParse(txtMetrazhTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        decimal? GhymatAz = decimal.TryParse(txtGhymatAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? GhymatTa = decimal.TryParse(txtGhymatTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        var Query = from p in dc.Maskans
                    where
                    p.IsDeleted == false
                    &&
                   (

                        rdAll.Checked
                        ||
                        (rdTaedShodeha.Checked && p.ShowInList == true)
                        ||
                        (rdAgahiha.Checked && p.IsAgahi)
                        ||
                        (rdAgahiHayKhandeNashode.Checked && p.IsAgahi == true && p.IsAgahiRead == false)
                        ||
                        (rdAgahiHayKhandeShode.Checked && p.IsAgahi == true && p.IsAgahiRead == true)
                     )
                     &&
                    (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "MELK")
                    &&
                    (cboVaziatMelk.SelectedIndex == 0 || (p.IsParvandeMaskanBePayanResideAst == false && cboVaziatMelk.SelectedIndex == 1) || (p.IsParvandeMaskanBePayanResideAst == true && cboVaziatMelk.SelectedIndex == 2))
                    &&
                    p.NoeMoavezeId != null && (p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh)
                    &&
                    (cboNoeMoamele.SelectedIndex == 0 || (p.NoeMoavezeId == null && cboNoeMoamele.SelectedValue == "0") || (p.NoeMoavezeId != null && cboNoeMoamele.SelectedValue == p.NoeMoavezeId.Value.ToString()))
                    &&
                    (cboNoeMelk.SelectedIndex == 0 || (p.NoeMelkId == null && cboNoeMelk.SelectedValue == "0") || (p.NoeMelkId != null && cboNoeMelk.SelectedValue == p.NoeMelkId.Value.ToString()))
                    &&
                    (cboTedadKhab.SelectedIndex == 0 || (p.TedadKhabId == null && cboTedadKhab.SelectedValue == "0") || (p.TedadKhabId != null && cboTedadKhab.SelectedValue == p.TedadKhabId.Value.ToString()))
                    &&
                    (cboMakan.SelectedIndex == 0 || (p.MakanId == null && cboMakan.SelectedValue == "0") || (p.MakanId != null && cboMakan.SelectedValue == p.MakanId.Value.ToString()))
                    &&
                    (txtCode.Text.Trim() == "" || p.code != null && p.code.Contains(txtCode.Text.Trim()))
                    &&
                    (MetrazhAz == null || (p.Metrazh != null && p.Metrazh.Value >= MetrazhAz))
                    &&
                    (MetrazhTa == null || (p.Metrazh != null && p.Metrazh.Value <= MetrazhTa))
                    &&
                    (
                        (GhymatAz == null || (p.Ghymat != null && p.Ghymat.Value >= GhymatAz))
                        &&
                        (GhymatTa == null || (p.Ghymat != null && p.Ghymat.Value <= GhymatTa))
                    )
                    select new
                    {
                        p.Id,
                        Code = p.code,
                        NoeMelkName = p.NoeMelkId == null ? "-" : p.NoeMelk.Name,
                        NoeMamele = p.NoeMoavezeId == null ? "-" : p.NoeMoaveze.Name,
                        TedadKhab = p.TedadKhabId == null ? "-" : p.TedadKhab.Name,
                        Tabghe = p.TabghaeForoshiId == null ? "-" : p.Tabghe.Name,
                        Metrazh = p.Metrazh,
                        Ejare = p.Mablagh_Ejare,
                        Klid = p.KilidId == null ? "-" : p.Klid.Name,
                        Makan = p.MakanId == null ? "-" : p.Makan.Name,
                        Mantaghe = p.MantagheId == null ? "" : p.Mantaghe.Name,
                        Darbaz = p.DarbAzId == null ? "-" : p.DarbAz.Name,
                        Rahn = p.Mablagh_Rahn,
                        Ghymat = p.Ghymat,
                        Vam = p.Vam,
                        Address = p.AddressKamel,
                        TedadTabaghat = p.TedadTabaghat == null ? "" : p.TedadTabaghat.ToString(),
                        DateTakhlie = p.DateTakhlie == null ? "" : p.DateTakhlie,
                        p.DateSabt_English,
                        Dsc_ShakhsiBarayUser = p.Dsc_ShakhsiBarayUser == null ? "" : p.Dsc_ShakhsiBarayUser,
                        Dsc = p.Dsc == null ? "" : p.Dsc,
                        MalekName = p.FullNameSahebkhane == null ? "" : p.FullNameSahebkhane,
                        telmalek = p.ShomareTelSahebkhane == null ? "" : p.ShomareTelSahebkhane,
                        mostajerName = p.FullNameMostajer == null ? "" : p.FullNameMostajer,
                        telmostajer = p.ShomareTelMostajer == null ? "" : p.ShomareTelMostajer,
                        VaziatMelk = p.IsParvandeMaskanBePayanResideAst ? "فروش رفته است" : "فروش نرفته است",
                    };


        var Query1 = (from p in Query.ToList()
                      select new
                      {
                          p.Id,
                          p.Code,
                          p.NoeMamele,
                          p.NoeMelkName,
                          p.TedadKhab,
                          p.Tabghe,
                          Metrazh = p.Metrazh == null ? "" : p.Metrazh.Value.ToString("###,###"),
                          Ejare = p.Ejare == null ? "" : p.Ejare.Value.ToString("###,###"),
                          p.Klid,
                          p.Makan,
                          p.Mantaghe,
                          p.Darbaz,
                          Rahn = p.Rahn == null ? "" : p.Rahn.Value.ToString("###,###"),
                          Ghymat = p.Ghymat == null ? "" : p.Ghymat.Value.ToString("###,###"),
                          Vam = p.Vam == null ? "" : p.Vam.Value.ToString("###,###"),
                          p.Address,
                          p.TedadTabaghat,
                          p.DateTakhlie,
                          p.Dsc_ShakhsiBarayUser,
                          p.DateSabt_English,
                          p.Dsc,
                          p.MalekName,
                          p.telmalek,
                          p.mostajerName,
                          p.telmostajer,
                          p.VaziatMelk
                      });


        string[] columnsname ={                          
                          "VaziatMelk",
                          "Code",
                          "NoeMamele",
                          "NoeMelkName",
                          "TedadKhab",
                          "Tabghe",
                          "Metrazh" ,   
                          "Darbaz",
                          "Klid",
                          "Makan",
                          "Mantaghe",                   
                          "Address",                          
                          "Ghymat"  ,
                          "Vam" ,
                          "TedadTabaghat",
                          "DateTakhlie",
                          "MalekName",
                          "telmalek",
                          "mostajerName",
                          "telmostajer",
                          "Dsc",
                          "Dsc_ShakhsiBarayUser"
                            };
        string[] Pcolumnsname ={                          
                          "وضعیت ملک",
                          "کد",
                          "نوع معامله",
                          "نوع ملک",
                          "تعداد خواب",
                          "طبقه اسکان",
                          "متراژ(مترمربع)" ,   
                          "درب از",
                          "کلید",
                          "مکان",
                          "منطقه",                   
                          "آدرس",                          
                          "قیمت ( تومان)"  ,
                          " وام (تومان)" ,
                          "تعداد طبقات",
                          "تاریخ تخلیه/تحویل",
                          "نام و نام خانوادگی مالک",
                          "شماره تمایس با مالک",
                          "نام و نام خانوادگی مستاجر",
                          "شماره تماس مستاجر",
                          "توضیحات ثبت شده در سایت",
                          "توضیحات مربوط به کاربر"
                            };

        ExcelExporter ex = new ExcelExporter(Query1.OrderByDescending(s=>s.DateSabt_English), "خرید و فروش ", Pcolumnsname.ToList(), columnsname.ToList());
        ex.Export("KharidVaForosh", "گزارش خرید و فروش ملک", true);

    }
    private void Print()
    {
        string RptName = "\\KharidVaForoshKhune.mrt";

        string ReportDate = DateShamsi.GetCurrentDate();
        string ReportTime = DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second;

        Stimulsoft.Report.StiReport rpt = new Stimulsoft.Report.StiReport();
        rpt.Load(HttpContext.Current.Server.MapPath("~\\ReportFiles" + RptName));


        decimal tmp = 0;
        decimal? MetrazhAz = decimal.TryParse(txtMetrazhAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? MetrazhTa = decimal.TryParse(txtMetrazhTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        decimal? GhymatAz = decimal.TryParse(txtGhymatAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? GhymatTa = decimal.TryParse(txtGhymatTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        var Query = from p in dc.Maskans
                    where
                    p.IsDeleted == false
                    &&
                    p.ShowInList==true
                    &&
                    (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "MELK")
                    &&
                    (cboVaziatMelk.SelectedIndex == 0 || (p.IsParvandeMaskanBePayanResideAst == false && cboVaziatMelk.SelectedIndex == 1) || (p.IsParvandeMaskanBePayanResideAst == true && cboVaziatMelk.SelectedIndex == 2))
                    &&
                    p.NoeMoavezeId != null && (p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh)
                    &&
                    (cboNoeMoamele.SelectedIndex == 0 || (p.NoeMoavezeId == null && cboNoeMoamele.SelectedValue == "0") || (p.NoeMoavezeId != null && cboNoeMoamele.SelectedValue == p.NoeMoavezeId.Value.ToString()))
                    &&
                    (cboNoeMelk.SelectedIndex == 0 || (p.NoeMelkId == null && cboNoeMelk.SelectedValue == "0") || (p.NoeMelkId != null && cboNoeMelk.SelectedValue == p.NoeMelkId.Value.ToString()))
                    &&
                    (cboTedadKhab.SelectedIndex == 0 || (p.TedadKhabId == null && cboTedadKhab.SelectedValue == "0") || (p.TedadKhabId != null && cboTedadKhab.SelectedValue == p.TedadKhabId.Value.ToString()))
                    &&
                    (cboMakan.SelectedIndex == 0 || (p.MakanId == null && cboMakan.SelectedValue == "0") || (p.MakanId != null && cboMakan.SelectedValue == p.MakanId.Value.ToString()))
                    &&
                    (txtCode.Text.Trim() == "" || p.code != null && p.code.Contains(txtCode.Text.Trim()))
                    &&
                    (MetrazhAz == null || (p.Metrazh != null && p.Metrazh.Value >= MetrazhAz))
                    &&
                    (MetrazhTa == null || (p.Metrazh != null && p.Metrazh.Value <= MetrazhTa))
                    &&
                    (
                        (GhymatAz == null || (p.Ghymat != null && p.Ghymat.Value >= GhymatAz))
                        &&
                        (GhymatTa == null || (p.Ghymat != null && p.Ghymat.Value <= GhymatTa))
                    )
                    select new
                    {
                        p.Id,
                        Code = p.code,
                        NoeMelkName = p.NoeMelkId == null ? "-" : p.NoeMelk.Name,
                        NoeMamele = p.NoeMoavezeId == null ? "-" : p.NoeMoaveze.Name,
                        TedadKhab = p.TedadKhabId == null ? "-" : p.TedadKhab.Name,
                        Tabghe = p.TabghaeForoshiId == null ? "-" : p.Tabghe.Name,
                        Metrazh = p.Metrazh,
                        Ejare = p.Mablagh_Ejare,
                        Klid = p.KilidId == null ? "-" : p.Klid.Name,
                        Makan = p.MakanId == null ? "-" : p.Makan.Name,
                        Mantaghe =p.LittleAddress_Baray_Namayesh_Dar_Site==null?"":p.LittleAddress_Baray_Namayesh_Dar_Site, //p.MantagheId == null ? "" : p.Mantaghe.Name,
                        Darbaz = p.DarbAzId == null ? "-" : p.DarbAz.Name,
                        Rahn = p.Mablagh_Rahn,
                        Ghymat = p.Ghymat,
                        Vam = p.Vam,
                        Address = p.AddressKamel,
                        TedadTabaghat = p.TedadTabaghat == null ? "" : p.TedadTabaghat.ToString(),
                        DateTakhlie = p.DateTakhlie == null ? "" : p.DateTakhlie,
                        p.DateSabt_English,
                        Dsc_ShakhsiBarayUser = p.Dsc_ShakhsiBarayUser == null ? "" : p.Dsc_ShakhsiBarayUser,
                        Dsc = p.Dsc == null ? "" : p.Dsc,
                        MalekName = p.FullNameSahebkhane == null ? "" : p.FullNameSahebkhane,
                        telmalek = p.ShomareTelSahebkhane == null ? "" : p.ShomareTelSahebkhane,
                        mostajerName = p.FullNameMostajer == null ? "" : p.FullNameMostajer,
                        telmostajer = p.ShomareTelMostajer == null ? "" : p.ShomareTelMostajer,
                        VaziatMelk = p.IsParvandeMaskanBePayanResideAst ? "فروش رفته است" : "فروش نرفته است",
                    };


        var Query1 = (from p in Query.ToList()
                      select new
                      {
                          p.Id,
                          p.Code,
                          p.NoeMamele,
                          p.NoeMelkName,
                          NoeMelk=p.NoeMelkName,
                          p.TedadKhab,
                          Khab=p.TedadKhab,
                          p.Tabghe,
                          Tabaghe=p.Tabghe,
                          Metrazh = p.Metrazh == null ? "" : p.Metrazh.Value.ToString("###,###"),
                          Ejare = p.Ejare == null ? "" : p.Ejare.Value.ToString("###,###"),
                          p.Klid,
                          p.Makan,
                          Address = p.Mantaghe,
                          p.Darbaz,
                          Rahn = p.Rahn == null ? "" : p.Rahn.Value.ToString("###,###"),
                          Ghymat = p.Ghymat == null ? "" : p.Ghymat.Value.ToString("###,###"),
                          Vam = p.Vam == null ? "" : p.Vam.Value.ToString("###,###"),
                          Address1 = p.Address,
                          p.TedadTabaghat,
                          p.DateTakhlie,
                          p.Dsc_ShakhsiBarayUser,
                          p.DateSabt_English,
                          p.Dsc,
                          p.MalekName,
                          p.telmalek,
                          p.mostajerName,
                          p.telmostajer,
                          p.VaziatMelk
                      });

        var profile = dc.Amlak_Porofiles.FirstOrDefault();
        rpt.Dictionary.Variables["DateReport"].Value = ReportDate;
        rpt.Dictionary.Variables["Address"].Value = profile.Address;
        rpt.Dictionary.Variables["TEL"].Value = profile.Tel;
        rpt.RegData("ds", Query1.ToList().OrderByDescending(s => s.DateSabt_English));

        rpt.Render();
        System.IO.MemoryStream ms = new System.IO.MemoryStream();
        rpt.ExportDocument(Stimulsoft.Report.StiExportFormat.Pdf, ms);
        //rpt.Print(true);
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.ContentType = "application/pdf";
        HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=Report." + "pdf");
        HttpContext.Current.Response.BinaryWrite(ms.ToArray());
        HttpContext.Current.Response.End();
    }
    private object Search()
    {
        CodeText = txtCode.Text.Trim();
        ghymatTextAz = txtGhymatAz.Text.Trim();
        ghymatTextTa = txtGhymatTa.Text.Trim();

        MetrazhTextAz = txtMetrazhAz.Text.Trim();
        MetrazhTextTa = txtMetrazhTa.Text.Trim();
        NoeMoameleCambo = cboNoeMoamele.SelectedValue;
        NoeMelkCambo = cboNoeMelk.SelectedValue;
        TedadKhabCambo = cboTedadKhab.SelectedValue;
        VaziatMelkCambo = cboVaziatMelk.SelectedValue;
        MakanCambo = cboMakan.SelectedValue;

        if (rdAll.Checked == true)
            SearchRadio = "all";
        else if (rdTaedShodeha.Checked == true)
            SearchRadio = "rdtaedshodeha";
        else if (rdAgahiha.Checked == true)
            SearchRadio = "rdagahiha";
        else if (rdAgahiHayKhandeNashode.Checked == true)
            SearchRadio = "rdagahihaykhandenashode";
        else if (rdAgahiHayKhandeShode.Checked == true)
            SearchRadio = "rdagahihaykhandeshode";
        else
            SearchRadio = "all";

        decimal tmp = 0;
        decimal? MetrazhAz = decimal.TryParse(txtMetrazhAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? MetrazhTa = decimal.TryParse(txtMetrazhTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        decimal? GhymatAz = decimal.TryParse(txtGhymatAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? GhymatTa = decimal.TryParse(txtGhymatTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        var Query = from p in dc.Maskans
                    where
                    p.IsDeleted == false
                    &&
                   (

                        rdAll.Checked
                        ||
                        (rdTaedShodeha.Checked && p.ShowInList == true)
                        ||
                        (rdAgahiha.Checked && p.IsAgahi)
                        ||
                        (rdAgahiHayKhandeNashode.Checked && p.IsAgahi == true && p.IsAgahiRead == false)
                        ||
                        (rdAgahiHayKhandeShode.Checked && p.IsAgahi == true && p.IsAgahiRead == true)
                     )
                     &&
                    (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "MELK")
                    &&
                    (cboVaziatMelk.SelectedIndex == 0 || (p.IsParvandeMaskanBePayanResideAst == false && cboVaziatMelk.SelectedIndex == 1) || (p.IsParvandeMaskanBePayanResideAst == true && cboVaziatMelk.SelectedIndex == 2))
                    &&
                    p.NoeMoavezeId != null && (p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh)
                    &&
                    (cboNoeMoamele.SelectedIndex == 0 || (p.NoeMoavezeId == null && cboNoeMoamele.SelectedValue == "0") || (p.NoeMoavezeId != null && cboNoeMoamele.SelectedValue == p.NoeMoavezeId.Value.ToString()))
                    &&
                    (cboNoeMelk.SelectedIndex == 0 || (p.NoeMelkId == null && cboNoeMelk.SelectedValue == "0") || (p.NoeMelkId != null && cboNoeMelk.SelectedValue == p.NoeMelkId.Value.ToString()))
                    &&
                    (cboTedadKhab.SelectedIndex == 0 || (p.TedadKhabId == null && cboTedadKhab.SelectedValue == "0") || (p.TedadKhabId != null && cboTedadKhab.SelectedValue == p.TedadKhabId.Value.ToString()))
                    &&
                    (cboMakan.SelectedIndex == 0 || (p.MakanId == null && cboMakan.SelectedValue == "0") || (p.MakanId != null && cboMakan.SelectedValue == p.MakanId.Value.ToString()))
                    &&
                    (txtCode.Text.Trim() == "" || p.code != null && p.code.Contains(txtCode.Text.Trim()))
                    &&
                    (MetrazhAz == null || (p.Metrazh != null && p.Metrazh.Value >= MetrazhAz))
                    &&
                    (MetrazhTa == null || (p.Metrazh != null && p.Metrazh.Value <= MetrazhTa))
                    &&
                    (
                        (GhymatAz == null || (p.Ghymat != null && p.Ghymat.Value >= GhymatAz))
                        &&
                        (GhymatTa == null || (p.Ghymat != null && p.Ghymat.Value <= GhymatTa))
                    )
                    select new
                    {
                        values = p.Id + ";" + (p.ShowInList == true ? "true" : "false") + ";" + (p.IsAgahi == true ? "true" : "false") + ";" + (p.IsAgahiRead == true ? "true" : "false"),
                        p.Id,
                        Code = p.code,
                        NoeMelkName = p.NoeMelkId == null ? "-" : p.NoeMelk.Name,
                        TedadKhab = p.TedadKhabId == null ? "-" : p.TedadKhab.Name,
                        Tabghe = p.TabghaeForoshiId == null ? "-" : p.Tabghe.Name,
                        Metrazh = p.Metrazh,
                        Makan = p.MakanId == null ? "-" : p.Makan.Name,
                        Darbaz = p.DarbAzId == null ? "-" : p.DarbAz.Name,
                        vam = p.Vam,
                        Ghymat = p.Ghymat,
                        AddressKamel = p.AddressKamel,
                        p.DateTakhlie,
                        url = p.IsParvandeMaskanBePayanResideAst ? "~/Application/Images/Grid/InActive.png" : "~/Application/Images/Grid/Active.png",
                        p.DateSabt_English,
                        Active = p.IsParvandeMaskanBePayanResideAst,
                        tooltip = p.IsParvandeMaskanBePayanResideAst ? "فروش رفته است" : "فروش نرفته است",
                        clientclick_EtelaatBishtar = "ShowInfoModelDialog('" + ((p.lat != null && p.lng != null && p.lng.Trim() != "" && p.lat.Trim() != "") ? "true" : "false") + "','" + (p.lat == null ? "" : p.lat) + "','" + (p.lng == null ? "" : p.lng) + "','" + (p.MaskanImages.Any() ? "true" : "false") + "','" + p.Id + "','ADMIN','" + ((p.AxShahrdari == null || p.AxShahrdari.Trim() == "") ? "" : (ImagePath + p.AxShahrdari)) + "'); return false;",
                        vis_Okazion = p.IsOkazion,
                        p.LittleAddress_Baray_Namayesh_Dar_Site,
                    };


        var Query1 = (from p in Query.ToList()
                      select new
                      {
                          p.values,
                          p.Id,
                          p.Code,
                          p.NoeMelkName,
                          p.TedadKhab,
                          p.Tabghe,
                          Metrazh = p.Metrazh == null ? "" : p.Metrazh.Value.ToString("###,###"),
                          vam = p.vam == null ? "" : p.vam.Value.ToString("###,###"),
                          Ghymat = p.Ghymat == null ? "" : p.Ghymat.Value.ToString("###,###"),
                          Address=p.LittleAddress_Baray_Namayesh_Dar_Site,
                          p.AddressKamel,
                          p.url,
                          p.Darbaz,
                          p.Makan,
                          p.DateSabt_English,
                          p.Active,
                          p.tooltip,
                          p.DateTakhlie,
                          p.clientclick_EtelaatBishtar,
                          p.vis_Okazion
                      });





        lblMavaredSabtShode.Text = Query1.Count().ToString() + " مورد";
        return Query1.OrderByDescending(s => s.DateSabt_English);


    }
    private void SetOldParametr()
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
            {
                txtCode.Text = CodeText;
                txtGhymatTa.Text = ghymatTextAz;
                txtGhymatTa.Text = ghymatTextTa;
                txtMetrazhAz.Text = MetrazhTextAz;
                txtMetrazhTa.Text = MetrazhTextTa;

                cboNoeMoamele.SelectedValue = NoeMoameleCambo;
                cboNoeMelk.SelectedValue = NoeMelkCambo;
                cboTedadKhab.SelectedValue = TedadKhabCambo;
                cboVaziatMelk.SelectedValue = VaziatMelkCambo;
                cboMakan.SelectedValue = MakanCambo;

                rdAll.Checked = false;
                rdTaedShodeha.Checked = false;
                rdAgahiha.Checked = false;
                rdAgahiHayKhandeNashode.Checked = false;
                rdAgahiHayKhandeShode.Checked = false;

                if (SearchRadio == "all")
                    rdAll.Checked = true;
                else if (SearchRadio == "rdtaedshodeha")
                    rdTaedShodeha.Checked = true;
                else if (SearchRadio == "rdagahiha")
                    rdAgahiha.Checked = true;
                else if (SearchRadio == "rdagahihaykhandenashode")
                    rdAgahiHayKhandeNashode.Checked = true;
                else if (SearchRadio == "rdagahihaykhandeshode")
                    rdAgahiHayKhandeShode.Checked = true;
                else
                    rdAll.Checked = true;

            }
        }
    }
    private void DeleteRecord(string Id)
    {
        var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == Id);
        if (obj == null)
        {
            ShowErrorMessage("</br>" + "رکورد یافت نشد");
            liSearch_Grid.RaiseViewChanged();
            return;
        }
        List<string> imageurl = new List<string>();
        if (obj.MaskanImages.Any())
        {
            ShowErrorMessage("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
            liSearch_Grid.RaiseViewChanged();
            return;
        }
        obj.IsDeleted = true;
        dc.SubmitChanges();
        ShowSeccessMessage("</br>" + "رکورد با موفقیت حذف گردید");
        liSearch_Grid.RaiseViewChanged();


    }
    private void BindCambo()
    {

        cboNoeMoamele.DataSource = (from p in dc.Maskans
                                    where
                                    p.IsDeleted == false
                                    &&
                                    (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "MELK")
                                    &&
                                    (
                                    p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh
                                    ||
                                    p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh
                                    )
                                    select new
                                    {
                                        Id = p.NoeMoavezeId == null ? 0 : p.NoeMoavezeId,
                                        Name = p.NoeMoavezeId == null ? "ثبت نشده" : p.NoeMoaveze.Name,
                                        priority = p.NoeMoavezeId == null ? (int?)null : p.NoeMoaveze.priority,
                                    }).Distinct().OrderBy(s => s.priority).ToList();
        cboNoeMoamele.DataBind();
        cboNoeMoamele.Items.Insert(0, new ListItem("همه موارد", "-1"));

        cboNoeMelk.DataSource = (from p in dc.Maskans
                                 where
                                 p.IsDeleted == false
                                 &&
                                 (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "MELK")
                                 &&
                                 (
                                 p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh
                                 ||
                                 p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh
                                 )
                                 select new
                                     {
                                         Id = p.NoeMelkId == null ? 0 : p.NoeMelkId,
                                         Name = p.NoeMelkId == null ? "ثبت نشده" : p.NoeMelk.Name,
                                         priority = p.NoeMelkId == null ? (int?)null : p.NoeMelk.priority,
                                     }).Distinct().OrderBy(s => s.priority).ToList();
        cboNoeMelk.DataBind();
        cboNoeMelk.Items.Insert(0, new ListItem("همه موارد", "-1"));

        cboTedadKhab.DataSource = (from p in dc.Maskans
                                   where
                                   p.IsDeleted == false
                                   &&
                                   (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "MELK")
                                   &&
                                 (
                                 p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh
                                 ||
                                 p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh
                                 )
                                   select new
                                   {
                                       Id = p.TedadKhabId == null ? 0 : p.TedadKhabId,
                                       Name = p.TedadKhabId == null ? "ثبت نشده" : p.TedadKhab.Name,
                                       priority = p.TedadKhabId == null ? (int?)null : p.TedadKhab.priority,
                                   }).Distinct().OrderBy(s => s.priority).ToList();
        cboTedadKhab.DataBind();
        cboTedadKhab.Items.Insert(0, new ListItem("همه موارد", "-1"));

        cboMakan.DataSource = (from p in dc.Maskans
                               where
                               p.IsDeleted == false
                               &&
                               (p.NoeMelkId == null || p.NoeMelk.GROUPTYPE == "MELK")
                               &&
                                 (
                                 p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh
                                 ||
                                 p.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh
                                 )
                               select new
                               {
                                   Id = p.MakanId == null ? 0 : p.MakanId,
                                   Name = p.MakanId == null ? "ثبت نشده" : p.Makan.Name,
                                   priority = p.MakanId == null ? (int?)null : p.Makan.Priority,
                               }).Distinct().OrderBy(s => s.priority).ToList();
        cboMakan.DataBind();
        cboMakan.Items.Insert(0, new ListItem("همه موارد", "-1"));

    }


}