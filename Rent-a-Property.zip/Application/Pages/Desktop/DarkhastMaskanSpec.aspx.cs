﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Application_Pages_Desktop_DarkhastMaskanSpec : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        txtname.Focus();
        Form.DefaultButton = btnsave.UniqueID;
        if (!IsPostBack)
        {
            Display();
        }
    }


    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ReturnToLastPage();
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (Checkvalidate())
        {
            Save();
            ReturnToLastPage();
        }
    }



    private void Display()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.DarkhastMaskans.FirstOrDefault(s => s.UID.ToString() == ID);
        if (obj == null || obj.IsDeleted)
            ReturnToLastPage();

        txtMozo.Text = obj.NoeDarkhast.Name;
        txtname.Text = obj.NameFrestande;
        txtEMail.Text = obj.EmailFrestande;
        txtDsc_Darkhast.Text = obj.Dsc_Darkhast;
        txtshomaretamas.Text = obj.TelFrestande;
        txtzamandarkhast.Text = obj.DateErsal + " [ " + obj.TimeErsal + " ]";
        hflatlng.Value = obj.lat + "," + obj.lng;
        txtdsc_pasokh.Text = obj.Javab;
        txtdatepasokh.Text = obj.DateTimeJavab == null ? "" : (obj.DatePasokh + " [ " + obj.TimePasokh + " ]");

        obj.IsRead = true;
        dc.SubmitChanges();

    }
    private void Save()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.DarkhastMaskans.FirstOrDefault(s => s.UID.ToString() == ID);
        if (obj == null)
        {
            return;
        }

        obj.TimePasokh = DateShamsi.GetCurrentHour();
        obj.DatePasokh = DateShamsi.GetCurrentDate();
        obj.Javab = txtdsc_pasokh.Text.Trim();
        obj.DateTimeJavab = DateTime.Now;
        dc.SubmitChanges();

        string message = "با سلام به کاربر عزیز " + obj.NameFrestande + Environment.NewLine + "با تشکر از انتخاب املاک ماهور این پیام در پاسخ به در خواست ارسال شده در تاریخ " + obj.DateErsal + " فرستاده شده است ";
        message += Environment.NewLine + " درخواست ارسال شده : " + Environment.NewLine + obj.Dsc_Darkhast;
        message += Environment.NewLine + Environment.NewLine + " پاسخ املاک ماهور : " + Environment.NewLine + obj.Javab;
        Mailer.SendMail(message, "املاک ماهور", obj.EmailFrestande, false, "پاسخ املاک ماهور");
    }

    private bool Checkvalidate()
    {
        bool result = true;
        string Msg = "لطفا به نکات زیر توجه نمایید : " + "</br>";
        int i = 0;
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.DarkhastMaskans.FirstOrDefault(s => s.UID.ToString() == ID);
        if (obj == null)
        {
            Msg += (++i).ToString() + " - " + "درخواست مسکن یافت نشد." + "</br>";
            result = false;
        }
        else if (txtdsc_pasokh.Text.Trim() == "")
        {
            Msg += (++i).ToString() + " - " + "پاسخ را وارد نمایید" + "</br>";
            result = false;
        }

        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }
    private void ReturnToLastPage()
    {
        Response.Redirect(ArssPayamUtility.GetEncodedQueryString("DarkhastMaskan.aspx?args={0}", "index=old"));
    }

}