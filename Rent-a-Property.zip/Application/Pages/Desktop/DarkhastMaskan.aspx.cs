﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Pages_Desktop_DarkhastMaskan : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    public int OldIndex
    {
        get
        {
            if (Request.Cookies["SearchCookieDarkhastMaskan"] != null && Request.Cookies["SearchCookieDarkhastMaskan"]["OldIndex"] != null)
            {

                return Convert.ToInt32(Request.Cookies["SearchCookieDarkhastMaskan"]["OldIndex"]);
            }

            return 0;
        }
        set
        {
            Response.Cookies["SearchCookieDarkhastMaskan"]["OldIndex"] = value.ToString();
        }
    }
    public string FieldJostejoCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieDarkhastMaskan"] != null && Request.Cookies["SearchCookieDarkhastMaskan"]["FieldJostejoCambo"] != null)
            {

                return Request.Cookies["SearchCookieDarkhastMaskan"]["FieldJostejoCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieDarkhastMaskan"]["FieldJostejoCambo"] = value.ToString();
        }
    }
    public string FieldMozoCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieDarkhastMaskan"] != null && Request.Cookies["SearchCookieDarkhastMaskan"]["FieldMozoCambo"] != null)
            {

                return Request.Cookies["SearchCookieDarkhastMaskan"]["FieldMozoCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieDarkhastMaskan"]["FieldMozoCambo"] = value.ToString();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        cboFieldJostejo.Focus();
        Form.DefaultButton = btnSearch.UniqueID;
        if (!IsPostBack)
        {
            bindCambobox();
            SetOldParametr();
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        liSearch_Grid.RaiseViewChanged();
    }
    protected void gvResult_PageIndexChanged(object sender, EventArgs e)
    {

        this.OldIndex = gvResult.PageIndex;

    }
    protected void gvResult_DataBound(object sender, EventArgs e)
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
                gvResult.PageIndex = OldIndex;

        }
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRow")
        {
            DeleteRecord(e.CommandArgument.ToString());

        }
        if (e.CommandName == "EditRow")
        {
            Response.Redirect(ArssPayamUtility.GetEncodedQueryString("DarkhastMaskanSpec.aspx?args={0}", "ID=" + e.CommandArgument));
        }
    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }

    public void bindCambobox()
    {
        var ds_mozo = (from p in dc.NoeDarkhasts
                       where
                       p.IsDelete == false
                       select new
                       {
                           p.id,
                           p.Name,
                           p.priority
                       }).OrderBy(s => s.priority).ToList();
        ds_mozo.Insert(0, new { id = 0, Name = "همه", priority = (int?)0 });
        cbodarkhast.DataSource = ds_mozo;
        cbodarkhast.DataBind();
    }
    private object Search()
    {

        FieldJostejoCambo = cboFieldJostejo.SelectedValue;
        FieldMozoCambo = cbodarkhast.SelectedValue;

        var Query = from p in dc.DarkhastMaskans
                    where

                    p.IsDeleted == false
                    &&
                    (
                    cboFieldJostejo.SelectedIndex == 0
                    ||
                    (cboFieldJostejo.SelectedIndex == 1 && p.IsRead == false)
                    ||
                    (cboFieldJostejo.SelectedIndex == 2 && p.IsRead == true)
                    )
                    &&
                    (
                    cbodarkhast.SelectedIndex == 0
                    ||
                    cbodarkhast.SelectedValue == p.NoeDarkhastId.ToString()
                    )
                    select new
                    {
                        p.UID,
                        Name = p.NameFrestande,
                        ShomareTamas = p.TelFrestande,
                        darkhast = p.Dsc_Darkhast,
                        mozo = p.NoeDarkhast.Name,
                        Date = p.DateErsal + " [" + p.TimeErsal + "]",
                        DatePasokh = p.DatePasokh + " [" + p.TimePasokh + "]",
                        editurl = p.IsRead ? ((p.DatePasokh == null || p.DatePasokh.Trim() == "") ? "~/Application/Images/Grid/read.png" : "~/Application/Images/Grid/replay.png") : "~/Application/Images/Grid/UnRead.png",
                        edittooltip = p.IsRead ? ((p.DatePasokh == null || p.DatePasokh.Trim() == "") ? "خوانده شده" : "پاسخ به درخواست") : "درخواست جدید",
                    };




        lblMavaredSabtShode.Text = Query.Count().ToString() + " مورد";
        return Query.OrderByDescending(s => s.Date);


    }
    private void SetOldParametr()
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
            {
                cboFieldJostejo.SelectedValue = FieldJostejoCambo;
                cbodarkhast.SelectedValue = FieldMozoCambo;
            }
        }
    }
    private void DeleteRecord(string Id)
    {
        var obj = dc.DarkhastMaskans.FirstOrDefault(s => s.UID.ToString() == Id);
        if (obj == null)
        {
            ShowErrorMessage("</br>" + "رکورد یافت نشد");
            liSearch_Grid.RaiseViewChanged();
            return;
        }
        obj.IsDeleted = true;
        dc.SubmitChanges();
        ShowSeccessMessage("</br>" + "رکورد با موفقیت حذف گردید");
        liSearch_Grid.RaiseViewChanged();


    }

}