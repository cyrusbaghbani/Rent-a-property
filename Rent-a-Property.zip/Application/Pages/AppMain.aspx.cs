﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Pages_AppMain : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    public int OldIndex
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["OldIndex"] != null)
            {

                return Convert.ToInt32(Request.Cookies["SearchCookieAmlak"]["OldIndex"]);
            }

            return 0;
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["OldIndex"] = value.ToString();
        }
    }
    public string ghymatTextAz
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["ghymatTextAz"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["ghymatTextAz"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["ghymatTextAz"] = value.ToString();
        }
    }
    public string ghymatTextTa
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["ghymatTextTa"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["ghymatTextTa"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["ghymatTextTa"] = value.ToString();
        }
    }
    public string EjareTextAz
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["EjareTextAz"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["EjareTextAz"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["EjareTextAz"] = value.ToString();
        }
    }
    public string EjareTextTa
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["EjareTextTa"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["EjareTextTa"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["EjareTextTa"] = value.ToString();
        }
    }
    public string RahnTextAz
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["RahnTextAz"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["RahnTextAz"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["RahnTextAz"] = value.ToString();
        }
    }
    public string RahnTextTa
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["RahnTextTa"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["RahnTextTa"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["RahnTextTa"] = value.ToString();
        }
    }
    public string MetrazhTextAz
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["MetrazhTextAz"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["MetrazhTextAz"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["MetrazhTextAz"] = value.ToString();
        }
    }
    public string MetrazhTextTa
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["MetrazhTextTa"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["MetrazhTextTa"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["MetrazhTextTa"] = value.ToString();
        }
    }
    public string CodeText
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["CodeText"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["CodeText"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["CodeText"] = value.ToString();
        }
    }
    public string VaziatMelkCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["VaziatMelkCambo"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["VaziatMelkCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["VaziatMelkCambo"] = value.ToString();
        }
    }
    public string TedadKhabCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["TedadKhabCambo"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["TedadKhabCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["TedadKhabCambo"] = value.ToString();
        }
    }
    public string NoeMelkCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["NoeMelkCambo"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["NoeMelkCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["NoeMelkCambo"] = value.ToString();
        }
    }
    public string NoeMoavezeCambo
    {
        get
        {
            if (Request.Cookies["SearchCookieAmlak"] != null && Request.Cookies["SearchCookieAmlak"]["NoeMoavezeCambo"] != null)
            {

                return Request.Cookies["SearchCookieAmlak"]["NoeMoavezeCambo"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookieAmlak"]["NoeMoavezeCambo"] = value.ToString();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        cboVaziatMelk.Focus();
        Form.DefaultButton = btnSearch.UniqueID;
        if (!IsPostBack)
        {
            BindCambo();
            SetOldParametr();
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        liSearch_Grid.RaiseViewChanged();
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("AppMainSpec.aspx");
    }
    protected void gvResult_PageIndexChanged(object sender, EventArgs e)
    {

        this.OldIndex = gvResult.PageIndex;

    }
    protected void gvResult_DataBound(object sender, EventArgs e)
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
                gvResult.PageIndex = OldIndex;

        }
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRow")
        {
            DeleteRecord(e.CommandArgument.ToString());

        } 
        if (e.CommandName == "EditRow")
        {
            Response.Redirect(ArssPayamUtility.GetEncodedQueryString("AppMainSpec.aspx?args={0}", "ID=" + e.CommandArgument));
        }
    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }

    private object Search()
    {
        CodeText = txtCode.Text.Trim();
        EjareTextAz = txtEjareAz.Text.Trim();
        EjareTextTa = txtEjareTa.Text.Trim();
        ghymatTextAz = txtGhymatAz.Text.Trim();
        ghymatTextTa = txtGhymatTa.Text.Trim();
        MetrazhTextAz = txtMetrazhAz.Text.Trim();
        MetrazhTextTa = txtMetrazhTa.Text.Trim();
        RahnTextAz = txtRahnAz.Text;
        RahnTextTa = txtRahnta.Text;
        NoeMoavezeCambo = cboNeMoaveze.SelectedValue;
        NoeMelkCambo = cboNoeMelk.SelectedValue;
        TedadKhabCambo = cboTedadKhab.SelectedValue;
        VaziatMelkCambo = cboVaziatMelk.SelectedValue;
        decimal tmp = 0;
        decimal? MetrazhAz = decimal.TryParse(txtMetrazhAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? MetrazhTa = decimal.TryParse(txtMetrazhTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;

        decimal? ghymatAz = decimal.TryParse(txtGhymatAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? ghymatTa = decimal.TryParse(txtGhymatTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;

        decimal? EjareAz = decimal.TryParse(txtEjareAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? EjareTa = decimal.TryParse(txtEjareTa.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;

        decimal? RahnAz = decimal.TryParse(txtRahnAz.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;
        decimal? RahnTa = decimal.TryParse(txtRahnta.Text.Replace(",", "").Trim(), out tmp) ? tmp : (decimal?)null;


        if (cboNeMoaveze.SelectedIndex == 0)
        {
            gvResult.Columns[6].Visible = true;
            gvResult.Columns[7].Visible = true;
            gvResult.Columns[8].Visible = true;
        }
        else if (cboNeMoaveze.SelectedValue == ((int)DataValueIds.NoeMoavezeIds.RahnVaEjare).ToString())
        {
            gvResult.Columns[6].Visible = true;
            gvResult.Columns[7].Visible = true;
            gvResult.Columns[8].Visible = false;
        }
        else
        {
            gvResult.Columns[6].Visible = false;
            gvResult.Columns[7].Visible = false;
            gvResult.Columns[8].Visible = true;
        }

        var Query = from p in dc.Maskans
                    where
                    p.IsDeleted == false
                    &&
                    (cboVaziatMelk.SelectedIndex == 0 || (p.IsParvandeMaskanBePayanResideAst == false && cboVaziatMelk.SelectedIndex == 1) || (p.IsParvandeMaskanBePayanResideAst == true && cboVaziatMelk.SelectedIndex == 2))
                    &&
                    (cboNeMoaveze.SelectedIndex == 0 || (p.NoeMoavezeId != null && p.NoeMoavezeId.ToString() == cboNeMoaveze.SelectedValue))
                    &&
                    (cboNoeMelk.SelectedIndex == 0 || (p.NoeMelkId != null && cboNoeMelk.SelectedValue == p.NoeMelkId.Value.ToString()))
                    &&
                    (cboTedadKhab.SelectedIndex == 0 || (p.TedadKhabId != null && cboTedadKhab.SelectedValue == p.TedadKhabId.Value.ToString()))
                    &&
                    (txtCode.Text.Trim() == "" || p.code != null && p.code.Contains(txtCode.Text.Trim()))
                    &&
                    (MetrazhAz == null || (p.Metrazh != null && p.Metrazh.Value >= MetrazhAz))
                    &&
                    (MetrazhTa == null || (p.Metrazh != null && p.Metrazh.Value <= MetrazhTa))
                    &&
                    (
                         (
                             (cboNeMoaveze.SelectedIndex == 0 || cboNeMoaveze.SelectedValue == ((int)DataValueIds.NoeMoavezeIds.RahnVaEjare).ToString())
                             &&
                             (EjareAz == null || (p.Mablagh_Ejare != null && p.Mablagh_Ejare.Value >= EjareAz))
                             &&
                             (EjareTa == null || (p.Mablagh_Ejare != null && p.Mablagh_Ejare.Value <= EjareTa))
                             &&
                             (RahnAz == null || (p.Mablagh_Rahn != null && p.Mablagh_Rahn.Value >= RahnAz))
                             &&
                             (RahnTa == null || (p.Mablagh_Rahn != null && p.Mablagh_Rahn.Value <= RahnTa))
                         )
                         ||
                         (
                             (cboNeMoaveze.SelectedIndex == 0 || cboNeMoaveze.SelectedValue != ((int)DataValueIds.NoeMoavezeIds.RahnVaEjare).ToString())
                             &&
                             (ghymatAz == null || (p.Ghymat != null && p.Ghymat.Value >= ghymatAz))
                             &&
                             (ghymatTa == null || (p.Ghymat != null && p.Ghymat.Value <= ghymatTa))
                         )
                    )
                    select new
                    {
                        p.Id,
                        Code = p.code,
                        NoeMelkName = p.NoeMelkId == null ? "-" : p.NoeMelk.Name,
                        TedadKhab = p.TedadKhabId == null ? "-" : p.TedadKhab.Name,
                        Tabghe = p.TabghaeForoshiId == null ? "-" : p.Tabghe.Name,
                        Metrazh = p.Metrazh,
                        Ejare = p.Mablagh_Ejare,
                        Rahn = p.Mablagh_Rahn,
                        Ghymat = p.Ghymat,
                        Address = p.Mantaghe,
                        url = p.IsParvandeMaskanBePayanResideAst ? "~/Application/Images/Grid/InActive.png" : "~/Application/Images/Grid/Active.png",
                        p.DateSabt_English,
                        Active = p.IsParvandeMaskanBePayanResideAst,
                        tooltip = p.IsParvandeMaskanBePayanResideAst ? "فورش و یا رهن و اجاره رفته است" : "هنوز فروش یا رهن و اجاره نرفته است",
                    };


        var Query1 = (from p in Query.ToList()
                      select new
                      {
                          p.Id,
                          p.Code,
                          p.NoeMelkName,
                          p.TedadKhab,
                          p.Tabghe,
                          Metrazh = p.Metrazh == null ? "" : p.Metrazh.Value.ToString("###,###"),
                          Ejare = p.Ejare == null ? "" : p.Ejare.Value.ToString("###,###"),
                          Rahn = p.Rahn == null ? "" : p.Rahn.Value.ToString("###,###"),
                          Ghymat = p.Ghymat == null ? "" : p.Ghymat.Value.ToString("###,###"),
                          p.Address,
                          p.url,
                          p.DateSabt_English,
                          p.Active,
                          p.tooltip,
                      });

        lblMavaredSabtShode.Text = Query1.Count().ToString() + " مورد";
        return Query1.OrderBy(s => s.DateSabt_English);


    }
    private void SetOldParametr()
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
            {
                txtCode.Text = CodeText;
                txtEjareAz.Text = EjareTextAz;
                txtEjareTa.Text = EjareTextTa;
                txtGhymatAz.Text = ghymatTextAz;
                txtGhymatTa.Text = ghymatTextTa;
                txtMetrazhAz.Text = MetrazhTextAz;
                txtMetrazhTa.Text = MetrazhTextTa;
                txtRahnAz.Text = RahnTextAz;
                txtRahnta.Text = RahnTextTa;
                cboNeMoaveze.SelectedValue = NoeMoavezeCambo;
                cboNoeMelk.SelectedValue = NoeMelkCambo;
                cboTedadKhab.SelectedValue = TedadKhabCambo;
                cboVaziatMelk.SelectedValue = VaziatMelkCambo;
            }
        }
    }
    private void DeleteRecord(string Id)
    {
        var obj = dc.Maskans.FirstOrDefault(s => s.Id.ToString() == Id);
        if (obj == null)
        {
            ShowErrorMessage("</br>" + "رکورد یافت نشد");
            liSearch_Grid.RaiseViewChanged();
            return;
        }
        List<string> imageurl = new List<string>();
        if (obj.MaskanImages.Any())
        {
            ShowErrorMessage("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
            liSearch_Grid.RaiseViewChanged();
            return;
        }
        obj.IsDeleted = true;
        dc.SubmitChanges();
        ShowSeccessMessage("</br>" + "رکورد با موفقیت حذف گردید");
        liSearch_Grid.RaiseViewChanged();


    }
    private void BindCambo()
    {
        cboNeMoaveze.DataSource = dc.NoeMoavezes.OrderBy(s => s.priority);
        cboNeMoaveze.DataBind();
        cboNeMoaveze.Items.Insert(0, new ListItem("همه موارد", "0"));

        cboNoeMelk.DataSource = dc.NoeMelks.OrderBy(s => s.priority);
        cboNoeMelk.DataBind();
        cboNoeMelk.Items.Insert(0, new ListItem("همه موارد", "0"));

        cboTedadKhab.DataSource = dc.TedadKhabs.OrderBy(s => s.priority);
        cboTedadKhab.DataBind();
        cboTedadKhab.Items.Insert(0, new ListItem("همه موارد", "0"));
    }

}