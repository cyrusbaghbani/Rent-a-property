﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class Application_Pages_Security_EtelaatSystemi : BasePage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();


    protected void Page_Load(object sender, EventArgs e)
    {
        cboTable.Focus();
        Form.DefaultButton = btnNew.UniqueID;
        if (!IsPostBack)
        {
            BindCambo();

        }
        AddbtnToUpdatepannel();
    }

    protected void btnNew_Click(object sender, EventArgs e)
    {
        if (CheckValidate())
        {
            EditItem();
            ShowSeccess("</br>" + "اطلاعات با موفقیت ثبت گردید");
        }
    }

    protected void cboTable_SelectedIndexChanged(object sender, EventArgs e)
    {
        liSearch_Grid.RaiseViewChanged();
        if (cboTable.SelectedValue == "KARBARI")
            btnNew.OnClientClick = "if(ShowEtelatSystemiInfo(this,'','مشخصات " + cboTable.SelectedItem.Text + "','','KARBARI',''))return false;";
        else if (cboTable.SelectedValue == "MANTAGHE")
            btnNew.OnClientClick = "if(ShowEtelatSystemiInfo(this,'','مشخصات " + cboTable.SelectedItem.Text + "','','MANTAGHE','')) return false;";

        else
            btnNew.OnClientClick = "if(ShowEtelatSystemiInfo(this,'','مشخصات " + cboTable.SelectedItem.Text + "',''))return false;";


    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRow")
        {
            DeleteRecord(e.CommandArgument.ToString());

        }
        if (e.CommandName == "EditRow")
        {
            if (CheckValidate(e.CommandArgument.ToString()))
            {
                EditItem(e.CommandArgument.ToString());
                ShowSeccess("</br>" + "اطلاعات با موفقیت ثبت گردید");
            }
        }
    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }

    private void EditItem(string Id = "")
    {

        if (cboTable.SelectedValue == "MELK_MELK")
        {
            var obj = dc.NoeMelks.FirstOrDefault(s => s.Id.ToString() == Id);
            int maxId = dc.NoeMelks.Any() == false ? 0 : dc.NoeMelks.Max(s => s.Id);
            if (obj == null)
            {
                obj = new NoeMelk();
                obj.Id = maxId + 1;
                obj.GROUPTYPE = "MELK";
                obj.IsDelete = false;

                dc.NoeMelks.InsertOnSubmit(obj);
            }
            obj.Name = GetName_EtelaatSystemi();
            obj.priority = Getpriority_EtelaatSystemi();
        }
        else if (cboTable.SelectedValue == "MELK_ZAMIN")
        {
            var obj = dc.NoeMelks.FirstOrDefault(s => s.Id.ToString() == Id);
            int maxId = dc.NoeMelks.Any() == false ? 0 : dc.NoeMelks.Max(s => s.Id);
            if (obj == null)
            {
                obj = new NoeMelk();
                obj.Id = maxId + 1;
                obj.GROUPTYPE = "ZAMIN";
                obj.IsDelete = false;
                dc.NoeMelks.InsertOnSubmit(obj);
            }
            obj.Name = GetName_EtelaatSystemi();
            obj.priority = Getpriority_EtelaatSystemi();
        }
        else if (cboTable.SelectedValue == "Mozo_DARKHAST_MASKAN")
        {
            var obj = dc.NoeDarkhasts.FirstOrDefault(s => s.id.ToString() == Id);
            int maxId = dc.NoeDarkhasts.Any() == false ? 0 : dc.NoeDarkhasts.Max(s => s.id);
            if (obj == null)
            {
                obj = new NoeDarkhast();
                obj.id = maxId + 1;
                obj.IsDelete = false;

                dc.NoeDarkhasts.InsertOnSubmit(obj);
            }
            obj.Name = GetName_EtelaatSystemi();
            obj.priority = Getpriority_EtelaatSystemi();
        }
        else if (cboTable.SelectedValue == "MANTAGHE")
        {
            var obj = dc.Mantaghes.FirstOrDefault(s => s.Id.ToString() == Id);
            int maxId = dc.Mantaghes.Any() == false ? 0 : dc.Mantaghes.Max(s => s.Id);
            if (obj == null)
            {
                obj = new Mantaghe();
                obj.Id = maxId + 1;
                dc.Mantaghes.InsertOnSubmit(obj);
                obj.IsDeleted = false;
            }
            obj.Makan = dc.Makans.Single(s => s.Id.ToString() == GetValue_EtelaatSystemi_NoeKarbari_NoeMelkValue());
            obj.Name = GetName_EtelaatSystemi();
            obj.priority = Getpriority_EtelaatSystemi();
        }
        else if (cboTable.SelectedValue == "MAKAN")
        {
            var obj = dc.Makans.FirstOrDefault(s => s.Id.ToString() == Id);
            int maxId = dc.Makans.Any() == false ? 0 : dc.Makans.Max(s => s.Id);
            if (obj == null)
            {
                obj = new Makan();
                obj.Id = maxId + 1;
                dc.Makans.InsertOnSubmit(obj);
                obj.IsDeleted = false;
            }
            obj.Name = GetName_EtelaatSystemi();
            obj.Priority = Getpriority_EtelaatSystemi();
        }
        else if (cboTable.SelectedValue == "KARBARI")
        {
            var obj = dc.NoeKarbaris.FirstOrDefault(s => s.Id.ToString() == Id);
            int maxId = dc.NoeKarbaris.Any() == false ? 0 : dc.NoeKarbaris.Max(s => s.Id);
            if (obj == null)
            {
                obj = new NoeKarbari();
                obj.Id = maxId + 1;
                dc.NoeKarbaris.InsertOnSubmit(obj);
                obj.IsDeleted = false;
            }
            obj.NoeMelk = dc.NoeMelks.Single(s => s.Id.ToString() == GetValue_EtelaatSystemi_NoeKarbari_NoeMelkValue());
            obj.Name = GetName_EtelaatSystemi();
            obj.priority = Getpriority_EtelaatSystemi();
        }
        else if (cboTable.SelectedValue == "TABGHE")
        {
            var obj = dc.Tabghes.FirstOrDefault(s => s.Id.ToString() == Id);
            int maxId = dc.Tabghes.Any() == false ? 0 : dc.Tabghes.Max(s => s.Id);
            if (obj == null)
            {
                obj = new Tabghe();
                obj.Id = maxId + 1;
                dc.Tabghes.InsertOnSubmit(obj);
                obj.IsDelete = false;
            }
            obj.Name = GetName_EtelaatSystemi();
            obj.priority = Getpriority_EtelaatSystemi();
        }
        else if (cboTable.SelectedValue == "TEDADKHAB")
        {
            var obj = dc.TedadKhabs.FirstOrDefault(s => s.id.ToString() == Id);
            int maxId = dc.TedadKhabs.Any() == false ? 0 : dc.TedadKhabs.Max(s => s.id);
            if (obj == null)
            {
                obj = new TedadKhab();
                obj.id = maxId + 1;
                dc.TedadKhabs.InsertOnSubmit(obj);
                obj.IsDelete = false;
            }
            obj.Name = GetName_EtelaatSystemi();
            obj.priority = Getpriority_EtelaatSystemi();
        }
        else if (cboTable.SelectedValue == "KELID")
        {
            var obj = dc.Klids.FirstOrDefault(s => s.Id.ToString() == Id);
            int maxId = dc.Klids.Any() == false ? 0 : dc.Klids.Max(s => s.Id);
            if (obj == null)
            {
                obj = new Klid();
                obj.Id = maxId + 1;
                dc.Klids.InsertOnSubmit(obj);
                obj.IsDelete = false;
            }
            obj.Name = GetName_EtelaatSystemi();
            obj.priority = Getpriority_EtelaatSystemi();
        }
        else if (cboTable.SelectedValue == "DARBAZ")
        {
            var obj = dc.DarbAzs.FirstOrDefault(s => s.Id.ToString() == Id);
            int maxId = dc.DarbAzs.Any() == false ? 0 : dc.DarbAzs.Max(s => s.Id);
            if (obj == null)
            {
                obj = new DarbAz();
                obj.Id = maxId + 1;
                dc.DarbAzs.InsertOnSubmit(obj);
                obj.IsDelete = false;
            }
            obj.Name = GetName_EtelaatSystemi();
            obj.priority = Getpriority_EtelaatSystemi();
        }
        dc.SubmitChanges();
        liSearch_Grid.RaiseViewChanged();
    }
    private bool CheckValidate(string Id = "")
    {
        bool result = true;
        int i = 0;
        string Msg = "لطفا به نکات زیر توجه نمایید : " + "</br>";
        int tmp = 0;
        if (GetName_EtelaatSystemi() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "عنوان را وارد نمایید" + "</br>";
        }
        else
        {
            string Name = GetName_EtelaatSystemi();
            bool IsExist = false;
            if (cboTable.SelectedValue == "MELK_MELK")
            {
                IsExist = dc.NoeMelks.Any(s => s.Id.ToString() != Id && s.Name == Name && s.GROUPTYPE == "MELK");
            }
            else if (cboTable.SelectedValue == "MELK_ZAMIN")
            {
                IsExist = dc.NoeMelks.Any(s => s.Id.ToString() != Id && s.Name == Name && s.GROUPTYPE == "ZAMIN");
            }
            else if (cboTable.SelectedValue == "Mozo_DARKHAST_MASKAN")
            {
                IsExist = dc.NoeDarkhasts.Any(s => s.id.ToString() != Id && s.Name == Name);
            }
            else if (cboTable.SelectedValue == "MANTAGHE")
            {
                string IDVALUE = GetValue_EtelaatSystemi_NoeKarbari_NoeMelkValue();
                IsExist = dc.Mantaghes.Any(s => s.Id.ToString() != Id && s.Name == Name && s.MakanId.ToString() == IDVALUE);
                if (!dc.Makans.Any(s => s.Id.ToString() == IDVALUE))
                {
                    result = false;
                    Msg += (++i).ToString() + " - " + "مکان را صحیح انتخاب نمایید." + "</br>";
                }
            }
            else if (cboTable.SelectedValue == "MAKAN")
            {
                IsExist = dc.Makans.Any(s => s.Id.ToString() != Id && s.Name == Name);
            }
            else if (cboTable.SelectedValue == "KARBARI")
            {
                string IDVALUE = GetValue_EtelaatSystemi_NoeKarbari_NoeMelkValue();
                IsExist = dc.NoeKarbaris.Any(s => s.Id.ToString() != Id && s.Name == Name && s.NeMelkId.ToString() == IDVALUE);
                if (!dc.NoeMelks.Any(s => s.Id.ToString() == IDVALUE && s.GROUPTYPE == "ZAMIN"))
                {
                    result = false;
                    Msg += (++i).ToString() + " - " + "نوع ملک را صحیح انتخاب نمایید." + "</br>";
                }
            }
            else if (cboTable.SelectedValue == "TABGHE")
            {
                IsExist = dc.Tabghes.Any(s => s.Id.ToString() != Id && s.Name == Name);
            }
            else if (cboTable.SelectedValue == "TEDADKHAB")
            {
                IsExist = dc.TedadKhabs.Any(s => s.id.ToString() != Id && s.Name == Name);
            }
            else if (cboTable.SelectedValue == "KELID")
            {
                IsExist = dc.Klids.Any(s => s.Id.ToString() != Id && s.Name == Name);
            }
            else if (cboTable.SelectedValue == "DARBAZ")
            {
                IsExist = dc.DarbAzs.Any(s => s.Id.ToString() != Id && s.Name == Name);
            }
            if (IsExist)
            {
                result = false;
                Msg += (++i).ToString() + " - " + "عنوان وارد شده قبلا در سیستم ثبت شده است." + "</br>";
            }
        }

        if (!result)
            ShowError(Msg);
        return result;
    }
    private object Search()
    {

        if (cboTable.SelectedValue == "MELK_MELK")
        {
            gvResult.Columns[2].Visible = false;
            var lst = dc.NoeMelks.Where(s => s.GROUPTYPE == "MELK").OrderBy(s => s.priority).Select(s => new { id = s.Id, Name = s.Name, noemelk = "", priority = s.priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.priority == null ? "" : s.priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        else if (cboTable.SelectedValue == "MELK_ZAMIN")
        {
            gvResult.Columns[2].Visible = false;
            var lst = dc.NoeMelks.Where(s => s.GROUPTYPE == "ZAMIN").OrderBy(s => s.priority).Select(s => new { id = s.Id, Name = s.Name, noemelk = "", priority = s.priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.priority == null ? "" : s.priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        else if (cboTable.SelectedValue == "Mozo_DARKHAST_MASKAN")
        {
            gvResult.Columns[2].Visible = false;
            var lst = dc.NoeDarkhasts.OrderBy(s => s.priority).Select(s => new { id = s.id, Name = s.Name, noemelk = "", priority = s.priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.priority == null ? "" : s.priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        else if (cboTable.SelectedValue == "MANTAGHE")
        {
            gvResult.Columns[2].Visible = true;
            gvResult.Columns[2].HeaderText = "مکان";
            var lst = dc.Mantaghes.OrderBy(s => s.priority).Select(s => new { id = s.Id, Name = s.Name, noemelk = s.Makan.Name, priority = s.priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.priority == null ? "" : s.priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "','MANTAGHE','" + s.MakanId.ToString() + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        else if (cboTable.SelectedValue == "MAKAN")
        {
            gvResult.Columns[2].Visible = false;
            var lst = dc.Makans.OrderBy(s => s.Priority).Select(s => new { id = s.Id, noemelk = "", Name = s.Name, priority = s.Priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.Priority == null ? "" : s.Priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        else if (cboTable.SelectedValue == "KARBARI")
        {
            gvResult.Columns[2].Visible = true;
            gvResult.Columns[2].HeaderText = "نوع ملک";
            var lst = dc.NoeKarbaris.OrderBy(s => s.priority).Select(s => new { id = s.Id, Name = s.Name, noemelk = s.NoeMelk.Name, priority = s.priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.priority == null ? "" : s.priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "','KARBARI','" + s.NeMelkId.ToString() + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        else if (cboTable.SelectedValue == "TABGHE")
        {
            gvResult.Columns[2].Visible = false;
            var lst = dc.Tabghes.OrderBy(s => s.priority).Select(s => new { id = s.Id, Name = s.Name, noemelk = "", priority = s.priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.priority == null ? "" : s.priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        else if (cboTable.SelectedValue == "DARBAZ")
        {
            gvResult.Columns[2].Visible = false;
            var lst = dc.DarbAzs.OrderBy(s => s.priority).Select(s => new { id = s.Id, Name = s.Name, noemelk = "", priority = s.priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.priority == null ? "" : s.priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        else if (cboTable.SelectedValue == "KELID")
        {
            gvResult.Columns[2].Visible = false;
            var lst = dc.Klids.OrderBy(s => s.priority).Select(s => new { id = s.Id, Name = s.Name, noemelk = "", priority = s.priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.priority == null ? "" : s.priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        else if (cboTable.SelectedValue == "TEDADKHAB")
        {
            gvResult.Columns[2].Visible = false;
            var lst = dc.TedadKhabs.OrderBy(s => s.priority).Select(s => new { id = s.id, Name = s.Name, noemelk = "", priority = s.priority, EditInfo = "if(ShowEtelatSystemiInfo(this,'" + (s.priority == null ? "" : s.priority.ToString()) + "','مشخصات " + cboTable.SelectedItem.Text + "','" + s.Name + "'))return false; else ShowModelDialogProgress();" });
            lblMavaredSabtShode.Text = lst.Count().ToString() + " مورد";
            ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
            return lst;
        }
        gvResult.Columns[2].Visible = false;
        lblMavaredSabtShode.Text = "0 مورد";
        ScriptManager.RegisterStartupScript(gvResult, this.GetType(), "alert", "progressclose(); ", true);
        return null;


    }
    private void DeleteRecord(string Id)
    {
        if (cboTable.SelectedValue == "MELK_MELK" || cboTable.SelectedValue == "MELK_ZAMIN")
        {
            var obj = dc.NoeMelks.FirstOrDefault(s => s.Id.ToString() == Id);
            if (obj == null)
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "رکورد یافت نشد");
                return;
            }

            if (obj.Maskans.Any() || obj.NoeKarbaris.Any())
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }
            dc.NoeMelks.DeleteOnSubmit(obj);
        }
        else if (cboTable.SelectedValue == "Mozo_DARKHAST_MASKAN")
        {
            var obj = dc.NoeDarkhasts.FirstOrDefault(s => s.id.ToString() == Id);
            if (obj == null)
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "رکورد یافت نشد");
                return;
            }

            if (obj.DarkhastMaskans.Any())
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }
            dc.NoeDarkhasts.DeleteOnSubmit(obj);
        }
        else if (cboTable.SelectedValue == "MANTAGHE")
        {
            var obj = dc.Mantaghes.FirstOrDefault(s => s.Id.ToString() == Id);
            if (obj == null)
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "رکورد یافت نشد");
                return;
            }

            if (obj.Maskans.Any())
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }
            dc.Mantaghes.DeleteOnSubmit(obj);
        }
        else if (cboTable.SelectedValue == "MAKAN")
        {
            var obj = dc.Makans.FirstOrDefault(s => s.Id.ToString() == Id);
            if (obj == null)
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "رکورد یافت نشد");
                return;
            }

            if (obj.Maskans.Any() || obj.Mantaghes.Any())
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }
            dc.Makans.DeleteOnSubmit(obj);
        }
        else if (cboTable.SelectedValue == "KARBARI")
        {
            var obj = dc.NoeKarbaris.FirstOrDefault(s => s.Id.ToString() == Id);
            if (obj == null)
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "رکورد یافت نشد");
                return;
            }

            if (obj.MaskanNoeKarbaris.Any())
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }
            dc.NoeKarbaris.DeleteOnSubmit(obj);
        }
        else if (cboTable.SelectedValue == "TABGHE")
        {
            var obj = dc.Tabghes.FirstOrDefault(s => s.Id.ToString() == Id);
            if (obj == null)
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "رکورد یافت نشد");
                return;
            }

            if (obj.Maskans.Any())
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }
            dc.Tabghes.DeleteOnSubmit(obj);
        }
        else if (cboTable.SelectedValue == "DARBAZ")
        {
            var obj = dc.DarbAzs.FirstOrDefault(s => s.Id.ToString() == Id);
            if (obj == null)
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "رکورد یافت نشد");
                return;
            }

            if (obj.Maskans.Any())
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }
            dc.DarbAzs.DeleteOnSubmit(obj);
        }
        else if (cboTable.SelectedValue == "KELID")
        {
            var obj = dc.Klids.FirstOrDefault(s => s.Id.ToString() == Id);
            if (obj == null)
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "رکورد یافت نشد");
                return;
            }

            if (obj.Maskans.Any())
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }
            dc.Klids.DeleteOnSubmit(obj);
        }
        else if (cboTable.SelectedValue == "TEDADKHAB")
        {
            var obj = dc.TedadKhabs.FirstOrDefault(s => s.id.ToString() == Id);
            if (obj == null)
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "رکورد یافت نشد");
                return;
            }

            if (obj.Maskans.Any())
            {

                liSearch_Grid.RaiseViewChanged();
                ShowError("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }
            dc.TedadKhabs.DeleteOnSubmit(obj);
        }


        dc.SubmitChanges();

        liSearch_Grid.RaiseViewChanged();
        ShowSeccess("</br>" + "رکورد با موفقیت حذف گردید");

    }

    private void ShowError(string msg)
    {
        string message = "progressclose();ShowErrorMessage('" + msg + "');";
        ScriptManager.RegisterStartupScript(btnNew, this.GetType(), "alert", message, true);
    }
    private void ShowSeccess(string msg)
    {
        string message = "progressclose();ShowSeccessMessage('" + msg + "');";
        ScriptManager.RegisterStartupScript(btnNew, this.GetType(), "alert", message, true);
    }
    private void BindCambo()
    {
        cboTable.Items.Add(new ListItem("نوع ملک (آپارنمان، منزل) ", "MELK_MELK"));
        cboTable.Items.Add(new ListItem("نوع ملک (باغ شهری، زمین)", "MELK_ZAMIN"));
        cboTable.Items.Add(new ListItem("نوع کاربری", "KARBARI"));
        cboTable.Items.Add(new ListItem("مکان", "MAKAN"));
        cboTable.Items.Add(new ListItem("منطقه", "MANTAGHE"));
        cboTable.Items.Add(new ListItem("طبقه اسکان", "TABGHE"));
        cboTable.Items.Add(new ListItem("درب از", "DARBAZ"));
        cboTable.Items.Add(new ListItem("کلید", "KELID"));
        cboTable.Items.Add(new ListItem("تعداد خواب", "TEDADKHAB"));
        cboTable.Items.Add(new ListItem("موضوع درخواست", "Mozo_DARKHAST_MASKAN"));
        cboTable.SelectedIndex = 0;
        btnNew.OnClientClick = "if(ShowEtelatSystemiInfo(this,'','مشخصات " + cboTable.SelectedItem.Text + "',''))return false;";
    }
    private void AddbtnToUpdatepannel()
    {
        foreach (GridViewRow row in gvResult.Rows)
        {
            ImageButton Edit = (ImageButton)row.FindControl("btnEdit");
            ImageButton Del = (ImageButton)row.FindControl("btnDeleterow");
            ScriptManager.GetCurrent(this).RegisterAsyncPostBackControl(Edit);
            ScriptManager.GetCurrent(this).RegisterAsyncPostBackControl(Del);
        }
    }

    [System.Web.Services.WebMethod]
    public static string getNoeMelkItems(string Name)
    {
        dbMaskanDataContext dc = new dbMaskanDataContext();
        if (Name == "KARBARI")
        {
            var obj = dc.NoeMelks.Where(s => s.GROUPTYPE == "ZAMIN").OrderBy(s => s.priority).ToList();
            if (!obj.Any())
                return "";
            return obj.Select(a => a.Name + ";" + a.Id).Aggregate((a, b) => a + "^" + b);
        }
        else if (Name == "MANTAGHE")
        {

            var obj = dc.Makans.OrderBy(s => s.Priority).ToList();
            if (!obj.Any())
                return "";
            return obj.Select(a => a.Name + ";" + a.Id).Aggregate((a, b) => a + "^" + b);
        }

        return "";
    }

}