﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class login : PrimeryPage
{
    dbMaskanDataContext dc = new dbMaskanDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        Form.DefaultButton = btnvorod.UniqueID;
        txtusername.Focus();
        if (!IsPostBack)
        {
            DeleteAllTempFiles();
            Session.RemoveAll();
        }
    }
    protected void btnvorod_Click(object sender, ImageClickEventArgs e)
    {
        if (CheckValidate())
        {
            Login();
        }
    }

    private bool CheckValidate()
    {
        string Msg = "لطفا به نکات زیر توجه نمایید :" + "</br>";
        bool result = true;
        int i = 0;
        if (txtusername.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام کاربری را وارد نمایید." + "</br>";
        }
        if (txtPass.Text == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "کلمه عبور را وارد نمایید." + "</br>";
        }
        if (result && !dc.User_s.Any(s => s.UserName == txtusername.Text.Trim() && s.Password == EncryptedQueryString.GetMD5Hash(txtPass.Text.Trim()) && s.IsActive == true))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام کاربری و یا کلمه عبور اشتباه می باشد." + "</br>";
        }


        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }

    private void Login()
    {
        Session["USERID"] = dc.User_s.SingleOrDefault(s => s.UserName == txtusername.Text.Trim() && s.Password == EncryptedQueryString.GetMD5Hash(txtPass.Text.Trim()) && s.IsActive == true).Id;
        Response.Redirect("~/Application/Pages/Desktop/Melks.aspx");
    }

    /// <summary>
    /// تمام عکسهایی که به صورت موقت ذخیره شده است
    /// </summary>
    private void DeleteAllTempFiles()
    {

        var lst = dc.TempImages.ToList();
        List<string> lstaddress = new List<string>();
        foreach (var t in lst)
        {
            try
            {
                if (DateTime.Now.Subtract(t.Datetime.Value).Hours > 1)
                {
                    lstaddress.Add(t.Address);
                    dc.TempImages.DeleteOnSubmit(t);
                }
            }
            catch { }
        }
        dc.SubmitChanges();
        foreach (var adr in lstaddress)
        {
            try
            {
                string path = Server.MapPath(adr);
                if (File.Exists(path))
                    File.Delete(path);

            }
            catch { }
        }

    }
}