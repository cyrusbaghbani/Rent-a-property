﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }



    [System.Web.Services.WebMethod]
    public static string getImage(string UID, string w, string h)
    {
        dbMaskanDataContext dc = new dbMaskanDataContext();
        var objs = dc.MaskanImages.Where(s => s.MaskanId.ToString() == UID);
        if (objs.Any() == false)
            return "";

        int i = 0;
        string bigimg = " <ul class=\"big_img\" id=\"BIGSLIDERDialogImg\" style=\"width: 100%;\">";
        string smallimg = " <ul class=\"slider_list\" id=\"SMALLSLIDERDialogImg\" style=\"height: 50px; padding-top: 5px\">";

        foreach (var obj in objs)
        {
            bigimg += " <li> <img src=\"/Attachment/Images/" + obj.Address + "\" style=\"height:100%;max-width: " + w + "px; max-height:" + h + "px\" alt=\"\" /> </li> ";
            smallimg += " <li index='" + (++i).ToString() + "' class=\"current\"><a> <img src=\"/Attachment/Images/" + obj.Address + "\" height=\"40px\" style=\"max-width:80px\" alt=\"\" /><span class=\"border\"></span></a></li> ";
        }
        bigimg += " </ul>";
        smallimg += " </ul>";
        return bigimg + smallimg;
    }
    [System.Web.Services.WebMethod]
    public static string getTableData(string UID, string admin)
    {
        if (admin == "ADMIN")
        {
            return getTableDataADMIN(UID);
        }
        else
        {
            dbMaskanDataContext dc = new dbMaskanDataContext();
            var obj = dc.Maskans.SingleOrDefault(s => s.Id.ToString() == UID);
            if (obj == null)
                return "";
            string[] bgcolor = { "#bfbfbf", "#c5c8d5" };
            int i = 0;
            string Table = " <table cellpadding=\"0\" cellspacing=\"5\" style=\"border: 3px solid transparent; width: 100%\">";

            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.code + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "کد" + "</td>";
            Table += " </tr>";
            i++;
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.NoeMoaveze.Name + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "نوع معامله" + "</td>";
            Table += " </tr>";
            i++;


            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.NoeMelk.Name + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "نوع ملک" + "</td>";
            Table += " </tr>";
            i++;
            if (obj.NoeMelk.GROUPTYPE == "ZAMIN" && obj.MaskanNoeKarbaris.Any())
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.MaskanNoeKarbaris.Select(s => s.NoeKarbari.Name).ToList().Aggregate((a, b) => a + ", " + b) + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "نوع کاربری" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.MakanId != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Makan.Name + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "مکان" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.MantagheId != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Mantaghe.Name + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "منطقه" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.LittleAddress_Baray_Namayesh_Dar_Site != null && obj.LittleAddress_Baray_Namayesh_Dar_Site.Trim() != "")
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.LittleAddress_Baray_Namayesh_Dar_Site + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "آدرس" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.Metrazh != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Metrazh == null ? "" : obj.Metrazh.Value.ToString("###,###")) + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "متراژ (مترمربع)" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.NoeMelk.GROUPTYPE == "ZAMIN" && (obj.Tol_Abad_Zamin != null || obj.Arz_Abad_Zamin != null))
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + "طول : " + (obj.Tol_Abad_Zamin == null ? "" : obj.Tol_Abad_Zamin.ToString()) + " عرض : " + (obj.Arz_Abad_Zamin == null ? "" : obj.Arz_Abad_Zamin.ToString()) + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "ابعاد" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.DarbAzId != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.DarbAz.Name + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "درب از" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.NoeMelk.GROUPTYPE == "MELK" && obj.TedadKhabId != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.TedadKhab.Name + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "تعداد خواب" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.NoeMelk.GROUPTYPE == "MELK" && obj.TabghaeForoshiId != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Tabghe.Name + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "طبقه اسکان" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.NoeMoavezeId != null && obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.RahnVaEjare && obj.Mablagh_Rahn != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Mablagh_Rahn == null ? "" : obj.Mablagh_Rahn.Value.ToString("###,###")) + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "رهن (میلیون تومان)" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.NoeMoavezeId != null && obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.RahnVaEjare && obj.Mablagh_Ejare != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Mablagh_Ejare == null ? "" : obj.Mablagh_Ejare.Value.ToString("###,###")) + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "اجاره (تومان)" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.NoeMoavezeId != null && (obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh) && obj.Ghymat != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Ghymat == null ? "" : obj.Ghymat.Value.ToString("###,###")) + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "قیمت (تومان)" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.NoeMoavezeId != null && (obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh) && obj.Vam != null)
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Vam == null ? "" : obj.Vam.Value.ToString("###,###")) + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "وام (تومان)" + "</td>";
                Table += " </tr>";
                i++;
            }
            if (obj.Dsc != null && obj.Dsc != "")
            {
                Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
                Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Dsc + "</td>";
                Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "توضیحات" + "</td>";
                Table += " </tr>";
                i++;
            }
            Table += " </table>";

            return Table;
        }
    }

    public static string getTableDataADMIN(string UID)
    {
        dbMaskanDataContext dc = new dbMaskanDataContext();
        var obj = dc.Maskans.SingleOrDefault(s => s.Id.ToString() == UID);
        if (obj == null)
            return "";
        string[] bgcolor = { "#bfbfbf", "#c5c8d5" };
        int i = 0;
        string Table = " <table cellpadding=\"0\" cellspacing=\"5\" style=\"border: 3px solid transparent; width: 100%\">";

        Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
        Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.code + "</td>";
        Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "کد" + "</td>";
        Table += " </tr>";
        i++;
        Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
        Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.NoeMoaveze.Name + "</td>";
        Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "نوع معامله" + "</td>";
        Table += " </tr>";
        i++;


        Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
        Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.NoeMelk.Name + "</td>";
        Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "نوع ملک" + "</td>";
        Table += " </tr>";
        i++;
        if (obj.NoeMelk.GROUPTYPE == "ZAMIN" && obj.MaskanNoeKarbaris.Any())
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.MaskanNoeKarbaris.Select(s => s.NoeKarbari.Name).ToList().Aggregate((a, b) => a + ", " + b) + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "نوع کاربری" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.MakanId != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Makan.Name + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "مکان" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.MantagheId != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Mantaghe.Name + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "منطقه" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.AddressKamel != null && obj.AddressKamel.Trim() != "")
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.AddressKamel + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "آدرس" + "</td>";
            Table += " </tr>";
            i++;
        }
        else if (obj.LittleAddress_Baray_Namayesh_Dar_Site != null && obj.LittleAddress_Baray_Namayesh_Dar_Site.Trim() != "")
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.LittleAddress_Baray_Namayesh_Dar_Site + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 120px; padding: 5px\">" + "آدرس" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.NoeMelk.GROUPTYPE == "ZAMIN" && obj.Pelak != null && obj.Pelak != "")
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Pelak + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "پلاک" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.Metrazh != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Metrazh == null ? "" : obj.Metrazh.Value.ToString("###,###")) + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "متراژ (مترمربع)" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.NoeMelk.GROUPTYPE == "ZAMIN" && (obj.Tol_Abad_Zamin != null || obj.Arz_Abad_Zamin != null))
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + "طول : " + (obj.Tol_Abad_Zamin == null ? "" : obj.Tol_Abad_Zamin.ToString()) + " عرض : " + (obj.Arz_Abad_Zamin == null ? "" : obj.Arz_Abad_Zamin.ToString()) + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "ابعاد" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.DarbAzId != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.DarbAz.Name + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "درب از" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.NoeMelk.GROUPTYPE == "MELK" && obj.TedadKhabId != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.TedadKhab.Name + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "تعداد خواب" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.NoeMelk.GROUPTYPE == "MELK" && obj.TabghaeForoshiId != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Tabghe.Name + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "طبقه اسکان" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.NoeMoavezeId != null && obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.RahnVaEjare && obj.Mablagh_Rahn != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Mablagh_Rahn == null ? "" : obj.Mablagh_Rahn.Value.ToString("###,###")) + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "رهن (میلیون تومان)" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.NoeMoavezeId != null && obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.RahnVaEjare && obj.Mablagh_Ejare != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Mablagh_Ejare == null ? "" : obj.Mablagh_Ejare.Value.ToString("###,###")) + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "اجاره (تومان)" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.NoeMoavezeId != null && (obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh) && obj.Ghymat != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Ghymat == null ? "" : obj.Ghymat.Value.ToString("###,###")) + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "قیمت (تومان)" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.NoeMoavezeId != null && (obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.PishForosh || obj.NoeMoavezeId == (int)DataValueIds.NoeMoavezeIds.KharidVaForosh) && obj.Vam != null)
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + (obj.Vam == null ? "" : obj.Vam.Value.ToString("###,###")) + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "وام (تومان)" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.Dsc != null && obj.Dsc != "")
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Dsc + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "توضیحات" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.Dsc_ShakhsiBarayUser != null && obj.Dsc_ShakhsiBarayUser != "")
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.Dsc_ShakhsiBarayUser + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "توضیحات - مدیر" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.FullNameSahebkhane != null && obj.FullNameSahebkhane != "")
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.FullNameSahebkhane + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "نام و نام خانوادگی مالک" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.ShomareTelSahebkhane != null && obj.ShomareTelSahebkhane != "")
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.ShomareTelSahebkhane + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "شماره تماس مالک" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.FullNameMostajer != null && obj.FullNameMostajer != "")
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.FullNameMostajer + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "نام و نام خانوادگی مستاجر" + "</td>";
            Table += " </tr>";
            i++;
        }
        if (obj.ShomareTelMostajer != null && obj.ShomareTelMostajer != "")
        {
            Table += " <tr style=\"background-color: " + bgcolor[i % 2] + "\"> ";
            Table += " <td style=\"text-align: right; direction: rtl; padding: 5px\">" + obj.ShomareTelMostajer + "</td>";
            Table += " <td style=\"text-align: left; direction: rtl; width: 140px; padding: 5px\">" + "شماره تماس مستاجر" + "</td>";
            Table += " </tr>";
            i++;
        }
        Table += " </table>";
        return Table;
    }
}